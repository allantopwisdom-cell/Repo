import os, subprocess, tempfile
from pathlib import Path
root=Path(__file__).resolve().parents[1]
with tempfile.TemporaryDirectory() as tmp:
    tmp=Path(tmp); log=tmp/'calls'; tool=tmp/'launchctl'
    tool.write_text('''#!/bin/sh
printf '%s\\n' "$*" >> "$PC_TEST_LOG"
if [ "$1" = print ]; then
 case "$PC_TEST_DOMAIN:$2" in
  user:user/foreground/com.apple.thermalmonitord|system:system/com.apple.thermalmonitord) exit 0;;
  *) exit 1;;
 esac
fi
exit "${PC_TEST_KICK_RESULT:-0}"
''');tool.chmod(0o755)
    for script,expected in [('postinst','configure'),('postrm','remove')]:
        text=(root/'layout/DEBIAN'/script).read_text()
        text=text.replace('for candidate in /bin/launchctl /usr/bin/launchctl /rootfs/bin/launchctl;',f'for candidate in "{tool}";')
        fixture=tmp/script;fixture.write_text(text)
        for phase in ['configure','remove','purge','upgrade','abort-upgrade','failed-upgrade','']:
            for domain in ['user','system','missing']:
                for failed in ['0','1']:
                    log.write_text('')
                    env={**os.environ,'PC_TEST_LOG':str(log),'PC_TEST_DOMAIN':domain,'PC_TEST_KICK_RESULT':failed}
                    result=subprocess.run(['sh',str(fixture),phase],env=env,capture_output=True,text=True)
                    assert result.returncode==0
                    calls=log.read_text().splitlines()
                    kicks=[x for x in calls if x.startswith('kickstart')]
                    if phase!=expected: assert not calls,(script,phase,calls)
                    elif domain=='missing': assert not kicks
                    else:
                        target='user/foreground' if domain=='user' else 'system'
                        assert kicks==[f'kickstart -k {target}/com.apple.thermalmonitord']
                        if failed=='1':assert 'failed' in result.stderr or 'still be loaded' in result.stderr
print('PASS: actual maintenance scripts, 84 phase/domain/failure combinations; service commands mocked')
