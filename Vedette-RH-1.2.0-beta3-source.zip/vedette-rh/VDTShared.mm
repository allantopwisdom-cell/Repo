// Original project Copyright (c) 2021 udevs; defensive preferences I/O, GPLv3.
#import "VDTShared.h"
#import "VDTValidation.h"
#include <sys/file.h>
#include <fcntl.h>
#include <unistd.h>
static NSDictionary *readDictionary(NSString *path) {
    NSDictionary *attributes=[[NSFileManager defaultManager] attributesOfItemAtPath:path error:NULL];
    if(!attributes || [attributes fileSize]>1024*1024)return @{};
    NSData *data=[NSData dataWithContentsOfFile:path options:NSDataReadingMappedIfSafe error:NULL];
    if(!data || data.length>1024*1024)return @{};
    id value=[NSPropertyListSerialization propertyListWithData:data options:NSPropertyListImmutable format:NULL error:NULL];
    return [value isKindOfClass:NSDictionary.class]?value:@{};
}
NSDictionary *getPrefs(){return readDictionary(PREFS_PATH);}
NSDictionary *getTempPrefs(){return readDictionary(PREFS_PATH_TMP);}
static BOOL globalFlag(NSString *key){return [key isKindOfClass:NSString.class] && [@[@"enabled",@"dryRun",@"allowTerminate"] containsObject:key];}
static id safeValue(NSString *key,id value,id fallback) {
    if([key isEqual:@"enabled"] || [key isEqual:@"dryRun"] || [key isEqual:@"allowTerminate"])
        return @(VDTFlagOr(value,VDTFlagOr(fallback,[key isEqual:@"dryRun"])));
    int number=0;int lo=0,hi=0;
    if([key isEqual:@"percentage"]){lo=20;hi=100;}
    else if([key isEqual:@"interval"]){lo=60;hi=3600;}
    else if([key isEqual:@"violationPolicy"]){lo=2;hi=3;}
    else if([key isEqual:@"executablePath"])return VDTAbsolutePath(value)?value:nil;
    else return fallback;
    if(VDTInteger(value,lo,hi,&number))return @(number);
    return VDTInteger(fallback,lo,hi,&number)?@(number):nil;
}
id valueForKey(NSString *key){return globalFlag(key)?safeValue(key,getPrefs()[key],nil):nil;}
id valueForKeyWithPrefs(NSString *key,NSDictionary *prefs){return globalFlag(key)?safeValue(key,(prefs?:getPrefs())[key],nil):nil;}
static NSString *collectionKey(VDTConfigType type){return type==VDTConfigTypeApp?@"appConfigs":@"daemonConfigs";}
static NSString *identifierKey(VDTConfigType type){return type==VDTConfigTypeApp?@"bundleIdentifier":@"daemonName";}
static void postChange(void) {
#ifndef VDT_HOST_TEST
    CFNotificationCenterPostNotification(CFNotificationCenterGetDarwinNotifyCenter(),(CFStringRef)PREFS_CHANGED_NN,NULL,NULL,YES);
#endif
}
static BOOL changePrefs(BOOL (^change)(NSMutableDictionary *)) {
    NSString *lockPath=[PREFS_PATH stringByAppendingString:@".lock"];
    int fd=open(lockPath.fileSystemRepresentation,O_CREAT|O_RDWR|O_NOFOLLOW|O_CLOEXEC,0600);
    struct stat info;
    if(fd<0)return NO;
    if(fstat(fd,&info)!=0 || !S_ISREG(info.st_mode) || info.st_nlink!=1 || flock(fd,LOCK_EX|LOCK_NB)!=0){close(fd);return NO;}
    NSMutableDictionary *prefs=[getPrefs() mutableCopy];
    BOOL changed=change(prefs);
    NSData *encoded=changed?[NSPropertyListSerialization dataWithPropertyList:prefs format:NSPropertyListXMLFormat_v1_0 options:0 error:NULL]:nil;
    BOOL ok=encoded && encoded.length<=1024*1024 && [encoded writeToFile:PREFS_PATH options:NSDataWritingAtomic error:NULL];
    flock(fd,LOCK_UN);close(fd);
    if(ok)postChange();else NSLog(@"[Vedette RH] preferences write rejected or failed");
    return ok;
}
BOOL setValueForKeyWithPrefs(NSString *key,id value,NSDictionary *prefs) {
    (void)prefs;BOOL flag=NO;
    if(!globalFlag(key) || !VDTFlag(value,&flag))return NO;
    return changePrefs(^BOOL(NSMutableDictionary *d){d[key]=@(flag);return YES;});
}
BOOL setValueForKey(NSString *key,id value){return setValueForKeyWithPrefs(key,value,nil);}
id valueForProcessConfigKeyWithPrefs(NSString *ident,NSString *key,id fallback,VDTConfigType type,NSDictionary *prefs) {
    if(!VDTIdentifier(ident) || (type!=VDTConfigTypeApp && type!=VDTConfigTypeDaemon))return safeValue(key,nil,fallback);
    id configs=(prefs?:getPrefs())[collectionKey(type)];
    if(![configs isKindOfClass:NSArray.class] || [configs count]>1024)return safeValue(key,nil,fallback);
    id found=nil;BOOL duplicate=NO;
    for(id item in configs)if([item isKindOfClass:NSDictionary.class] && [item[identifierKey(type)] isEqual:ident]){
        if(found){duplicate=YES;break;}found=item;
    }
    return safeValue(key,duplicate?nil:found[key],fallback);
}
id valueForProcessConfigKey(NSString *ident,NSString *key,id fallback,VDTConfigType type) {
    return valueForProcessConfigKeyWithPrefs(ident,key,fallback,type,nil);
}
BOOL VDTSetProcessConfigValue(NSString *ident,NSString *key,id value,VDTConfigType type,NSString *executablePath) {
    if(!VDTIdentifier(ident) || ![key isKindOfClass:NSString.class] || ![@[@"enabled",@"violationPolicy",@"percentage",@"interval"] containsObject:key] ||
       (type!=VDTConfigTypeApp && type!=VDTConfigTypeDaemon))return NO;
    id validated=nil;int number=0;BOOL enabled=NO;
    if([key isEqual:@"enabled"]){if(!VDTFlag(value,&enabled))return NO;validated=@(enabled);}
    else {
        int lo=[key isEqual:@"percentage"]?20:([key isEqual:@"interval"]?60:2);
        int hi=[key isEqual:@"percentage"]?100:([key isEqual:@"interval"]?3600:3);
        if(!VDTInteger(value,lo,hi,&number))return NO;validated=@(number);
    }
    if(enabled && ((type==VDTConfigTypeDaemon && vdt_protected_name(ident.UTF8String)) || [ident isEqual:@"com.apple.Preferences"] || [ident isEqual:@"com.apple.springboard"]))return NO;
    if(executablePath && !VDTAbsolutePath(executablePath))return NO;
    NSString *resolvedPath=executablePath?[executablePath stringByResolvingSymlinksInPath]:nil;
    if(executablePath && !VDTAbsolutePath(resolvedPath))return NO;
    return changePrefs(^BOOL(NSMutableDictionary *d){
        id original=d[collectionKey(type)];NSMutableArray *items=[NSMutableArray array];NSMutableDictionary *entry=nil;
        if([original isKindOfClass:NSArray.class])for(id item in original) {
            if(![item isKindOfClass:NSDictionary.class])continue;
            if([item[identifierKey(type)] isEqual:ident]) {if(!entry)entry=[item mutableCopy];}
            else [items addObject:item];
        }
        if(items.count>=1024)return NO;
        if(!entry)entry=[@{identifierKey(type):ident} mutableCopy];
        if(type==VDTConfigTypeDaemon && executablePath)entry[@"executablePath"]=resolvedPath;
        if(type==VDTConfigTypeDaemon && enabled && !VDTAbsolutePath(entry[@"executablePath"]))return NO;
        entry[key]=validated;[items addObject:entry];d[collectionKey(type)]=items;return YES;
    });
}
BOOL setValueForProcessConfigKeyWithPrefs(NSString *ident,NSString *key,id value,VDTConfigType type,NSDictionary *prefs) {
    (void)prefs;return VDTSetProcessConfigValue(ident,key,value,type,nil);
}
BOOL setValueForProcessConfigKey(NSString *ident,NSString *key,id value,VDTConfigType type) {
    return VDTSetProcessConfigValue(ident,key,value,type,nil);
}
BOOL VDTResetPreferences(void) {
    return changePrefs(^BOOL(NSMutableDictionary *d){[d removeAllObjects];d[@"enabled"]=@NO;d[@"dryRun"]=@YES;return YES;});
}
BOOL VDTCancelRemoval(void) {
    if(!VDTRemovalRequested())return YES;
    BOOL removed=[[NSFileManager defaultManager] removeItemAtPath:VDT_REMOVAL_PATH error:NULL];
    if(removed)postChange();return removed;
}

NSDictionary *VDTGetStatus(void){return readDictionary(VDT_STATUS_PATH);}
