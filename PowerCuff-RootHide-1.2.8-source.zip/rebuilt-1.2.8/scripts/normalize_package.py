#!/usr/bin/env python3
"""Normalize numeric archive owners without changing any regular-file payload bytes."""
from package_format import open_tar
import gzip,hashlib,io,lzma,pathlib,re,struct,sys,tarfile

def members(data):
    assert data[:8]==b'!<arch>\n';pos=8;out={}
    while pos<len(data):
        h=data[pos:pos+60];assert len(h)==60 and h[58:]==b'`\n'
        name=h[:16].rstrip(b' ');assert re.fullmatch(rb'[A-Za-z0-9_.-]{1,15}/?',name)
        assert re.fullmatch(rb' *[0-9]+ *',h[48:58]);size=int(h[48:58]);name=name.rstrip(b'/').decode()
        assert name not in out and pos+60+size<=len(data)
        out[name]=data[pos+60:pos+60+size];pos+=60+size
        if size%2:assert data[pos:pos+1]==b'\n';pos+=1
    assert pos==len(data)
    return out

def payloads(blob,name):
    with open_tar(blob,name) as archive:
        return {t.name:hashlib.sha256(archive.extractfile(t).read()).hexdigest()
                for t in archive if t.isfile()}

def normalize(path,epoch):
    original=members(path.read_bytes());assert original.pop('debian-binary')==b'2.0\n'
    assert len(original)==2 and list(original)[0].startswith('control.tar.') and list(original)[1].startswith('data.tar.'), 'unexpected Debian archive members'
    result={'debian-binary':b'2.0\n'}
    for kind in ['control','data']:
        names=[k for k in original if k.startswith(kind+'.tar')];assert len(names)==1
        old=original[names[0]];buffer=io.BytesIO()
        with open_tar(old,names[0]) as source, \
             tarfile.open(fileobj=buffer,mode='w',format=tarfile.USTAR_FORMAT) as target:
            seen=set()
            for item in source:
                canonical=str(pathlib.PurePosixPath(item.name))
                assert canonical not in seen, 'duplicate normalized path'
                seen.add(canonical)
                assert item.isfile() or item.isdir(), 'unexpected tar object'
                assert not item.name.startswith('/') and '..' not in pathlib.PurePosixPath(item.name).parts
                stream=source.extractfile(item) if item.isfile() else None
                item.uid=item.gid=0;item.uname=item.gname='root';item.mtime=epoch;item.pax_headers={}
                target.addfile(item,stream)
        encoded=lzma.compress(buffer.getvalue(),format=lzma.FORMAT_XZ)
        assert payloads(old,names[0])==payloads(encoded,kind+'.tar.xz'),'payload bytes changed during normalization'
        result[kind+'.tar.xz']=encoded
    data=bytearray(b'!<arch>\n')
    for name,blob in result.items():
        header=f'{name+"/":<16}{epoch:<12}{0:<6}{0:<6}{"100644":<8}{len(blob):<10}`\n'.encode()
        assert len(header)==60;data+=header+blob
        if len(blob)%2:data+=b'\n'
    staged=path.with_suffix('.normalized.deb');staged.write_bytes(data);staged.replace(path)
    print('archive normalization: uid=0 gid=0; all file payload SHA-256 unchanged PASS')
if __name__=='__main__':normalize(pathlib.Path(sys.argv[1]),int(sys.argv[2]))
