#ifndef PCR_BUILD_GUARD_H
#define PCR_BUILD_GUARD_H
// Production releases use the same Apple Xcode ABI as the target system.
// A versioned Mach-O subtype alone does not prove pointer-authentication codegen.
#if !defined(__apple_build_version__)
#error "Release requires Apple Xcode clang; upstream Linux clang is not qualified"
#endif
#if !defined(__arm64e__)
#error "Release requires arm64e"
#endif
#if !__has_feature(ptrauth_calls) || !__has_feature(ptrauth_returns) || !__has_feature(ptrauth_intrinsics)
#error "Release requires pointer-authentication calls, returns and intrinsics"
#endif
#endif
