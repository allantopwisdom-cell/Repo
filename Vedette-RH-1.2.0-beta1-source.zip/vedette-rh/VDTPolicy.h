// GPL-3.0-or-later. Development fork, 2026.
#ifndef VDT_POLICY_H
#define VDT_POLICY_H
#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>
#ifdef __cplusplus
extern "C" {
#endif
typedef enum { VDTNone=0, VDTMonitor=1, VDTTerminate=2, VDTThrottle=3 } VDTMode;
typedef enum { VDTIdle, VDTKeep, VDTRestore, VDTApply } VDTAction;
VDTAction vdt_next_action(bool has_old, bool same_rule, bool enabled, bool dry_run, bool recovery, bool has_desired);
bool vdt_parse_integer(const char *text, int minimum, int maximum, int *result);
bool vdt_valid_rule(int mode, int percentage, int interval);
bool vdt_protected_name(const char *name);
// proc_listpids returns bytes; never read beyond either returned bytes or allocation.
size_t vdt_pid_count(int bytes, size_t capacity_bytes);
#ifdef __cplusplus
}
#endif
#endif
