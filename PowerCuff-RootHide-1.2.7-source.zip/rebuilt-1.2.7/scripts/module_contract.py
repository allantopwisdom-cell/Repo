"""Independent project discovery/settings/resource contract, used before and after build."""
import struct,zlib
from package_format import plist_equal
DOMAIN='com.dao.powercuff'
NOTIFICATION=DOMAIN+'.settingschanged'
TITLES=['关闭','正常（仍在模拟）','轻度','适中','重度']
def validate_module(info,version):
    expected={'CFBundleIdentifier':'com.dao.powercuff.ccmodule','CFBundleExecutable':'PowercuffCC',
              'NSPrincipalClass':'PowercuffCCModule','CFBundlePackageType':'BNDL',
              'MinimumOSVersion':'16.0','CFBundleSupportedPlatforms':['iPhoneOS'],
              'CFBundleShortVersionString':version,'CFBundleVersion':'127',
              'UIDeviceFamily':[1,2],'CCSGetModuleSizeAtRuntime':False,
              'CCSModuleSize':{'Portrait':{'Width':1,'Height':1},'Landscape':{'Width':1,'Height':1}}}
    for key,value in expected.items():
        assert key in info and plist_equal(info[key],value), 'module discovery contract: '+key

def validate_preferences(panel):
    items=panel.get('items');assert type(items) is list, 'settings contract: items'
    keyed=[x for x in items if 'key' in x]
    assert len(keyed)==2 and {x['key'] for x in keyed}=={'PowerMode','RequireLowPowerMode'}, 'settings contract: keys'
    for item in keyed:
        assert item.get('defaults')==DOMAIN, 'settings contract: domain'
        assert item.get('PostNotification')==NOTIFICATION, 'settings contract: notification'
    mode=next(x for x in keyed if x['key']=='PowerMode')
    gate=next(x for x in keyed if x['key']=='RequireLowPowerMode')
    assert mode.get('cell')=='PSLinkListCell' and mode.get('detail')=='PSListItemsController', 'settings contract: mode cell'
    assert plist_equal(mode.get('validValues'),list(range(5))) and mode.get('validTitles')==TITLES, 'settings contract: profiles'
    assert plist_equal(mode.get('default'),0), 'settings contract: mode default'
    assert gate.get('cell')=='PSSwitchCell' and gate.get('default') is False, 'settings contract: gate default'

def validate_png(data,dimensions):
    assert len(data)<=1024*1024 and data[:8]==b'\x89PNG\r\n\x1a\n', 'PNG signature/limit'
    pos=8;chunks=[];compressed=bytearray();ended=False
    while pos<len(data):
        assert pos+12<=len(data), 'PNG chunk bounds'
        n=struct.unpack_from('>I',data,pos)[0];kind=data[pos+4:pos+8];end=pos+12+n
        assert end<=len(data), 'PNG chunk bounds'
        body=data[pos+8:pos+8+n]
        assert zlib.crc32(kind+body)&0xffffffff==struct.unpack_from('>I',data,end-4)[0], 'PNG CRC'
        if not chunks:assert kind==b'IHDR' and n==13, 'PNG IHDR'
        if kind==b'IHDR':
            assert not chunks, 'PNG duplicate IHDR'
            w,h,depth,color,compression,filtering,interlace=struct.unpack('>IIBBBBB',body)
            assert (w,h)==dimensions and (depth,color,compression,filtering,interlace)==(8,6,0,0,0), 'PNG dimensions/format'
        if kind==b'IDAT':compressed.extend(body)
        if kind==b'IEND':
            assert n==0 and end==len(data), 'PNG IEND/trailer'
            ended=True;break
        chunks.append(kind);pos=end
    assert ended and compressed, 'PNG missing image/end'
    expected=dimensions[1]*(1+4*dimensions[0]);d=zlib.decompressobj()
    try:raw=d.decompress(compressed,expected+1)
    except zlib.error as e:raise AssertionError('PNG image stream') from e
    assert len(raw)==expected and d.eof and not d.unused_data and not d.unconsumed_tail, 'PNG image stream bounds'
    assert all(raw[y*(1+4*dimensions[0])]<=4 for y in range(dimensions[1])), 'PNG scanline filter'
