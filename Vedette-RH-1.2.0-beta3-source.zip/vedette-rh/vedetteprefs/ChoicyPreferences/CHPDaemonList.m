// Copyright (c) 2019-2021 Lars Fröder

// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:

// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.

// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.

#import "CHPDaemonList.h"
#import "CHPDaemonInfo.h"
#import "../../VDTValidation.h"

#import <dirent.h>

@implementation CHPDaemonList
@synthesize loaded=_loaded, loading=_loading, daemonList=_daemonList;
- (BOOL)loaded { @synchronized(self){return _loaded;} }
- (BOOL)loading { @synchronized(self){return _loading;} }
- (NSArray *)daemonList { @synchronized(self){return _daemonList;} }

+ (instancetype)sharedInstance
{
	static CHPDaemonList* sharedInstance = nil;
	static dispatch_once_t onceToken;
	dispatch_once(&onceToken, ^
	{
		//Initialise instance
		sharedInstance = [[CHPDaemonList alloc] init];
	});
	return sharedInstance;
}

- (instancetype)init
{
	self = [super init];

    if(!self)return nil;
	_observers = [NSHashTable weakObjectsHashTable];

	return self;
}

- (BOOL)daemonList:(NSArray*)daemonList containsDisplayName:(NSString*)displayName
{
	for(CHPDaemonInfo* info in daemonList)
	{
		if([info.displayName isEqualToString:displayName])
		{
			return YES;
		}
	}

	return NO;
}

- (void)updateDaemonListIfNeeded
{
    @synchronized(self){if(_loaded || _loading)return;_loading=YES;}

	NSMutableArray<NSURL*>* daemonPlists = [[[NSFileManager defaultManager] contentsOfDirectoryAtURL:[NSURL fileURLWithPath:@"/System/Library/LaunchDaemons"] includingPropertiesForKeys:nil options:0 error:nil] mutableCopy] ?: [NSMutableArray array];

	[daemonPlists addObjectsFromArray:[[NSFileManager defaultManager] contentsOfDirectoryAtURL:[NSURL fileURLWithPath:@"/System/Library/NanoLaunchDaemons"] includingPropertiesForKeys:nil options:0 error:nil] ?: @[]];

	[daemonPlists addObjectsFromArray:[[NSFileManager defaultManager] contentsOfDirectoryAtURL:[NSURL fileURLWithPath:jbroot(@"/Library/LaunchDaemons")] includingPropertiesForKeys:nil options:0 error:nil] ?: @[]];

	for(NSURL* daemonPlistURL in [daemonPlists copy])
	{
		if(![daemonPlistURL.pathExtension isEqualToString:@"plist"])
		{
			[daemonPlists removeObject:daemonPlistURL];
		}
	}

	NSMutableArray* daemonListM = [NSMutableArray new];

	for(NSURL* daemonPlistURL in daemonPlists)
	{
		NSDictionary* daemonDictionary = [NSDictionary dictionaryWithContentsOfURL:daemonPlistURL];
        if(![daemonDictionary isKindOfClass:NSDictionary.class])continue;
		
		CHPDaemonInfo* info = [[CHPDaemonInfo alloc] init];

        id program=daemonDictionary[@"Program"];
        info.executablePath=[program isKindOfClass:NSString.class]?program:nil;

		if(!info.executablePath)
		{
			NSArray* programArguments = [daemonDictionary objectForKey:@"ProgramArguments"];
			if([programArguments isKindOfClass:NSArray.class] && programArguments.count>0 && [programArguments.firstObject isKindOfClass:NSString.class])
			{
				info.executablePath = programArguments.firstObject;
			}
		}

        if(!VDTAbsolutePath(info.executablePath))continue;
        NSString *jailbreakDaemonDirectory=jbroot(@"/Library/LaunchDaemons/");
        if([daemonPlistURL.path hasPrefix:jailbreakDaemonDirectory]) {
            NSString *mapped=jbroot(info.executablePath);
            if([[NSFileManager defaultManager] fileExistsAtPath:mapped])info.executablePath=mapped;
        }
        info.executablePath=[info.executablePath stringByResolvingSymlinksInPath];
		info.plistIdentifier = [daemonPlistURL lastPathComponent].stringByDeletingPathExtension;

		if(info.executablePath && [[NSFileManager defaultManager] fileExistsAtPath:info.executablePath] && ![info.plistIdentifier hasSuffix:@"Jetsam"] && ![info.plistIdentifier hasSuffix:@"SimulateCrash"] && ![info.plistIdentifier hasSuffix:@"_v2"] && ![info.plistIdentifier isEqualToString:@"com.apple.SpringBoard"]) //Filter out some useless entries
		{
			if(![self daemonList:daemonListM containsDisplayName:info.displayName])
			{
				[daemonListM addObject:info];
			}
		}
	}

	NSDirectoryEnumerator* systemLibraryFrameworksEnumerator = [[NSFileManager defaultManager] enumeratorAtURL:[NSURL fileURLWithPath:@"/System/Library/Frameworks" isDirectory:YES] includingPropertiesForKeys:nil options:0 errorHandler:^(NSURL *url, NSError *error)
	{
		return YES;
	}];

	NSDirectoryEnumerator* systemLibraryPrivateFrameworksEnumerator = [[NSFileManager defaultManager] enumeratorAtURL:[NSURL fileURLWithPath:@"/System/Library/PrivateFrameworks" isDirectory:YES] includingPropertiesForKeys:nil options:0 errorHandler:^(NSURL *url, NSError *error)
	{
		return YES;
	}];

	NSMutableArray* XPCUrls = [NSMutableArray new];

	for(NSURL* fileURL in systemLibraryFrameworksEnumerator)
	{
		if([fileURL.path hasSuffix:@".xpc"])
		{
			[XPCUrls addObject:fileURL];[systemLibraryFrameworksEnumerator skipDescendants];
		}
	}

	for(NSURL* fileURL in systemLibraryPrivateFrameworksEnumerator)
	{
		if([fileURL.path hasSuffix:@".xpc"])
		{
			[XPCUrls addObject:fileURL];[systemLibraryPrivateFrameworksEnumerator skipDescendants];
		}
	}

	for(NSURL* XPCUrl in XPCUrls)
	{
		NSString* XPCPath = XPCUrl.path;

		NSString* XPCName = [XPCUrl.lastPathComponent stringByReplacingOccurrencesOfString:@".xpc" withString:@""];

        NSDictionary *infoDictionary=[NSDictionary dictionaryWithContentsOfFile:[XPCPath stringByAppendingPathComponent:@"Info.plist"]];
        NSString *executable=[infoDictionary[@"CFBundleExecutable"] isKindOfClass:NSString.class]?infoDictionary[@"CFBundleExecutable"]:XPCName;
        if(!VDTIdentifier(executable))continue;
		NSString* XPCExecutablePath = [XPCPath stringByAppendingPathComponent:executable];

		if([[NSFileManager defaultManager] fileExistsAtPath:XPCExecutablePath])
		{
			CHPDaemonInfo* info = [[CHPDaemonInfo alloc] init];
			info.executablePath = XPCExecutablePath;

			if(![self daemonList:daemonListM containsDisplayName:info.displayName])
			{
				[daemonListM addObject:info];
			}
		}
	}

	NSMutableArray* additionalPotentialDaemons = [NSMutableArray new];

	// On A12 unc0ver, using contentsOfDirectoryAtURL on /usr/libexec locks the thread and leaves a kernel thread looping
	// This causes all sorts of issues and heats the device up
	// This has been fixed in unc0ver 4.0, but we still use the old solution because some people might not be updated to 4.0
	// The C API is not affected by this issue, so we just use it instead
	DIR *dir;
    struct dirent* dp;
    dir = opendir("/usr/libexec");
    while (dir && (dp=readdir(dir)) != NULL)
	{
        if (!(!strcmp(dp->d_name, ".") || !strcmp(dp->d_name, "..")))
        {
            NSString* filename = [NSString stringWithCString:dp->d_name encoding:NSUTF8StringEncoding];
            if(filename)
			{
				NSURL* URL = [NSURL fileURLWithPath:[@"/usr/libexec" stringByAppendingPathComponent:filename]];
				HBLogDebug(@"added %@", URL);
				[additionalPotentialDaemons addObject:URL];
			}
        }
    }
    if (dir) closedir(dir);

	/*[additionalPotentialDaemons addObjectsFromArray:[[NSFileManager defaultManager] contentsOfDirectoryAtURL:[NSURL fileURLWithPath:@"/usr/libexec" isDirectory:YES] 
                    includingPropertiesForKeys:nil 
                                       options:0 
                                         error:nil] ?: @[]];*/
	
	[additionalPotentialDaemons addObjectsFromArray:[[NSFileManager defaultManager] contentsOfDirectoryAtURL:[NSURL fileURLWithPath:@"/usr/bin" isDirectory:YES] 
                    includingPropertiesForKeys:nil 
                                       options:0 
                                         error:nil] ?: @[]];
	
	[additionalPotentialDaemons addObjectsFromArray:[[NSFileManager defaultManager] contentsOfDirectoryAtURL:[NSURL fileURLWithPath:@"/usr/sbin" isDirectory:YES] 
                    includingPropertiesForKeys:nil 
                                       options:0 
                                         error:nil] ?: @[]];
	

	for(NSURL* URL in additionalPotentialDaemons)
	{
		if([URL.lastPathComponent hasSuffix:@"d"])
		{
			CHPDaemonInfo* info = [[CHPDaemonInfo alloc] init];
			info.executablePath = [URL path];

			if(![self daemonList:daemonListM containsDisplayName:info.displayName])
			{
				[daemonListM addObject:info];
			}
		}
	}

	[daemonListM sortUsingComparator:^NSComparisonResult(CHPDaemonInfo* a, CHPDaemonInfo* b)  //Sort alphabetically
	{
		return [[a displayName] localizedCaseInsensitiveCompare:[b displayName]];
	}];

    @synchronized(self){_daemonList=[daemonListM copy];_loading=NO;_loaded=YES;}

	[self sendReloadToObservers];
}

- (void)addObserver:(id<CHPDaemonListObserver>)observer {
    if(!observer)return;@synchronized(self){[_observers addObject:observer];}
}
- (void)removeObserver:(id<CHPDaemonListObserver>)observer {
    if(!observer)return;@synchronized(self){[_observers removeObject:observer];}
}
- (void)sendReloadToObservers {
    dispatch_async(dispatch_get_main_queue(),^{
        NSArray *observers;@synchronized(self){observers=_observers.allObjects;}
        for(id<CHPDaemonListObserver> observer in observers)[observer daemonListDidUpdate:self];
    });
}
@end
