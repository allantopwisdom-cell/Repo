// Original code Copyright (c) 2021 udevs. GPLv3; development changes 2026.
#import <Foundation/Foundation.h>
#import <HBLog.h>
#import <objc/runtime.h>
#import <roothide.h>
#define VEDETTE_IDENTIFIER @"com.udevs.vedette"
// Shared mobile preferences remain outside the relocated package root.
#define PREFS_PATH @"/var/mobile/Library/Preferences/com.udevs.vedette.plist"
#define PREFS_PATH_TMP @"/var/tmp/com.udevs.vedette.plist"
#define PREFS_CHANGED_NN @"com.udevs.vedette.prefschanged"
#define RESTORE_ALL_MONITORS_NN @"com.udevs.vedette.restore-all-monitors"
#define VDT_RUNTIME_PATH @"/var/mobile/Library/Preferences/com.udevs.vedette.runtime.plist"
#define VDT_STATUS_PATH @"/var/mobile/Library/Preferences/com.udevs.vedette.status.plist"
