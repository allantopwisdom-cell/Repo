#!/bin/sh
set -eu
[ "$#" -eq 1 ] || { echo 'Usage: verify_deb.sh package.deb' >&2; exit 2; }
command -v dpkg-deb >/dev/null
package=$1
[ "$(dpkg-deb -f "$package" Package)" = com.udevs.vedette.rhdev ]
[ "$(dpkg-deb -f "$package" Version)" = '1.2.0~beta3' ]
[ "$(dpkg-deb -f "$package" Architecture)" = iphoneos-arm64e ]
work=$(mktemp -d)
trap 'rm -rf "$work"' EXIT HUP INT TERM
dpkg-deb -x "$package" "$work"
find "$work" -name Vedette.dylib | while IFS= read -r file; do
  command -v file >/dev/null && file "$file"
done
# Assert the packaged controller and settings resources actually exist.
[ "$(find "$work" -name Vedette.dylib -type f | wc -l | tr -d ' ')" -eq 1 ]
[ "$(find "$work" -path '*/PreferenceBundles/VedettePrefs.bundle/VedettePrefs' -type f | wc -l | tr -d ' ')" -eq 1 ]
[ "$(find "$work" -path '*/PreferenceLoader/Preferences/VedettePrefs.plist' -type f | wc -l | tr -d ' ')" -eq 1 ]
printf '%s\n' 'PASS: package identity and required payload files. This does not verify signatures, Mach-O ABI, runtime permissions or effects.'

python3 - "$package" <<'PYVERIFY'
import io, subprocess, sys, tarfile
for option in ('--ctrl-tarfile','--fsys-tarfile'):
    archive=tarfile.open(fileobj=io.BytesIO(subprocess.check_output(['dpkg-deb',option,sys.argv[1]])))
    for member in archive:
        assert member.uid==0 and member.gid==0, (member.name,member.uid,member.gid)
        if member.name.lstrip('./') in ('postinst','prerm','postrm'):
            assert member.mode & 0o111, member.name
print('PASS: all archive entries use numeric uid/gid 0/0; maintainer scripts executable')
PYVERIFY

python3 "$(dirname "$0")/verify_package.py" "$package"
