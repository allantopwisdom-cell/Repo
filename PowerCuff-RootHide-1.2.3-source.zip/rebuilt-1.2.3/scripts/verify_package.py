#!/usr/bin/env python3
"""Validate this rebuilt package, all Mach-O slices and CodeDirectory code pages.
No certificate-chain, device PAC, entitlements-policy or runtime verification is claimed.
"""
import hashlib,json,pathlib,plistlib,struct,subprocess,sys,tempfile
if not __debug__: raise RuntimeError('do not run verification with -O')
def check_signature(b,off,size):
    blob=b[off:off+size];magic,length,count=struct.unpack_from('>III',blob)
    assert magic==0xfade0cc0 and length<=size and 12+8*count<=length
    result=[]
    for i in range(count):
        slot,start=struct.unpack_from('>II',blob,12+8*i)
        kind,ln=struct.unpack_from('>II',blob,start)
        assert start+ln<=length
        if kind!=0xfade0c02: continue
        cd=blob[start:start+ln]
        ver,flags,hoff,ident,special,n,limit=struct.unpack_from('>IIIIIII',cd,8)
        hs,ht,platform,pg=struct.unpack_from('>BBBB',cd,36)
        algorithm={1:'sha1',2:'sha256',3:'sha256',4:'sha384'}[ht]
        page=(1<<pg) if pg else limit
        assert page and limit==off and n==(limit+page-1)//page
        assert hoff+n*hs<=len(cd)
        for j in range(n):
            digest=hashlib.new(algorithm,b[j*page:min((j+1)*page,limit)]).digest()[:hs]
            assert digest==cd[hoff+j*hs:hoff+(j+1)*hs],f'code page hash mismatch {j}'
        result.append({'slot':slot,'code_pages':n,'hash_type':ht,'code_pages_valid':True})
    assert result
    return result

def inspect(path):
    data=path.read_bytes();slices=[]
    if data[:4]==b'\xca\xfe\xba\xbe':
        for i in range(struct.unpack_from('>I',data,4)[0]):
            _,_,off,size,_=struct.unpack_from('>IIIII',data,8+20*i);slices.append(data[off:off+size])
    else:slices=[data]
    results=[]
    for b in slices:
        magic,cpu,sub,filetype,n,sz,flags,reserved=struct.unpack_from('<8I',b)
        assert magic==0xfeedfacf and cpu==0x100000c and sub==0x80000002, 'expected versioned arm64e'
        pos=32;loads=[];sig=None;minimum=None
        for _ in range(n):
            c,z=struct.unpack_from('<II',b,pos);assert z>=8 and pos+z<=32+sz
            if c in [0xc,0x80000018]:
                no=struct.unpack_from('<I',b,pos+8)[0]
                loads.append(b[pos+no:pos+z].split(b'\0')[0].decode())
            if c==0x32:
                platform,minimum,sdk=struct.unpack_from('<III',b,pos+8);assert platform==2
            if c==0x1d:sig=struct.unpack_from('<II',b,pos+8)
            if c in [0x21,0x2c]:assert struct.unpack_from('<I',b,pos+16)[0]==0, 'encrypted binary'
            pos+=z
        assert minimum == 0x100000, 'expected iOS 16.0 deployment target'
        assert sig is not None
        if path.name=='PowercuffRebuilt.dylib':
            assert '@loader_path/.jbroot/usr/lib/libsubstrate.dylib' in loads
            assert not any('/var/jb/' in x for x in loads)
        results.append({'subtype':hex(sub),'minimum':hex(minimum),'dependencies':loads,
                        'sha256':hashlib.sha256(b).hexdigest(),'signature':check_signature(b,*sig)})
    return results

def verify(deb):
    fields=subprocess.check_output(['dpkg-deb','-f',str(deb)]).decode()
    assert 'Package: com.powercuff.roothide\n' in fields and 'Version: 1.2.3\n' in fields
    assert 'Architecture: iphoneos-arm64e\n' in fields
    result={'package':deb.name,'sha256':hashlib.sha256(deb.read_bytes()).hexdigest(),'binaries':{}}
    with tempfile.TemporaryDirectory() as tmp:
        root=pathlib.Path(tmp);subprocess.run(['dpkg-deb','-x',str(deb),str(root)],check=True)
        for suffix in ['Library/MobileSubstrate/DynamicLibraries/PowercuffRebuilt.dylib',
                       'Library/ControlCenter/Bundles/PowercuffCC.bundle/PowercuffCC','usr/bin/pcctl']:
            matches=[p for p in root.rglob(pathlib.Path(suffix).name) if str(p).endswith(suffix)]
            assert len(matches)==1, f'missing or duplicate binary {suffix}'
            result['binaries'][suffix]=inspect(matches[0])
        filters=list(root.rglob('PowercuffRebuilt.plist'));assert len(filters)==1
        assert plistlib.loads(filters[0].read_bytes())=={'Filter':{'Executables':['thermalmonitord','SpringBoard']}}
        infos=list(root.rglob('Info.plist'));assert len(infos)==1
        info=plistlib.loads(infos[0].read_bytes());assert info['CFBundleShortVersionString']=='1.2.3'
        assert info['NSPrincipalClass']=='PowercuffCCModule'
        prefs=[p for p in root.rglob('Powercuff.plist') if 'PreferenceLoader' in p.parts];assert len(prefs)==1
        items=plistlib.loads(prefs[0].read_bytes())['items']
        keys={x['key'] for x in items if 'key' in x};assert keys=={'PowerMode','RequireLowPowerMode'}
        for x in items:
            if 'key' in x:assert x['defaults']=='com.dao.powercuff'
    return result
if __name__=='__main__':
    print(json.dumps(verify(pathlib.Path(sys.argv[1]).resolve()),ensure_ascii=False,indent=2))
