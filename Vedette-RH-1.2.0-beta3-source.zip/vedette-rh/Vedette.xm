// Original project Copyright (c) 2021 udevs; rewritten controller, GPLv3.
#import "VDTProcessManager.h"
#import "VDTShared.h"
#include <notify.h>
#include <sys/sysctl.h>
#include <sys/utsname.h>
static dispatch_queue_t controllerQueue;
static dispatch_source_t discoveryTimer;
static int prefsToken=-1,resetToken=-1;
static BOOL controllerReady;
static void reconcile(void) { if(!controllerReady)return;@autoreleasepool { VDTReconcile(getPrefs()); } }
%ctor {
    @autoreleasepool {
        if (![[NSProcessInfo processInfo].processName isEqualToString:@"runningboardd"])return;
        struct utsname systemInfo={};
        char build[64]={0};size_t length=sizeof(build);
        if(uname(&systemInfo)!=0 || sysctlbyname("kern.osversion",build,&length,NULL,0)!=0 ||
           strcmp(build,"20F66") || strcmp(systemInfo.machine,"iPhone15,3")) {
            NSLog(@"[Vedette RH] unsupported target; controller inactive");return;
        }
        controllerQueue=dispatch_queue_create("com.udevs.vedette.controller",DISPATCH_QUEUE_SERIAL);
        if(!controllerQueue){NSLog(@"[Vedette RH] controller queue unavailable");return;}
        int prefsResult=notify_register_dispatch("com.udevs.vedette.prefschanged",&prefsToken,controllerQueue,^(int token){(void)token;reconcile();});
        int resetResult=notify_register_dispatch("com.udevs.vedette.restore-all-monitors",&resetToken,controllerQueue,^(int token){(void)token;reconcile();});
        discoveryTimer=dispatch_source_create(DISPATCH_SOURCE_TYPE_TIMER,0,0,controllerQueue);
        BOOL notifications=(prefsResult==NOTIFY_STATUS_OK && resetResult==NOTIFY_STATUS_OK);
        BOOL timerAvailable=discoveryTimer!=nil;
        dispatch_async(controllerQueue,^{
            VDTSetControllerHealth(notifications,timerAvailable);controllerReady=timerAvailable;
            if(timerAvailable)reconcile();else VDTReconcile(@{@"enabled":@NO,@"dryRun":@YES});
        });
        if(!discoveryTimer) {
            if(prefsResult==NOTIFY_STATUS_OK)notify_cancel(prefsToken);
            if(resetResult==NOTIFY_STATUS_OK)notify_cancel(resetToken);
            NSLog(@"[Vedette RH] discovery timer unavailable; new policies disabled");return;
        }
        // Notifications are an optimization; bounded PID discovery also reloads settings.
        dispatch_source_set_timer(discoveryTimer,dispatch_time(DISPATCH_TIME_NOW,30*NSEC_PER_SEC),30*NSEC_PER_SEC,5*NSEC_PER_SEC);
        dispatch_source_set_event_handler(discoveryTimer,^{reconcile();});
        dispatch_resume(discoveryTimer);
    }
}
