#pragma once
#include <stdint.h>
static inline unsigned PCModeFromDouble(double value) {
    /* NaN, infinity, fractions and out-of-range values all fail closed. */
    if (!(value >= 0.0 && value <= 4.0)) return 0;
    unsigned mode = (unsigned)value;
    return (double)mode == value ? mode : 0;
}
static inline unsigned PCEffectiveMode(unsigned mode, int requireLowPower, int lowPower) {
    if (mode > 4 || (requireLowPower && !lowPower)) return 0;
    return mode;
}
