// Derived from rpetrich/Powercuff and Mikasa-san/Powercuff.
#import <Foundation/Foundation.h>
#import <CoreFoundation/CoreFoundation.h>
#import <objc/runtime.h>
#import <notify.h>
#import <math.h>
#import <string.h>
#import "Policy.h"

@interface CommonProduct : NSObject
- (void)putDeviceInThermalSimulationMode:(NSString *)mode;
@end

static const char *const PCStateName = "com.rpetrich.powercuff.thermals";
static const char *const PCSettingsName = "com.rpetrich.powercuff.settingschanged";
static const char *const PCRequestName = "com.powercuff.roothide.requeststate";
static int stateToken = -1;
static int eventToken = -1;
static int settingsToken = -1;
static int requestToken = -1;
// All collection access and thermal application occur on the main queue.
// Weak keys neither keep daemon products alive nor leave dangling pointers.
static NSHashTable<CommonProduct *> *products;
static NSMapTable<CommonProduct *, NSNumber *> *appliedModes;
static BOOL applyFailed;
static id lowPowerObserver;

static NSString *PCModeString(unsigned mode) {
    switch (mode) {
        case 1: return @"nominal";
        case 2: return @"light";
        case 3: return @"moderate";
        case 4: return @"heavy";
        default: return @"off";
    }
}

static void PCApply(void) {
    if (applyFailed) return;
    uint64_t state = 0;
    if (stateToken < 0 || notify_get_state(stateToken, &state) != NOTIFY_STATUS_OK)
        state = 0;
    unsigned mode = state <= 4 ? (unsigned)state : 0;
    for (CommonProduct *product in products.allObjects) {
        NSNumber *previous = [appliedModes objectForKey:product];
        if (previous && previous.unsignedIntValue == mode) continue;
        @try {
            [product putDeviceInThermalSimulationMode:PCModeString(mode)];
            [appliedModes setObject:@(mode) forKey:product];
        } @catch (NSException *exception) {
            // Do not repeatedly invoke an incompatible private interface.
            applyFailed = YES;
            NSLog(@"[Powercuff] Thermal application failed: %@. Disable the tweak and restart thermalmonitord.", exception.name);
            break;
        }
    }
}

static BOOL PCIsNumber(id value) {
    return [value isKindOfClass:NSNumber.class] &&
        CFGetTypeID((__bridge CFTypeRef)value) != CFBooleanGetTypeID();
}

static void PCLoadSettings(void) {
    // This function runs ONLY in SpringBoard (mobile user), never in root daemon.
    Boolean synchronized = CFPreferencesAppSynchronize(CFSTR("com.rpetrich.powercuff"));
    id rawMode = CFBridgingRelease(CFPreferencesCopyAppValue(CFSTR("PowerMode"), CFSTR("com.rpetrich.powercuff")));
    id rawRequire = CFBridgingRelease(CFPreferencesCopyAppValue(CFSTR("RequireLowPowerMode"), CFSTR("com.rpetrich.powercuff")));
    unsigned mode = PCIsNumber(rawMode) ? PCModeFromDouble([rawMode doubleValue]) : 0;
    BOOL requireValid = !rawRequire || ([rawRequire isKindOfClass:NSNumber.class] &&
        ([rawRequire doubleValue] == 0.0 || [rawRequire doubleValue] == 1.0));
    if (!synchronized || !requireValid) mode = 0;
    mode = PCEffectiveMode(mode, [rawRequire isKindOfClass:NSNumber.class] && [rawRequire boolValue],
                           NSProcessInfo.processInfo.lowPowerModeEnabled);
    if (stateToken < 0 || notify_set_state(stateToken, mode) != NOTIFY_STATUS_OK) {
        NSLog(@"[Powercuff] Cannot publish thermal state.");
        return;
    }
    if (notify_post(PCStateName) != NOTIFY_STATUS_OK)
        NSLog(@"[Powercuff] Cannot notify thermal state change.");
}

static BOOL PCCheckProductABI(Class cls) {
    Method init = class_getInstanceMethod(cls, @selector(initProduct:));
    Method apply = class_getInstanceMethod(cls, @selector(putDeviceInThermalSimulationMode:));
    if (!init || !apply || method_getNumberOfArguments(init) != 3 || method_getNumberOfArguments(apply) != 3)
        return NO;
    char result[32] = {0}, arg[32] = {0}, initResult[32] = {0}, initArg[32] = {0};
    method_getReturnType(apply, result, sizeof(result));
    method_getArgumentType(apply, 2, arg, sizeof(arg));
    method_getReturnType(init, initResult, sizeof(initResult));
    method_getArgumentType(init, 2, initArg, sizeof(initArg));
    return result[0] == 'v' && arg[0] == '@' && initResult[0] == '@' && initArg[0] == '@';
}

%group Thermal
%hook CommonProduct
- (id)initProduct:(id)data {
    id product = %orig(data);
    if (product) {
        __weak CommonProduct *weakProduct = product;
        dispatch_async(dispatch_get_main_queue(), ^{
            CommonProduct *liveProduct = weakProduct;
            if (liveProduct) {
                [products addObject:liveProduct];
                PCApply();
            }
        });
    }
    return product;
}
%end
%end

%ctor {
    @autoreleasepool {
        NSString *process = NSProcessInfo.processInfo.processName;
        BOOL thermal = [process isEqualToString:@"thermalmonitord"];
        BOOL springboard = [process isEqualToString:@"SpringBoard"];
        if (!thermal && !springboard) return;
        if (notify_register_check(PCStateName, &stateToken) != NOTIFY_STATUS_OK) {
            stateToken = -1;
            NSLog(@"[Powercuff] State registration failed; tweak remains inactive.");
            return;
        }
        if (thermal) {
            Class productClass = NSClassFromString(@"CommonProduct");
            if (!PCCheckProductABI(productClass)) {
                NSLog(@"[Powercuff] Unsupported CommonProduct ABI; no thermal hook installed.");
                return;
            }
            products = [NSHashTable weakObjectsHashTable];
            appliedModes = [NSMapTable weakToStrongObjectsMapTable];
            if (notify_register_dispatch(PCStateName, &eventToken, dispatch_get_main_queue(), ^(int t) {
                (void)t;
                PCApply();
            }) != NOTIFY_STATUS_OK) {
                NSLog(@"[Powercuff] Thermal event registration failed; no hook installed.");
                return;
            }
            %init(Thermal, CommonProduct = productClass);
            // Ask the mobile process to republish after daemon restart.
            notify_post(PCRequestName);
        } else {
            if (notify_register_dispatch(PCSettingsName, &settingsToken, dispatch_get_main_queue(), ^(int t) {
                (void)t;
                PCLoadSettings();
            }) != NOTIFY_STATUS_OK) {
                NSLog(@"[Powercuff] Settings registration failed.");
                return;
            }
            if (notify_register_dispatch(PCRequestName, &requestToken, dispatch_get_main_queue(), ^(int t) {
                (void)t;
                PCLoadSettings();
            }) != NOTIFY_STATUS_OK) {
                NSLog(@"[Powercuff] State request registration failed.");
            }
            lowPowerObserver = [NSNotificationCenter.defaultCenter addObserverForName:NSProcessInfoPowerStateDidChangeNotification
                object:nil queue:NSOperationQueue.mainQueue usingBlock:^(NSNotification *note) {
                    (void)note;
                    PCLoadSettings();
                }];
            dispatch_async(dispatch_get_main_queue(), ^{ PCLoadSettings(); });
        }
    }
}
