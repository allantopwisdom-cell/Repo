# 构建/验收状态的权威依据

源码文档不预先记录云端构建成功。请使用与本SOURCE-SHA256.json一致的源码ZIP、固定工作流、实际提交和BUILD-LOG.txt确认构建结果；以对应最终DEB的verification.json、negative-tests.txt和下载后复核报告作为包验收依据。

LOCAL-VALIDATION.txt只记录源码封存前的Linux主机检查。Foundation、真实生产核心/CLI主函数测试须在macOS执行；设备私有API、控制中心界面、RootHide注入、watchdog与续航必须另外实测。既往版本测试不替代本版测试。

目标iPhone15,3 / iOS16.5 / RootHide Dopamine3.0.4。独立测试优先，不能据此承诺与Hello CPU联用安全或固定1428MHz。
