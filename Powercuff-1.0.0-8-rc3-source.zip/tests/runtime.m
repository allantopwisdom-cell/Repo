#import <Foundation/Foundation.h>
#import <assert.h>
#import "../Protocol.h"
#import "../Runtime.h"
@interface CommonProduct : NSObject
@property unsigned calls;
@property unsigned mode;
@property BOOL shouldThrow;
@property(copy) void (^onApply)(void);
- (id)initProduct:(id)data;
- (void)putDeviceInThermalSimulationMode:(NSString *)mode;
@end
@implementation CommonProduct
- (id)initProduct:(id)data { (void)data; return self; }
- (BOOL)isEqual:(id)other { return [other isKindOfClass:CommonProduct.class]; }
- (NSUInteger)hash { return 1; }
- (void)putDeviceInThermalSimulationMode:(NSString *)mode {
    self.calls++;
    if(self.shouldThrow) [NSException raise:@"FixtureFailure" format:@"simulated"];
    self.mode=(unsigned)[@[@"off",@"nominal",@"light",@"moderate",@"heavy"] indexOfObject:mode];
    if (self.onApply) self.onApply();
}
@end
static BOOL active, applying, applyPending;
static unsigned deferredCount;
static void PCDeferApply(void) { ++deferredCount; }
static PCSession session;
static NSHashTable<CommonProduct *> *products;
static NSMapTable<CommonProduct *,NSNumber *> *applied,*failures;
static unsigned lastStatus;
static void PCReport(unsigned code) { lastStatus=code; }
// ACTUAL_PRODUCTION_FUNCTIONS
static void TestApply(void) { @autoreleasepool { PCApply(); } }
int main(void) { @autoreleasepool {
    NSPointerFunctionsOptions keys=NSPointerFunctionsWeakMemory|NSPointerFunctionsObjectPointerPersonality;
    products=[NSHashTable hashTableWithOptions:keys];
    applied=[NSMapTable mapTableWithKeyOptions:keys valueOptions:NSPointerFunctionsStrongMemory];
    failures=[NSMapTable mapTableWithKeyOptions:keys valueOptions:NSPointerFunctionsStrongMemory];
    __weak CommonProduct *weakA;
    CommonProduct *b;
    @autoreleasepool {
    CommonProduct *a=[CommonProduct new]; b=[CommonProduct new];
    [products addObject:a];[products addObject:b];
    assert(products.count==2); // isEqual deliberately says equal; identity must win.
    PCStartSession(&session,42);session.mode=3;
    TestApply(); assert(a.calls==0&&b.calls==0);
    active=YES; TestApply(); assert(a.calls==0&&b.calls==0);
    session.received=true; TestApply();
    assert(a.calls==1&&b.calls==1&&a.mode==3&&b.mode==3&&lastStatus==3);
    TestApply(); assert(a.calls==1&&b.calls==1);
    a.shouldThrow=YES;session.mode=2;TestApply();
    assert(a.calls==2&&b.calls==2&&b.mode==2&&lastStatus==98);
    session.mode=1;TestApply();
    assert(a.calls==2&&b.calls==3&&b.mode==1&&lastStatus==98);
    weakA=a;a=nil;
    } // End failed receiver lifetime before testing a replacement receiver.
    assert(weakA==nil);
    @autoreleasepool {
    CommonProduct *c=[CommonProduct new];[products addObject:c];TestApply();
    assert(c.calls==1&&c.mode==1&&b.calls==3&&lastStatus==1);
    [applied removeObjectForKey:b];TestApply();assert(b.calls==4);
    b=nil;c=nil;
    } // Drain weak-load/autoreleased snapshot temporaries before lifetime assertions.
    assert(weakA==nil);
    assert(products.allObjects.count==0);
    TestApply();assert(lastStatus==10); // No live receiver cannot mean successfully applied.
    @autoreleasepool {
        CommonProduct *e=[CommonProduct new];[products addObject:e];
        PCStartSession(&session,71);session.received=true;session.mode=3;
        __block BOOL changed=NO;
        e.onApply=^{ if (!changed) { changed=YES;session.mode=2; } };
        TestApply();
        assert(e.calls==1 && e.mode==3);
        assert([[applied objectForKey:e] unsignedIntValue]==3); // rc2 incorrectly cached 2.
        assert(deferredCount==1);
        TestApply();assert(e.calls==2 && e.mode==2 && lastStatus==2);
        e.onApply=nil;
        session.mode=4;changed=NO;
        e.onApply=^{ if(!changed){changed=YES;session.mode=1;PCApply();} };
        unsigned before=e.calls;
        TestApply();assert(e.calls==before+1 && e.mode==4 && deferredCount==2);
        e.onApply=nil;TestApply();assert(e.calls==before+2 && e.mode==1 && lastStatus==1);
        // A new waiting session during the call must never be reported as applied.
        session.mode=3;
        e.onApply=^{PCStartSession(&session,72);PCReport(10);};
        TestApply();assert(lastStatus==10 && !session.received);
        e.onApply=nil;assert(PCAcceptResponse(&session,PCResponse(72,0)));
        TestApply();assert(e.mode==0 && lastStatus==0);
        e=nil;
    }
    @autoreleasepool {
        __block unsigned replacementCalls=0;
        Class replacement=objc_allocateClassPair(NSObject.class,"PCReplacementOnly",0);
        class_addMethod(replacement,@selector(putDeviceInThermalSimulationMode:),imp_implementationWithBlock(^(id self,NSString *mode){
            (void)self;assert([mode isEqualToString:@"light"]);++replacementCalls;
        }),"v@:@");objc_registerClassPair(replacement);
        assert(PCCheckApplyABI(replacement) && !PCCheckProductABI(replacement));
        id receiver=[replacement new];[products addObject:receiver];
        session.mode=2;session.received=true;TestApply();
        assert(replacementCalls==1 && lastStatus==2);
    }
    puts("PASS: extracted production apply code, inactive/waiting guards, identity, dedup, reinit, exception isolation, weak lifetime, empty status, reentrant mode/session changes and replacement receiver");
} return 0; }
