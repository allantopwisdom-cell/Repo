#ifndef PC_UI_STATE_H
#define PC_UI_STATE_H
#include <stdbool.h>
#include <stdint.h>
#include "PCRProtocol.h"
typedef struct { uint64_t generation; uint32_t previousSession; bool active,expired; } PCUIQuery;
typedef enum { PCUIIgnore, PCUIWaiting, PCUIAccepted, PCUIMismatch, PCUITimeout, PCUIException, PCUIUnsupported,
               PCUICachedException, PCUICachedUnsupported, PCUINoReply } PCUIResult;
static inline uint64_t PCUIBegin(PCUIQuery *q, uint32_t previous) {
    ++q->generation; q->previousSession=previous; q->active=true; q->expired=false; return q->generation;
}
static inline void PCUIInvalidate(PCUIQuery *q) { ++q->generation; q->active=false; }
static inline bool PCUIIsCurrent(const PCUIQuery *q, uint64_t generation) {
    return q->active && q->generation==generation;
}
static inline void PCUIExpire(PCUIQuery *q,uint64_t generation) {
    if (PCUIIsCurrent(q,generation)) q->expired=true;
}
static inline PCUIResult PCUIEvaluate(const PCUIQuery *q, uint32_t before,
                                      uint64_t ack, uint32_t after, unsigned expected,
                                      unsigned *status) {
    if (!q->active) return PCUIIgnore;
    PCUIResult pending=q->expired ? PCUINoReply : PCUIWaiting;
    if (before!=after) return pending;
    // Terminal faults refuse new probe cycles. Expose their precise cached record,
    // including session-zero preflight faults, without treating it as a live reply.
    if (!before || before==q->previousSession) {
        if (ack==PCREncodeStatus(before,98)) return PCUICachedException;
        if (ack==PCREncodeStatus(before,99)) return PCUICachedUnsupported;
        return pending;
    }
    if (!PCRDecodeStatus(ack,before,status)) return pending;
    if (*status<=4) return *status==expected ? PCUIAccepted : PCUIMismatch;
    if (*status==11) return PCUITimeout;
    if (*status==98) return PCUIException;
    if (*status==99) return PCUIUnsupported;
    return pending;
}
#endif
