#ifndef PCR_CC_HOST_TEST
#import <UIKit/UIKit.h>
#endif
#import <Foundation/Foundation.h>
#import <objc/message.h>
#import <objc/runtime.h>
#import <notify.h>
#import "../PCRProtocol.h"
#import "../PCUIState.h"
#import "../PCRPreferences.h"
#import "../PCShortcut.h"
// Deliberately minimal private API declarations; no private ivar or KVC access.
@interface CCUIMenuModuleViewController : UIViewController
- (void)setTitle:(NSString *)title;
- (void)removeAllActions;
- (void)addActionWithTitle:(NSString *)title glyph:(UIImage *)glyph handler:(void (^)(void))handler;
- (void)addActionWithTitle:(NSString *)title subtitle:(NSString *)subtitle glyph:(UIImage *)glyph handler:(void (^)(void))handler;
- (void)setGlyphImage:(UIImage *)image;
- (void)setSelectedGlyphColor:(UIColor *)color;
- (void)setSelected:(BOOL)selected;
- (void)willTransitionToExpandedContentMode:(BOOL)expanded;
@end
@interface PowercuffCCModuleViewController : CCUIMenuModuleViewController {
    int _settingsToken, _appliedToken, _requestToken;
    PCUIQuery _query;
    id _lpmObserver;
}
@property(nonatomic) NSInteger selectedIndex;
@property(nonatomic,copy) NSString *statusText;
- (void)refresh;
- (void)refreshStatus;
- (void)chooseMode:(NSInteger)mode;
- (void)queryStatus;
@end

static NSUserDefaults *PCDefaults(void) {
    return [[NSUserDefaults alloc] initWithSuiteName:@"com.dao.powercuff"];
}
static uint32_t PCSession(int token) {
    uint64_t word = 0; uint32_t session = 0;
    if (token >= 0 && notify_get_state(token, &word) == NOTIFY_STATUS_OK)
        PCRDecodeRequest(word, &session);
    return session;
}
@implementation PowercuffCCModuleViewController
- (id)init {
    if ((self = [super initWithNibName:nil bundle:nil])) {
        _settingsToken = _appliedToken = _requestToken = -1;
        __weak typeof(self) weak = self;
        if (notify_register_check("com.powercuff.roothide.request", &_requestToken) != NOTIFY_STATUS_OK)
            _requestToken = -1;
        if (notify_register_dispatch("com.dao.powercuff.settingschanged", &_settingsToken,
            dispatch_get_main_queue(), ^(int t) { (void)t; [weak queryStatus]; }) != NOTIFY_STATUS_OK)
            _settingsToken = -1;
        if (notify_register_dispatch(PCRAppliedName, &_appliedToken, dispatch_get_main_queue(),
            ^(int t) { (void)t; [weak refreshStatus]; }) != NOTIFY_STATUS_OK)
            _appliedToken = -1;
        _lpmObserver = [NSNotificationCenter.defaultCenter
            addObserverForName:NSProcessInfoPowerStateDidChangeNotification object:nil
            queue:NSOperationQueue.mainQueue usingBlock:^(NSNotification *n) {
                (void)n; [weak queryStatus];
            }];
        _statusText = @"未验证后台状态";
    }
    return self;
}
- (void)dealloc {
    if (_lpmObserver) [NSNotificationCenter.defaultCenter removeObserver:_lpmObserver];
    if (_settingsToken >= 0) notify_cancel(_settingsToken);
    if (_appliedToken >= 0) notify_cancel(_appliedToken);
    if (_requestToken >= 0) notify_cancel(_requestToken);
}
- (void)viewDidLoad {
    [super viewDidLoad];
    if ([self respondsToSelector:@selector(setGlyphImage:)]) {
        UIImage *glyph=[UIImage imageNamed:@"Icon" inBundle:[NSBundle bundleForClass:self.class]
             compatibleWithTraitCollection:nil];
        [self setGlyphImage:glyph ?: [UIImage systemImageNamed:@"thermometer"]];
    }
    if ([self respondsToSelector:@selector(setSelectedGlyphColor:)])
        [self setSelectedGlyphColor:[UIColor colorWithRed:0.972 green:0.8 blue:0.274 alpha:1.0]];
    [self refresh];
}
- (void)viewWillAppear:(BOOL)animated {
    [super viewWillAppear:animated]; [self queryStatus];
}
- (void)controlCenterWillPresent { [self queryStatus]; }
- (BOOL)shouldBeginTransitionToExpandedContentModule { return YES; }
- (BOOL)_canShowWhileLocked { return YES; }
- (void)willTransitionToExpandedContentMode:(BOOL)expanded {
    if ([CCUIMenuModuleViewController instancesRespondToSelector:_cmd])
        [super willTransitionToExpandedContentMode:expanded];
    if (expanded) [self queryStatus];
}
- (void)refresh {
    NSDictionary *snapshot = PCRPreferenceSnapshot(PCDefaults(), @"com.dao.powercuff");
    self.selectedIndex = PCRSelectedMode(snapshot[@"PowerMode"]);
    // Compact highlight denotes the requested effective profile, never a live API acknowledgement.
    NSInteger effective=PCRValidatedMode(snapshot[@"PowerMode"],snapshot[@"RequireLowPowerMode"],
                                         NSProcessInfo.processInfo.lowPowerModeEnabled);
    if ([self respondsToSelector:@selector(setSelected:)]) [self setSelected:effective>0];
    NSArray *titles = @[@"关闭", @"正常（仍在模拟）", @"轻度", @"适中", @"重度"];
    if ([self respondsToSelector:@selector(setTitle:)])
        [self setTitle:[NSString stringWithFormat:@"PowerCuff · %@", self.statusText ?: @"未确认"]];
    BOOL detailed=[self respondsToSelector:@selector(addActionWithTitle:subtitle:glyph:handler:)];
    if (![self respondsToSelector:@selector(removeAllActions)] ||
        (!detailed && ![self respondsToSelector:@selector(addActionWithTitle:glyph:handler:)])) {
        if ([self respondsToSelector:@selector(setTitle:)]) [self setTitle:@"PowerCuff · 菜单接口不可用"];
        return;
    }
    [self removeAllActions];
    __weak typeof(self) weak = self;
    for (NSInteger i=0; i<5; ++i) {
        NSString *title=[NSString stringWithFormat:@"%@%@", i==self.selectedIndex ? @"✓ " : @"", titles[i]];
        void (^handler)(void)=^{ [weak chooseMode:i]; };
        if (detailed)
            [self addActionWithTitle:title subtitle:(i==self.selectedIndex ? self.statusText : @"选择此热模拟档位")
                              glyph:nil handler:handler];
        else [self addActionWithTitle:title glyph:nil handler:handler];
    }
}
- (void)queryStatus {
    if (_requestToken<0 || _appliedToken<0 || _settingsToken<0) {
        PCUIInvalidate(&_query); self.statusText=@"通知注册失败，无法确认状态"; [self refresh]; return;
    }
    uint64_t generation = PCUIBegin(&_query, PCSession(_requestToken));
    self.statusText = @"正在确认接口状态…";
    [self refresh];
    // A status probe never rebroadcasts settingschanged, avoiding a feedback loop.
    if (notify_post(PCRProbeName) != NOTIFY_STATUS_OK) {
        PCUIInvalidate(&_query);
        self.statusText = @"状态请求发送失败"; [self refresh]; return;
    }
    __weak typeof(self) weak = self;
    for (NSNumber *delay in @[@0.4, @1.3, @3.2]) {
        dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(delay.doubleValue*NSEC_PER_SEC)),
                       dispatch_get_main_queue(), ^{
            typeof(self) strong = weak;
            if (strong && PCUIIsCurrent(&strong->_query, generation)) {
                if (delay.doubleValue>=3.2) PCUIExpire(&strong->_query,generation);
                [strong refreshStatus];
            }
        });
    }
}
- (void)refreshStatus {
    uint32_t before = PCSession(_requestToken);
    uint64_t word = 0; unsigned status = 255;
    if (_appliedToken < 0 || notify_get_state(_appliedToken, &word) != NOTIFY_STATUS_OK) word=0;
    uint32_t after = PCSession(_requestToken);
    NSDictionary *snapshot = PCRPreferenceSnapshot(PCDefaults(), @"com.dao.powercuff");
    unsigned expected=(unsigned)PCRValidatedMode(snapshot[@"PowerMode"], snapshot[@"RequireLowPowerMode"],
                                               NSProcessInfo.processInfo.lowPowerModeEnabled);
    PCUIResult result=PCUIEvaluate(&_query,before,word,after,expected,&status);
    if (result==PCUIIgnore) return;
    if (result==PCUIAccepted) {
        NSArray *names = @[@"关闭", @"正常（仍在模拟）", @"轻度", @"适中", @"重度"];
        self.statusText = [NSString stringWithFormat:@"接口已返回：%@", names[status]];
    } else if (result==PCUIMismatch) self.statusText=@"返回档位与当前设置不一致";
    else if (result==PCUIException) self.statusText=@"接口异常，已停止重试";
    else if (result==PCUIUnsupported) self.statusText=@"接口不兼容";
    else if (result==PCUITimeout) self.statusText=@"后台通信超时，旧档位可能仍在";
    else if (result==PCUICachedException) self.statusText=@"后台异常记录，当前存活未确认";
    else if (result==PCUICachedUnsupported) self.statusText=@"接口不兼容记录，当前存活未确认";
    else if (result==PCUINoReply) self.statusText=@"本次确认未完成，旧档位可能仍在";
    else self.statusText=@"尚未收到本次应用确认";
    [self refresh];
}
- (void)chooseMode:(NSInteger)mode {
    if (mode < 0 || mode > 4) return;
    NSUserDefaults *d = PCDefaults();
    if (!PCRSaveControlCenterMode(d, @"com.dao.powercuff", mode)) {
        PCUIInvalidate(&_query);
        self.statusText = @"设置同步失败，未确认应用"; [self refresh]; return;
    }
    if (notify_post("com.dao.powercuff.settingschanged") != NOTIFY_STATUS_OK) {
        PCUIInvalidate(&_query); self.statusText=@"设置通知发送失败"; [self refresh]; return;
    }
    [self queryStatus];
}
- (void)buttonTapped:(id)sender forEvent:(id)event {
    (void)sender; (void)event;
    NSDictionary *snapshot = PCRPreferenceSnapshot(PCDefaults(), @"com.dao.powercuff");
    unsigned selected=(unsigned)PCRSelectedMode(snapshot[@"PowerMode"]);
    unsigned last=(unsigned)PCRSelectedMode(snapshot[@"LastEnabledMode"]);
    [self chooseMode:(NSInteger)PCShortcutTarget(selected,last)];
}

@end

@protocol CCUIContentModule <NSObject>
@property(nonatomic,readonly) UIViewController *contentViewController;
@property(nonatomic,readonly) UIViewController *backgroundViewController;
@end
@interface PowercuffCCModule : NSObject <CCUIContentModule>
@property(nonatomic,strong,readonly) UIViewController *contentViewController;
@property(nonatomic,strong,readonly) UIViewController *backgroundViewController;
@end
@implementation PowercuffCCModule
- (id)init {
    if ((self=[super init])) _contentViewController = [PowercuffCCModuleViewController new];
    return self;
}
@end
