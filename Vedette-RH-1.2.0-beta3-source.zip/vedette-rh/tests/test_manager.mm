// GPLv3. Executes the production manager with mock kernel APIs and temporary files.
#import <Foundation/Foundation.h>
#include <unistd.h>
#include <errno.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
static NSString *testDirectory;
static NSString *journalOverride;
NSString *VDTTestPath(NSString *name) {
    if(journalOverride && [name isEqual:@"runtime.plist"])return journalOverride;
    return [testDirectory stringByAppendingPathComponent:name];
}
#include "../VDTProcessManager.mm"
static NSMutableDictionary<NSNumber *,NSDictionary *> *processes;
static NSArray<NSNumber *> *pidOrder;
static NSMutableDictionary<NSNumber *,NSNumber *> *limits;
static NSMutableDictionary<NSNumber *,NSNumber *> *monitors;
static BOOL failEnumeration,failClear,failDefaults;
static NSUInteger clearCalls,throttleCalls,monitorCalls,resumeCalls,checks;
#define CHECK(expr) do { ++checks; if(!(expr)){fprintf(stderr,"FAIL %s:%d: %s\n",__FILE__,__LINE__,#expr);abort();} } while(0)

static int fakeList(uint32_t type,uint32_t typeinfo,void *buffer,int size) {
    (void)type;(void)typeinfo;
    if(failEnumeration){errno=EIO;return -1;}
    int bytes=(int)(pidOrder.count*sizeof(pid_t));
    if(!buffer)return bytes?bytes:(int)sizeof(pid_t);
    int count=MIN((int)pidOrder.count,size/(int)sizeof(pid_t));
    for(int i=0;i<count;i++)((pid_t *)buffer)[i]=pidOrder[i].intValue;
    return count*(int)sizeof(pid_t);
}
static int fakeInfo(int pid,int flavor,uint64_t arg,void *buffer,int size) {
    (void)arg;
    NSDictionary *p=processes[@(pid)];
    if(!p || flavor!=VDT_PROC_PIDTBSDINFO || size!=(int)sizeof(VDTProcBSDInfo)){errno=ESRCH;return 0;}
    VDTProcBSDInfo info={};info.pbi_pid=(uint32_t)pid;
    info.pbi_start_tvsec=[p[@"startSec"] unsignedLongLongValue];
    info.pbi_start_tvusec=[p[@"startUSec"] unsignedLongLongValue];
    memcpy(buffer,&info,sizeof(info));return (int)sizeof(info);
}
static int fakePath(int pid,void *buffer,uint32_t size) {
    NSDictionary *p=processes[@(pid)];if(!p){errno=ESRCH;return 0;}
    const char *path=[p[@"path"] UTF8String];size_t n=strlen(path)+1;
    if(n>size){errno=ENOSPC;return 0;}memcpy(buffer,path,n);return (int)n-1;
}
static int fakeThrottle(pid_t pid,int action,int percent) {
    CHECK(action==1);++throttleCalls;limits[@(pid)]=@(percent);return 0;
}
static int fakeClear(pid_t pid) {
    ++clearCalls;if(failClear){errno=EPERM;return -1;}[limits removeObjectForKey:@(pid)];return 0;
}
static int fakeDisable(pid_t pid){(void)pid;return 0;}
static int fakeDefaults(pid_t pid) {
    if(failDefaults){errno=EIO;return -1;}[monitors removeObjectForKey:@(pid)];return 0;
}
static int fakeResume(pid_t pid){(void)pid;++resumeCalls;return 0;}
static int fakeFatal(pid_t pid,int percent,int interval) {
    CHECK(interval>=60);++monitorCalls;monitors[@(pid)]=@(percent);return 0;
}
void *VDTTestLookup(const char *name) {
    if(!strcmp(name,"proc_listpids"))return (void *)fakeList;
    if(!strcmp(name,"proc_pidinfo"))return (void *)fakeInfo;
    if(!strcmp(name,"proc_pidpath"))return (void *)fakePath;
    if(!strcmp(name,"proc_setcpu_percentage"))return (void *)fakeThrottle;
    if(!strcmp(name,"proc_clear_cpulimits"))return (void *)fakeClear;
    if(!strcmp(name,"proc_disable_cpumon"))return (void *)fakeDisable;
    if(!strcmp(name,"proc_set_cpumon_defaults"))return (void *)fakeDefaults;
    if(!strcmp(name,"proc_resume_cpumon"))return (void *)fakeResume;
    if(!strcmp(name,"proc_set_cpumon_params_fatal"))return (void *)fakeFatal;
    return NULL;
}
BOOL VDTTestProcessGone(pid_t pid){return processes[@(pid)]==nil;}
static void restartManager(void) {
    initialized=NO;tracked=nil;recovery=NO;loadError=nil;lastError=@"";
}
static void newScenario(void) {
    restartManager();processes=[NSMutableDictionary dictionary];pidOrder=@[];
    limits=[NSMutableDictionary dictionary];monitors=[NSMutableDictionary dictionary];
    failEnumeration=failClear=failDefaults=NO;clearCalls=throttleCalls=monitorCalls=resumeCalls=0;
    journalOverride=nil;VDTSetControllerHealth(YES,YES);
    [[NSFileManager defaultManager] removeItemAtPath:VDT_REMOVAL_PATH error:NULL];
    [[NSFileManager defaultManager] removeItemAtPath:VDT_RUNTIME_PATH error:NULL];
    [[NSFileManager defaultManager] removeItemAtPath:VDT_STATUS_PATH error:NULL];
}
static void app(pid_t pid,NSString *name,uint64_t start) {
    NSString *bundle=[testDirectory stringByAppendingPathComponent:[name stringByAppendingString:@".app"]];
    CHECK([[NSFileManager defaultManager] createDirectoryAtPath:bundle withIntermediateDirectories:YES attributes:nil error:NULL]);
    NSDictionary *info=@{@"CFBundleExecutable":name,@"CFBundleIdentifier":[@"test." stringByAppendingString:name]};
    CHECK([info writeToFile:[bundle stringByAppendingPathComponent:@"Info.plist"] atomically:YES]);
    processes[@(pid)]=@{@"pid":@(pid),@"path":[bundle stringByAppendingPathComponent:name],@"startSec":@(start),@"startUSec":@0};
}
static NSDictionary *rule(NSString *name,int percent,int mode) {
    return @{@"bundleIdentifier":[@"test." stringByAppendingString:name],@"enabled":@YES,@"percentage":@(percent),@"interval":@120,@"violationPolicy":@(mode)};
}
static NSDictionary *preferences(NSArray *rules,BOOL enabled,BOOL dryRun) {
    return @{@"enabled":@(enabled),@"dryRun":@(dryRun),@"allowTerminate":@YES,@"appConfigs":rules};
}
static NSDictionary *status(void){return [NSDictionary dictionaryWithContentsOfFile:VDT_STATUS_PATH];}
int main(void) {
 @autoreleasepool {
    char temp[]="/tmp/vedette-manager-XXXXXX";char *path=mkdtemp(temp);CHECK(path!=NULL);
    testDirectory=[NSString stringWithUTF8String:path];
    const pid_t a=100001,b=100002;
    NSArray *rules=@[rule(@"A",30,VDTThrottle),rule(@"B",80,VDTThrottle)];
    // Actual enumeration and rule matching with reversed PID order and missing app A.
    newScenario();app(a,@"A",1);app(b,@"B",2);pidOrder=@[@(b),@(a)];
    VDTReconcile(preferences(rules,YES,NO));
    CHECK([limits[@(a)] isEqual:@30] && [limits[@(b)] isEqual:@80]);CHECK(tracked.count==2);
    NSUInteger applied=throttleCalls;VDTReconcile(preferences(rules,YES,NO));CHECK(throttleCalls==applied);
    VDTReconcile(preferences(rules,NO,NO));CHECK(!limits.count && !tracked.count);CHECK(![[NSFileManager defaultManager] fileExistsAtPath:VDT_RUNTIME_PATH]);
    newScenario();app(b,@"B",2);pidOrder=@[@(b)];VDTReconcile(preferences(rules,YES,NO));CHECK([limits[@(b)] isEqual:@80]);
    // Startup cleanup failure must remain latched and be retried on the next production cycle.
    restartManager();failClear=YES;VDTReconcile(preferences(rules,YES,NO));
    CHECK(recovery);CHECK([status()[@"blocked"] boolValue]);CHECK(![tracked[@"100002"][@"active"] boolValue]);
    NSUInteger clears=clearCalls;VDTReconcile(preferences(rules,YES,NO));CHECK(clearCalls>clears && recovery);
    failClear=NO;VDTReconcile(preferences(rules,YES,NO));CHECK(!recovery && ![status()[@"blocked"] boolValue]);CHECK([limits[@(b)] isEqual:@80]);
    // Discovery failure still clears known policies and reports a fresh blocked status.
    failEnumeration=YES;VDTReconcile(preferences(rules,YES,NO));CHECK(!limits.count && !tracked.count);
    CHECK([status()[@"discoveryFailed"] boolValue] && [status()[@"blocked"] boolValue]);
    // Terminate -> Throttle clears monitor; changing percentage clears and reapplies the correct rule.
    newScenario();app(a,@"A",1);pidOrder=@[@(a)];
    VDTReconcile(preferences(@[rule(@"A",70,VDTTerminate)],YES,NO));CHECK([monitors[@(a)] isEqual:@70]);
    VDTReconcile(preferences(@[rule(@"A",45,VDTThrottle)],YES,NO));CHECK(!monitors.count && [limits[@(a)] isEqual:@45]);
    VDTReconcile(preferences(@[rule(@"A",55,VDTThrottle)],YES,NO));CHECK([limits[@(a)] isEqual:@55]);
    VDTReconcile(preferences(@[],YES,NO));CHECK(!limits.count && !tracked.count);
    // A PID reused by a protected process drops the obsolete record without touching that process.
    newScenario();app(a,@"A",1);pidOrder=@[@(a)];VDTReconcile(preferences(rules,YES,NO));
    processes[@(a)]=@{@"pid":@(a),@"path":@"/usr/libexec/thermalmonitord",@"startSec":@99,@"startUSec":@0};
    NSUInteger beforeReuse=clearCalls;VDTReconcile(preferences(rules,YES,NO));CHECK(!tracked.count && clearCalls==beforeReuse);
    // Journal write failure must not issue cleanup calls or discard the pending marker.
    newScenario();app(a,@"A",1);pidOrder=@[@(a)];VDTReconcile(preferences(rules,YES,NO));
    NSString *validJournal=VDT_RUNTIME_PATH;journalOverride=testDirectory;
    clears=clearCalls;VDTReconcile(preferences(rules,NO,NO));CHECK(clearCalls==clears);
    CHECK([status()[@"blocked"] boolValue] && ![tracked[@"100001"][@"active"] boolValue]);
    journalOverride=nil;CHECK([VDT_RUNTIME_PATH isEqual:validJournal]);
    VDTReconcile(preferences(rules,NO,NO));CHECK(!tracked.count && !limits.count);
    // Monitor recovery still resumes monitoring when restoring defaults fails.
    newScenario();app(a,@"A",1);pidOrder=@[@(a)];VDTReconcile(preferences(@[rule(@"A",70,VDTTerminate)],YES,NO));
    failDefaults=YES;NSUInteger resumes=resumeCalls;VDTReconcile(preferences(@[],NO,NO));
    CHECK(resumeCalls>resumes && tracked.count==1 && [status()[@"blocked"] boolValue]);
    failDefaults=NO;VDTReconcile(preferences(@[],NO,NO));CHECK(!tracked.count && !monitors.count);
    // Dry-run discovers targets without applying limits; enabling it clears previous limits.
    newScenario();app(a,@"A",1);pidOrder=@[@(a)];VDTReconcile(preferences(rules,YES,YES));CHECK(!throttleCalls && [status()[@"matched"] intValue]==1);
    VDTReconcile(preferences(rules,YES,NO));CHECK(limits.count==1);
    VDTReconcile(preferences(rules,YES,YES));CHECK(!limits.count && !tracked.count);
    // Removal marker drains policies and forbids new ones until explicitly cancelled.
    newScenario();app(a,@"A",1);pidOrder=@[@(a)];VDTReconcile(preferences(rules,YES,NO));
    CHECK([@"" writeToFile:VDT_REMOVAL_PATH atomically:YES encoding:NSUTF8StringEncoding error:NULL]);
    VDTReconcile(preferences(rules,YES,NO));CHECK(!limits.count && !tracked.count && [status()[@"removing"] boolValue]);
    VDTReconcile(preferences(rules,YES,NO));CHECK(!tracked.count);
    // Timer failure forbids enforcement; lost notification registration still permits polling.
    newScenario();app(a,@"A",1);pidOrder=@[@(a)];VDTSetControllerHealth(NO,NO);
    VDTReconcile(preferences(rules,YES,NO));CHECK(!limits.count && ![status()[@"timerHealthy"] boolValue]);
    VDTSetControllerHealth(NO,YES);VDTReconcile(preferences(rules,YES,NO));CHECK(limits.count==1 && ![status()[@"notificationHealthy"] boolValue]);
    // Same daemon basename at another executable path must never match.
    newScenario();pidOrder=@[@(a),@(b)];
    processes[@(a)]=@{@"path":@"/usr/libexec/exampled",@"startSec":@1,@"startUSec":@0};
    processes[@(b)]=@{@"path":@"/other/exampled",@"startSec":@2,@"startUSec":@0};
    NSDictionary *daemon=@{@"daemonName":@"exampled",@"enabled":@YES,@"executablePath":@"/usr/libexec/exampled"};
    VDTReconcile(@{@"enabled":@YES,@"dryRun":@NO,@"daemonConfigs":@[daemon]});CHECK(limits.count==1 && limits[@(a)]!=nil);
    VDTReconcile(@{@"enabled":@YES,@"dryRun":@NO,@"daemonConfigs":@[@{@"daemonName":@"exampled",@"enabled":@YES}]});CHECK(!limits.count && [status()[@"invalidRules"] intValue]==1);
    // Malformed values and duplicate rules fail closed without an Objective-C exception.
    newScenario();app(a,@"A",1);pidOrder=@[@(a)];
    for(id bad in @[@[],@{},NSNull.null,@YES,@(NAN),@"80x"]) {
        NSMutableDictionary *r=[rule(@"A",80,VDTThrottle) mutableCopy];r[@"percentage"]=bad;
        VDTReconcile(preferences(@[r],YES,NO));CHECK(!limits.count && [status()[@"invalidRules"] intValue]==1);
    }
    VDTReconcile(preferences(@[rules[0],rules[0]],YES,NO));CHECK(!limits.count);
    VDTReconcile(preferences(rules,YES,NO));CHECK(limits.count==1);
    VDTReconcile(preferences(@[],NO,NO));
    // Corrupt journal schema must block even when the global switch is off.
    CHECK([(@{@"schema":@YES,@"records":@{}}) writeToFile:VDT_RUNTIME_PATH atomically:YES]);
    restartManager();VDTReconcile(preferences(rules,YES,NO));CHECK([status()[@"journalInvalid"] boolValue] && [status()[@"blocked"] boolValue]);
    newScenario();[[NSFileManager defaultManager] removeItemAtPath:testDirectory error:NULL];
    printf("PASS: production manager fault injection, %lu assertions\n",(unsigned long)checks);
 }
 return 0;
}
