from pathlib import Path
import sys
root=Path(__file__).resolve().parents[1]
s=(root/'Powercuff.x').read_text()
mode=s[s.index('static NSString *PCModeString('):s.index('static void PCApply(void) {')]
apply=s[s.index('static void PCApply(void) {'):s.index('static BOOL PCReadResponse(')]
template=(root/'tests/runtime.m').read_text().replace('#import "../Protocol.h"','#import "Protocol.h"').replace('#import "../Runtime.h"','#import "Runtime.h"')
assert template.count('// ACTUAL_PRODUCTION_FUNCTIONS')==1
if len(sys.argv)>2 and sys.argv[2]=='baseline': apply=(root/'tests/rc2_apply_baseline.inc').read_text()
Path(sys.argv[1]).write_text(template.replace('// ACTUAL_PRODUCTION_FUNCTIONS',mode+apply))
