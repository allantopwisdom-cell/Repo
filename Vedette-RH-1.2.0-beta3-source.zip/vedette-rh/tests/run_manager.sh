#!/bin/sh
set -eu
cd "$(dirname "$0")/.."
[ "$(uname -s)" = Darwin ] || { echo 'SKIP: production Objective-C manager tests require macOS Foundation'; exit 0; }
work=$(mktemp -d)
trap 'rm -rf "$work"' EXIT HUP INT TERM
xcrun clang -std=c11 -Wall -Wextra -Werror -fsanitize=address,undefined -fno-omit-frame-pointer -c VDTPolicy.c -o "$work/policy.o"
xcrun clang++ -std=c++17 -fobjc-arc -DVDT_HOST_TEST=1 -Wall -Wextra -Werror -fsanitize=address,undefined -fno-omit-frame-pointer tests/test_manager.mm "$work/policy.o" -framework Foundation -o "$work/test_manager"
ASAN_OPTIONS=detect_leaks=0 "$work/test_manager"

xcrun clang++ -std=c++17 -fobjc-arc -DVDT_HOST_TEST=1 -Wall -Wextra -Werror -fsanitize=address,undefined -fno-omit-frame-pointer tests/test_preferences.mm "$work/policy.o" -framework Foundation -o "$work/test_preferences"
ASAN_OPTIONS=detect_leaks=0 "$work/test_preferences"
