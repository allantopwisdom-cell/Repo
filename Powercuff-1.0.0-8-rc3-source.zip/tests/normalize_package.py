"""Normalize archive owners without changing any signed payload or control bytes."""
from pathlib import Path
import hashlib, subprocess, sys, tempfile
package=Path(sys.argv[1]).resolve()
assert package.is_file() and package.suffix=='.deb',package

def snapshot(root):
    return {str(p.relative_to(root)):(hashlib.sha256(p.read_bytes()).hexdigest(),p.stat().st_mode & 0o7777)
            for p in root.rglob('*') if p.is_file()}

with tempfile.TemporaryDirectory(prefix='powercuff-normalize-') as temp:
    temp=Path(temp);before=temp/'before';after=temp/'after';result=temp/'normalized.deb'
    subprocess.run(['dpkg-deb','-R',str(package),str(before)],check=True)
    original=snapshot(before)
    subprocess.run(['dpkg-deb','--root-owner-group','-b',str(before),str(result)],check=True)
    subprocess.run(['dpkg-deb','-R',str(result),str(after)],check=True)
    assert snapshot(after)==original,'normalization altered file bytes or permissions'
    # The temporary archive can be on another filesystem; copy to a sibling,
    # then atomically replace only after byte/mode equality has passed.
    sibling=package.with_suffix('.deb.normalized')
    try:
        sibling.write_bytes(result.read_bytes())
        sibling.replace(package)
    finally:
        sibling.unlink(missing_ok=True)
print('PASS: numeric archive owner normalization; every file byte and mode unchanged')
