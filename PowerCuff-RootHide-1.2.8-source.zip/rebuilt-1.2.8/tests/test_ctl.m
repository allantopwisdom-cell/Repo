// Run the real diagnostic main with an in-memory notify adapter, never device IPC.
#import <Foundation/Foundation.h>
#import <notify.h>
#import "PCRProtocol.h"
#include <assert.h>
#include <stdio.h>
#include <string.h>
#include <unistd.h>
static unsigned ReqReads,Sleeps,Cancels,StatusValue;
static BOOL Torn,Match,Disable,RegisterFail,PostFail;
static uint64_t Nonce;
static uint32_t TRegister(const char *name,int *token) {
    if (RegisterFail) return 1;
    *token=(strcmp(name,"com.powercuff.roothide.request")==0 || strcmp(name,PCRDisableName)==0) ? 1:2;return 0;
}
static uint32_t TGet(int token,uint64_t *word) {
    if (Disable) *word=Match?Nonce:0;
    else if (token==1) *word=PCREncodeRequest(++ReqReads>1 && Torn?101:100);
    else *word=PCREncodeStatus(Match?100:99,StatusValue);
    return 0;
}
static uint32_t TSet(int token,uint64_t word) {(void)token;Nonce=word;return 0;}
static uint32_t TPost(const char *name) {(void)name;return PostFail?1:0;}
static uint32_t TCancel(int token) {(void)token;++Cancels;return 0;}
static int TSleep(useconds_t delay) {assert(delay==100000);++Sleeps;return 0;}
#define notify_register_check TRegister
#define notify_get_state TGet
#define notify_set_state TSet
#define notify_post TPost
#define notify_cancel TCancel
#define usleep TSleep
#define main PCControlMain
#import "../ctl/main.m"
#undef main
static void Reset(void) {ReqReads=Sleeps=Cancels=StatusValue=0;Torn=Disable=RegisterFail=PostFail=NO;Match=YES;Nonce=0;}
int main(void) {
    char *status[]={"pcctl","status"},*disable[]={"pcctl","disable"};
    for (unsigned n=0;n<=4;++n) {Reset();StatusValue=n;assert(PCControlMain(2,status)==0 && Cancels==2);}
    for (unsigned n=10;n<=99;++n) {Reset();StatusValue=n;assert(PCControlMain(2,status)==4 && Cancels==2);}
    Reset();Torn=YES;assert(PCControlMain(2,status)==3);
    Reset();Match=NO;assert(PCControlMain(2,status)==3);
    Reset();RegisterFail=YES;assert(PCControlMain(2,status)==3 && Cancels==0);
    Reset();Disable=YES;assert(PCControlMain(2,disable)==0 && Nonce && Sleeps==0 && Cancels==2);
    Reset();Disable=YES;Match=NO;assert(PCControlMain(2,disable)==3 && Sleeps==30 && Cancels==2);
    Reset();Disable=YES;PostFail=YES;assert(PCControlMain(2,disable)==3 && Sleeps==0 && Cancels==2);
    Reset();Disable=YES;RegisterFail=YES;assert(PCControlMain(2,disable)==2);
    puts("CLI production main: status codes, torn/mismatched snapshots, register/post failures, exact disable nonce and finite wait PASS");
    return 0;
}
