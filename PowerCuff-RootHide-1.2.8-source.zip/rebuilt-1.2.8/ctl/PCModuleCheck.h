#import <Foundation/Foundation.h>
#import <CoreFoundation/CoreFoundation.h>
#include <stdio.h>
// Explicit read-only diagnostic. Never instantiate a module, call principalClass,
// load executable code, edit preferences, post notifications or reload services.
static BOOL PCIntegerEquals(id value, NSInteger expected) {
    return [value isKindOfClass:NSNumber.class] &&
        CFGetTypeID((__bridge CFTypeRef)value)!=CFBooleanGetTypeID() &&
        [value doubleValue]==(double)expected;
}
static NSDictionary *PCModuleReport(NSString *path, BOOL (^preflight)(NSBundle *,NSError **)) {
    NSMutableDictionary *report=[NSMutableDictionary new];
    NSMutableArray *issues=[NSMutableArray new];
    report[@"schema"]=@1;report[@"bundle_path"]=path ?: @"";
    report[@"code_loaded"]=@NO;report[@"injection_verified"]=@NO;
    report[@"runtime_verified"]=@NO;report[@"preflight"]=@"skipped";
    if (!path.isAbsolutePath) { [issues addObject:@"bundle path must be absolute"];report[@"issues"]=issues;return report; }
    NSFileManager *fm=NSFileManager.defaultManager;BOOL directory=NO;
    BOOL exists=[fm fileExistsAtPath:path isDirectory:&directory] && directory;
    report[@"bundle_directory_exists"]=@(exists);
    NSString *infoPath=[path stringByAppendingPathComponent:@"Info.plist"];
    NSDictionary *attributes=[fm attributesOfItemAtPath:infoPath error:nil];
    unsigned long long size=[attributes[NSFileSize] unsignedLongLongValue];
    NSDictionary *info=nil;
    if (exists && size>0 && size<=65536) info=[NSDictionary dictionaryWithContentsOfFile:infoPath];
    if (!exists) [issues addObject:@"module directory missing or inaccessible"];
    if (!info) [issues addObject:@"Info.plist missing, unreadable, oversized or not a dictionary"];
    NSDictionary *expected=@{@"CFBundleIdentifier":@"com.dao.powercuff.ccmodule",
        @"CFBundleExecutable":@"PowercuffCC",@"NSPrincipalClass":@"PowercuffCCModule",
        @"CFBundlePackageType":@"BNDL",@"MinimumOSVersion":@"16.0"};
    NSMutableDictionary *metadata=[NSMutableDictionary new];
    for (NSString *key in expected) {
        id value=info[key];metadata[key]=value ? [value description] : @"<missing>";
        if (![value isKindOfClass:NSString.class] || ![value isEqual:expected[key]])
            [issues addObject:[@"unexpected metadata: " stringByAppendingString:key]];
    }
    for (NSString *key in @[@"CFBundleVersion",@"CFBundleShortVersionString"])
        metadata[key]=info[key] ? [info[key] description] : @"<missing>";
    id family=info[@"UIDeviceFamily"];
    if (![family isKindOfClass:NSArray.class] || [family count]!=2 ||
        !PCIntegerEquals(family[0],1) || !PCIntegerEquals(family[1],2))
        [issues addObject:@"UIDeviceFamily must be integer [1,2]"];
    report[@"metadata"]=metadata;
    NSString *executable=[path stringByAppendingPathComponent:@"PowercuffCC"];
    BOOL executableExists=[fm isExecutableFileAtPath:executable];
    report[@"executable_accessible"]=@(executableExists);
    if (!executableExists) [issues addObject:@"module executable missing or not executable"];
    // The caller supplies jbroot's resolved bundle path; derive the same root for CCSupport.
    NSString *root=path;
    for (unsigned i=0;i<4;++i) root=root.stringByDeletingLastPathComponent;
    NSString *base=[root stringByAppendingPathComponent:@"Library/MobileSubstrate/DynamicLibraries/CCSupport"];
    BOOL supportExists=[fm fileExistsAtPath:[base stringByAppendingString:@".dylib"]];
    report[@"ccsupport_dylib_exists"]=@(supportExists);
    if (!supportExists) [issues addObject:@"CCSupport dylib missing or inaccessible"];
    NSDictionary *filter=[NSDictionary dictionaryWithContentsOfFile:[base stringByAppendingString:@".plist"]];
    id filterBody=filter[@"Filter"];
    id bundles=[filterBody isKindOfClass:NSDictionary.class] ? filterBody[@"Bundles"] : nil;
    BOOL filterValid=[bundles isKindOfClass:NSArray.class] &&
        [bundles containsObject:@"com.apple.springboard"] && [bundles containsObject:@"com.apple.Preferences"];
    report[@"ccsupport_expected_filter"]=@(filterValid);
    if (!filterValid) [issues addObject:@"CCSupport SpringBoard/Settings filter missing or unexpected"];
    if (!issues.count) {
        NSBundle *bundle=[NSBundle bundleWithPath:path];NSError *error=nil;
        BOOL ok=bundle && preflight(bundle,&error);
        report[@"preflight"]=ok ? @"passed" : @"failed";
        if (error) {report[@"preflight_error_domain"]=error.domain;report[@"preflight_error_code"]=@(error.code);
                    report[@"preflight_error"]=error.localizedDescription;}
        if (!ok) [issues addObject:@"bundle preflight failed; this does not identify every possible link/load error"];
    }
    report[@"issues"]=issues;
    report[@"note"]=@"Preflight does not load executable code and does not prove SpringBoard/Settings injection, module discovery or actual thermal operation.";
    return report;
}
static int PCPrintModuleCheck(NSString *path) {
    NSDictionary *report=PCModuleReport(path, ^BOOL(NSBundle *bundle,NSError **error) {
        return [bundle preflightAndReturnError:error];
    });
    NSData *json=[NSJSONSerialization dataWithJSONObject:report options:NSJSONWritingPrettyPrinted error:nil];
    if (!json) return 2;
    fwrite(json.bytes,1,json.length,stdout);fputc('\n',stdout);
    return [report[@"issues"] count] ? 3 : 0;
}
