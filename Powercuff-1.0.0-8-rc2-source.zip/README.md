# Powercuff 1.0.0-8 rc2 — RootHide 验收候选版

目标：iPhone 14 Pro Max / iOS 16.5（20F66）/ RootHide Dopamine 3.0.4。
**本版未经目标设备实测，不能作为零风险或全部功能生效的证明。**

源码基线：
- rpetrich/Powercuff a97c445a4a8fd2ce1cfe9fbc16fdf82a930b62d1
- Mikasa-san/Powercuff 5397253bda51578b82dfbf7b804dd2839f48bfe7
- 上次交付 rc1 源码提交 6205ddf9bf45cf7c525a85bc8c6cc5aad3eb397b；DEB SHA256：827171c1b6cdcf95f003ce0f08b8e6e11cdc3b4fd810c4227e8d3ad3b4726300。

## 逐模块复核与修复
| 编号 | rc1 问题 | rc2 处理 | 验证方式 |
| --- | --- | --- | --- |
| P01 | 裸档位不能区分旧进程/旧缓存，daemon 写零与发布端并发竞争 | 新命名空间、40位非零随机会话、请求/回复标记；只接受当前会话回复；daemon 不改写响应状态 | 直接测试生产 Protocol.h：旧状态、跨会话、错误类型、越界、重启 |
| P02 | notify 读取失败被当作 off，并可能改变已生效状态 | 传输错误不转换为档位；最多4次请求+最终读取，无回复报告11并停止主动重试，旧模拟可能仍在 | 协议回归；源代码控制流审查；实际 notify 故障仍需真机 |
| P03 | 单个对象异常永久禁用全部对象 | 弱引用、按指针身份区分对象；按对象隔离异常/ABI失败；其它对象可继续；新对象可正常工作 | 对象集合使用 Foundation 接口；实际私有对象需真机 |
| P04 | 通知早到可能先于低电观察和完整初始化 | 成功注册全部必需资源后，在主队列激活；所有回调和延迟任务检查 active；失败清理 | 控制流复核；部分初始化故障仍需注入测试 |
| P05 | 偏好检查仅有数值C测试，未覆盖真实 NSNumber/CFBoolean 类型 | 提取生产 Preferences.h，在macOS真实Foundation下验证字符串、布尔、集合、NaN、无穷、开关与同步失败 | CI编译并运行 tests/foundation.m |
| P06 | 安装/卸载按进程名重启 SpringBoard，可能在包操作期间中断界面；purge 重复重启 | 仅在 configure/remove 探测服务域后请求一次 thermalmonitord kickstart；不按进程名发信号；提示手动注销；purge不重复 | 实际脚本的84组阶段/域/失败组合（命令模拟） |
| P07 | 弱容器默认对象相等性可能合并不同产品实例 | 使用弱内存+ObjectPointerPersonality，按身份维护应用及失败缓存 | 源码审查；产品多实例生命周期需真机 |
| P08 | 包校验缺少源码对应和篡改反例 | 增加精确payload、属主、脚本及plist源码对照；对实际dylib修改一字节，必须被代码页校验拒绝 | tests/verify_package.py |

## 所有配置参数
偏好域继续使用 com.rpetrich.powercuff，保留旧设置；不以root身份写入偏好。
- PowerMode：默认0，0=off、1=nominal、2=light、3=moderate、4=heavy。拒绝布尔、非数字、非整数、越界和非有限值，回退off。
- RequireLowPowerMode：默认false，仅接受布尔或数值0/1。开启且系统LPM关闭时请求off，不改变保存的PowerMode。非法开关或偏好同步失败回退off。
- 设置通知保持 com.rpetrich.powercuff.settingschanged。
- 每次配置/LPM/请求事件立即读取当前值，再在150/600ms有限重读；新事件使旧延迟任务失效，不持续轮询。

## 运行结构
仅注入 SpringBoard 与 thermalmonitord，不注入App、Widget或Settings。
SpringBoard（uid501）读取mobile用户AnyHost指定域的一份快照，响应当前daemon会话。thermalmonitord捕获CommonProduct初始化对象，主队列处理会话、对象与应用，调用前检查实际接收对象ABI。
初始hook同步安装，避免推迟到daemon创建产品之后；实际应用异步在主队列执行。必须在设备上确认该私有接口允许此队列。
不猜测GPProduct等其它类名，不包含控制中心独立模块、CPU固定频率、后台冻结或自动强制低电功能。

## 安装与回滚
与rc1使用相同包标识 com.baldaran.powercuff-r3vamp，rc2可升级替换rc1。不能与其它Powercuff包并装。
**安装/升级后手动注销一次**，替换SpringBoard中的旧代码。若daemon重载不确定，使用越狱应用重启用户空间。维护脚本输出只是重启请求，不证明重载成功。
首次停用其它热控插件，从off→light→off验证。卸载保留偏好；卸载后注销，若仍受限，重启用户空间以卸载daemon旧代码。

## 状态诊断
通知 com.powercuff.roothide.v2.status 的64位值：高16位0x5053，中40位daemon会话，低8位状态。与当前请求会话不一致时属于过时信息。
0..4=私有方法返回且无已记录对象失败；10=等待当前会话回复；11=有限请求超时；98=对象抛Objective-C异常；99=对象ABI不支持。
状态不证明实际硬件节流；服务死亡可能留下通知值，不能以残留值证明当前进程存活。

## 必须保留的运行限制
- 无真机证据：私有API/类布局、PAC执行、主队列归属、RootHide加载、LPM通知、偏好路径和真实温控保护均未最终确认。
- 全部有限通知均丢失后不会无限重试；可能保留旧状态，需显式设置变更或重启。方法异常后的对象不会尝试自动off，旧模拟可能仍在。
- Objective-C异常捕获不能捕获SIGBUS/SIGSEGV或watchdog。异常隔离避免重复调用，不代表故障已消失。
- 40位随机会话有极低的碰撞概率，不是对恶意注入的安全认证；同设备其它有权限的代码仍可干扰通知/私有方法。
- 上游未提供明确许可证文件；保留来源与作者署名，公开可读不等同于任意再分发授权。
- 热模拟不等于固定CPU频率或已量化省电，nominal也不等于关闭。与Hello CPU/Hello Memory Status联用须另做对照验证。

## 验收范围与门禁
C策略和会话测试在Linux/macOS执行；Foundation类型/ABI测试仅在macOS执行，CI为必需项。维护脚本命令被模拟，不执行设备操作。构建采用固定RootHide Theos、iOS16.5 SDK、Xcode16.4；全部源码重新编译、链接、签名、打包，再验证签名代码页、包内容、元数据和源码对应。
这只能放行“源码/构建/静态校验候选版”，**不满足无异常运行及全部功能生效的最终真机验收条件**。

真机应逐档记录实际状态、off恢复、LPM四组合、快速切换、锁屏/解锁、daemon和SpringBoard分别重启、重越狱、安装升级卸载、相机通话充电场景及至少一个完整待机周期；收集thermalmonitord/SpringBoard/watchdog日志。省电效果须固定负载和环境对照测试。
