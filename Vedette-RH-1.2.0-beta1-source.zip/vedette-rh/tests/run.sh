#!/bin/sh
set -eu
cd "$(dirname "$0")/.."
work=$(mktemp -d)
trap 'rm -rf "$work"' EXIT HUP INT TERM
${CC:-cc} -std=c11 -Wall -Wextra -Werror -fsanitize=address,undefined -fno-omit-frame-pointer VDTPolicy.c tests/test_policy.c -o "$work/test_policy"
ASAN_OPTIONS=detect_leaks=0 "$work/test_policy"
python3 tests/check_project.py
for script in layout/DEBIAN/*; do sh -n "$script"; done
