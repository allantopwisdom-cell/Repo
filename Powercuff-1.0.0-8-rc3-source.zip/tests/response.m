#import <Foundation/Foundation.h>
#import <assert.h>
#import "Protocol.h"
#define NOTIFY_STATUS_OK 0
static BOOL active;
static PCSession session;
static uint64_t responseGeneration;
static int responseState=10;
static unsigned readFailures,readCalls,applyCalls,lastStatus;
static uint64_t wireValue;
static NSMutableArray *tasks;
static void PCReport(unsigned value) { lastStatus=value; }
static void PCApply(void) { ++applyCalls;PCReport(session.mode); }
static uint32_t FakeGet(int token,uint64_t *out) {
    assert(token==responseState);++readCalls;
    if(readFailures){--readFailures;return 1;}
    *out=wireValue;return 0;
}
#define notify_get_state FakeGet
static void PCScheduleResponseRead(double delay,dispatch_block_t block) {
    assert(delay>0 && delay<=0.60);[tasks addObject:[block copy]];
}
// ACTUAL_RESPONSE_FUNCTIONS
static void Drain(void) {
    NSArray *pending=[tasks copy];[tasks removeAllObjects];
    for(dispatch_block_t block in pending)block();
}
int main(void) { @autoreleasepool {
    tasks=[NSMutableArray array];PCStartSession(&session,17);
    PCRefreshResponse();assert(readCalls==0 && tasks.count==0);
    active=YES;wireValue=PCResponse(17,3);readFailures=1;
    PCRefreshResponse();assert(!session.received && tasks.count==3 && applyCalls==0);
    Drain();assert(session.received && session.mode==3 && applyCalls==1 && readCalls==2);
    // A transient failure after initial success must still retry and restore Off.
    wireValue=PCResponse(17,0);readFailures=1;PCRefreshResponse();
    assert(session.mode==3 && applyCalls==1);Drain();
    assert(session.mode==0 && applyCalls==2 && lastStatus==0);
    readFailures=4;PCRefreshResponse();Drain();
    assert(lastStatus==12 && session.mode==0 && applyCalls==2 && tasks.count==0);
    wireValue=PCResponse(17,2);PCRefreshResponse();assert(session.mode==2 && lastStatus==2);
    // Delayed tasks from an old session or superseded event cannot publish an old mode.
    wireValue=PCResponse(16,4);PCRefreshResponse();unsigned before=readCalls;
    PCStartSession(&session,18);Drain();assert(readCalls==before && !session.received);
    wireValue=PCResponse(18,4);PCRefreshResponse();assert(session.mode==4 && lastStatus==4);
    readFailures=1;PCRefreshResponse();before=readCalls;active=NO;Drain();assert(readCalls==before);
    puts("PASS: extracted response reader, transient failure after success, Off recovery, finite exhaustion, superseded session/event and inactive callback guards");
} return 0; }
