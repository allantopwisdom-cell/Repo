#include <assert.h>
#include <stdio.h>
#include "../Protocol.h"
int main(void) {
    unsigned mode = 99;
    PCSession s;
    PCStartSession(&s, 17);
    assert(!s.received);
    assert(!PCAcceptResponse(&s, 4)); // Legacy cached mode cannot be applied.
    assert(!PCAcceptResponse(&s, PCResponse(16,4)));
    assert(!PCAcceptResponse(&s, PCRequest(17)));
    assert(!PCAcceptResponse(&s, PC_STATUS_TAG | (17ULL<<8) | 4));
    assert(!s.received);
    for (unsigned m=0;m<=4;++m) {
        assert(PCAcceptResponse(&s,PCResponse(17,m)));
        assert(s.received && s.mode==m);
    }
    PCStartSession(&s,18);
    assert(!s.received && !PCAcceptResponse(&s,PCResponse(17,4)));
    assert(!PCAcceptResponse(&s,PCResponse(18,5)));
    assert(!PCAcceptResponse(&s,PCResponse(18,255)));
    assert(!s.received); // Transport failure/invalid reply never becomes Off.
    assert(PCAcceptResponse(&s,PCResponse(18,0)) && s.mode==0);
    assert(!PCValidRequest(0));
    assert(!PCValidRequest(PCRequest(0)));
    assert(!PCValidRequest(PCRequest(1)|1));
    assert(PCValidRequest(PCRequest(PC_NONCE_MASK)));
    assert(PCNonce(PCRequest(PC_NONCE_MASK))==PC_NONCE_MASK);
    assert(PCDecodeResponse(PCResponse(PC_NONCE_MASK,4),PC_NONCE_MASK,&mode) && mode==4);
    assert(!PCDecodeResponse(PCResponse(1,0),0,&mode));
    assert(!PCDecodeResponse(PCResponse(1,0),PC_NONCE_MASK+1,&mode));
    puts("PASS: production session codec, all modes, stale/legacy/malformed replies, restart and nonce boundaries");
}
