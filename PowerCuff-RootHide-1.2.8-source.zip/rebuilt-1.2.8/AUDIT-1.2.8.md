# 1.2.8 复审：控制中心发现与诊断

直接基线1.2.7实际DEB SHA256 2c9b8f995af9609018739ca3d2e981f130a5185bf1aa74926cce2b20eaa7507d。用户确认安装后控制中心列表无模块；截图表明两个包均iphoneos-arm64e、模块文件与UIDeviceFamily存在。CCSupport实际注入、用户空间重启状态和设备bundle预检结果尚无证据，根因未确定。不得宣称已修复显示问题或通过全部真机功能。

本轮修补验证链缺口，不猜改温控参数：

- 包验证新增Mach-O符号/节表检查，确认PowercuffCCModule及控制器是__objc_data中的已定义外部类符号，非只出现名字/未定义导入。添加6组Python反例及一类真实包导出名变异，包反例计划23类。
- 新增pcctl module-check ABSOLUTE_BUNDLE_PATH。调用者使用jbroot命令解析当前RootHide路径；工具只读模块/CCSupport文件及注入filter，核对元数据/设备族/执行权限，并调用NSBundle preflightAndReturnError，输出结构化错误。不会调用principalClass、loadAndReturnError、实例化模块、发通知、写配置或重启进程。
- 苹果文档明确preflight不加载可执行代码，也不能检出所有链接错误；通过不证明Settings/SpringBoard注入、真实模块发现或热控有效。四组Foundation诊断测试已加入待macOS执行链，覆盖正确/缺文件、错误字段/权限/filter、预检失败和只读性。
- 热控核心、协议、偏好解析、CC交互、LPM和故障熔断与1.2.7字节不变；设置仅版本页脚更新。未删除模块备份、改CCSupport配置或强制白名单。

执行：在NewTerm中运行

    pcctl module-check "$(jbroot /Library/ControlCenter/Bundles/PowercuffCC.bundle)"

输出包含当前物理路径，仅用于设备诊断，不会自动上传。返回0只表示本工具所检查文件/元数据和预检未失败，绝不表示所有功能已验证。若返回非零，保留JSON输出定位。即使返回0仍需核对CCSupport已在Settings和SpringBoard加载。

源码公开上传与新macOS构建结果以本轮交付报告为准；封存时不预写成功。未连接目标设备iPhone15,3/iOS16.5/RootHide Dopamine3.0.4。
