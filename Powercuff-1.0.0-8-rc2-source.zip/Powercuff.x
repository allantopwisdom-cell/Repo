// Based on rpetrich/Powercuff and Mikasa-san/Powercuff. See README.md.
#import <Foundation/Foundation.h>
#import <notify.h>
#import <unistd.h>
#import "Protocol.h"
#import "Preferences.h"
#import "Runtime.h"

@interface CommonProduct : NSObject
- (void)putDeviceInThermalSimulationMode:(NSString *)mode;
@end
static const char *const responseName = "com.powercuff.roothide.v2.response";
static const char *const requestName = "com.powercuff.roothide.v2.request";
static const char *const settingsName = "com.rpetrich.powercuff.settingschanged";
static const char *const statusName = "com.powercuff.roothide.v2.status";
static int responseState = -1, responseEvent = -1, requestState = -1, requestEvent = -1;
static int settingsEvent = -1, statusToken = -1;
static BOOL active;
static PCSession session;
static uint64_t refreshGeneration;
static NSHashTable<CommonProduct *> *products;
static NSMapTable<CommonProduct *, NSNumber *> *applied;
static NSMapTable<CommonProduct *, NSNumber *> *failures;
static id lowPowerObserver;

static void PCCancel(int *token) { if (*token >= 0) notify_cancel(*token); *token = -1; }
static void PCCleanup(void) {
    active = NO;
    PCCancel(&responseState); PCCancel(&responseEvent); PCCancel(&requestState);
    PCCancel(&requestEvent); PCCancel(&settingsEvent); PCCancel(&statusToken);
    if (lowPowerObserver) [NSNotificationCenter.defaultCenter removeObserver:lowPowerObserver];
    lowPowerObserver = nil;
}
// Status is bound to this daemon session; method return is not proof of actual throttling.
static void PCReport(unsigned code) {
    if (statusToken >= 0) notify_set_state(statusToken, PC_STATUS_TAG | (session.nonce << 8) | code);
}
static NSString *PCModeString(unsigned mode) {
    switch (mode) {
        case 1: return @"nominal"; case 2: return @"light";
        case 3: return @"moderate"; case 4: return @"heavy";
        default: return @"off";
    }
}
static void PCApply(void) {
    if (!active || !session.received) return;
    NSArray<CommonProduct *> *liveProducts = products.allObjects;
    if (liveProducts.count == 0) { PCReport(10); return; }
    unsigned errorCode = 0;
    for (CommonProduct *product in liveProducts) {
        NSNumber *failure = [failures objectForKey:product];
        if (failure) { errorCode = MAX(errorCode, failure.unsignedIntValue); continue; }
        if (!PCCheckProductABI(object_getClass(product))) {
            [failures setObject:@99 forKey:product];
            errorCode = 99;
            NSLog(@"[Powercuff] Unsupported receiver ABI; receiver quarantined.");
            continue;
        }
        NSNumber *previous = [applied objectForKey:product];
        if (previous && previous.unsignedIntValue == session.mode) continue;
        @try {
            [product putDeviceInThermalSimulationMode:PCModeString(session.mode)];
            [applied setObject:@(session.mode) forKey:product];
            NSLog(@"[Powercuff] Requested %@; method returned, hardware effect unverified.", PCModeString(session.mode));
        } @catch (NSException *exception) {
            [failures setObject:@98 forKey:product];
            errorCode = MAX(errorCode, 98U);
            NSLog(@"[Powercuff] %@; receiver quarantined. Existing simulation may remain; disable tweak and restart thermalmonitord.", exception.name);
        }
    }
    PCReport(errorCode ? errorCode : session.mode);
}
static BOOL PCReadResponse(void) {
    if (!active) return NO;
    uint64_t value = 0;
    if (notify_get_state(responseState, &value) != NOTIFY_STATUS_OK) return NO;
    if (!PCAcceptResponse(&session, value)) return NO;
    PCApply();
    return YES;
}
static void PCPublish(void) {
    if (!active) return;
    uint64_t request = 0;
    if (notify_get_state(requestState, &request) != NOTIFY_STATUS_OK || !PCValidRequest(request)) return;
    Boolean synchronized = CFPreferencesSynchronize(CFSTR("com.rpetrich.powercuff"), kCFPreferencesCurrentUser, kCFPreferencesAnyHost);
    NSDictionary *snapshot = CFBridgingRelease(CFPreferencesCopyMultiple(
        (__bridge CFArrayRef)@[@"PowerMode", @"RequireLowPowerMode"],
        CFSTR("com.rpetrich.powercuff"), kCFPreferencesCurrentUser, kCFPreferencesAnyHost));
    unsigned mode = PCNormalizeSettings(snapshot, synchronized, NSProcessInfo.processInfo.lowPowerModeEnabled);
    // Verify daemon did not replace its session while preferences were read.
    uint64_t current = 0;
    if (!active || notify_get_state(requestState, &current) != NOTIFY_STATUS_OK || current != request) return;
    if (notify_set_state(responseState, PCResponse(PCNonce(request), mode)) != NOTIFY_STATUS_OK ||
        notify_post(responseName) != NOTIFY_STATUS_OK)
        NSLog(@"[Powercuff] State publication failed; finite refresh will retry.");
}
static void PCRefreshSettings(void) {
    if (!active) return;
    uint64_t generation = ++refreshGeneration;
    PCPublish();
    for (NSNumber *delay in @[@0.15, @0.60]) {
        dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(delay.doubleValue * NSEC_PER_SEC)),
            dispatch_get_main_queue(), ^{
                if (active && generation == refreshGeneration) PCPublish();
            });
    }
}
static void PCSendRequest(void) {
    if (!active || session.received) return;
    if (notify_set_state(requestState, PCRequest(session.nonce)) != NOTIFY_STATUS_OK || notify_post(requestName) != NOTIFY_STATUS_OK)
        NSLog(@"[Powercuff] Request publication failed; finite retry pending.");
}
static void PCBeginSession(void) {
    if (!active || products.count == 0) return;
    uint64_t nonce;
    do { arc4random_buf(&nonce, sizeof(nonce)); nonce &= PC_NONCE_MASK; } while (!nonce || nonce == session.nonce);
    PCStartSession(&session, nonce);
    PCReport(10); // Waiting; prior simulation may remain.
    PCSendRequest();
    // Four requests maximum per explicit event/object session, no continuous polling.
    for (NSNumber *delay in @[@0.15, @0.60, @1.50]) {
        dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(delay.doubleValue * NSEC_PER_SEC)),
            dispatch_get_main_queue(), ^{
                if (active && session.nonce == nonce && !session.received) {
                    if (!PCReadResponse()) PCSendRequest();
                }
            });
    }
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, 2 * NSEC_PER_SEC), dispatch_get_main_queue(), ^{
        if (active && session.nonce == nonce && !session.received && !PCReadResponse()) {
            PCReport(11);
            NSLog(@"[Powercuff] No current-session response. Existing simulation may remain; change settings or restart services.");
        }
    });
}
static BOOL PCRegisterState(const char *name, int *token) {
    if (notify_register_check(name, token) == NOTIFY_STATUS_OK) return YES;
    *token = -1;
    return NO;
}
%group Thermal
%hook CommonProduct
- (id)initProduct:(id)data {
    id product = %orig(data);
    if (product) {
        __weak CommonProduct *weakProduct = product;
        dispatch_async(dispatch_get_main_queue(), ^{
            CommonProduct *live = weakProduct;
            if (!active || !live) return;
            [products addObject:live];
            [applied removeObjectForKey:live];
            PCBeginSession();
        });
    }
    return product;
}
%end
%end
%ctor {
    @autoreleasepool {
        NSString *process = NSProcessInfo.processInfo.processName;
        BOOL thermal = [process isEqualToString:@"thermalmonitord"];
        BOOL springboard = [process isEqualToString:@"SpringBoard"] && getuid() == 501;
        if (!thermal && !springboard) return;
        if (!PCRegisterState(responseName, &responseState) || !PCRegisterState(requestName, &requestState)) {
            PCCleanup(); NSLog(@"[Powercuff] State registration failed; inactive."); return;
        }
        if (thermal) {
            Class productClass = NSClassFromString(@"CommonProduct");
            if (!PCCheckProductABI(productClass)) { PCCleanup(); NSLog(@"[Powercuff] Unsupported CommonProduct; no hook installed."); return; }
            NSPointerFunctionsOptions keys = NSPointerFunctionsWeakMemory | NSPointerFunctionsObjectPointerPersonality;
            products = [NSHashTable hashTableWithOptions:keys];
            applied = [NSMapTable mapTableWithKeyOptions:keys valueOptions:NSPointerFunctionsStrongMemory];
            failures = [NSMapTable mapTableWithKeyOptions:keys valueOptions:NSPointerFunctionsStrongMemory];
            if (!PCRegisterState(statusName, &statusToken) ||
                notify_register_dispatch(responseName, &responseEvent, dispatch_get_main_queue(), ^(int t) {
                    (void)t; if (active) PCReadResponse();
                }) != NOTIFY_STATUS_OK ||
                notify_register_dispatch(settingsName, &settingsEvent, dispatch_get_main_queue(), ^(int t) {
                    (void)t; if (active) PCBeginSession();
                }) != NOTIFY_STATUS_OK) { PCCleanup(); NSLog(@"[Powercuff] Thermal registration failed; no hook installed."); return; }
            // Constructor activation is serialized before any main-queue callback.
            dispatch_async(dispatch_get_main_queue(), ^{ active = YES; PCReport(10); });
            // Install before daemon main() can create its first product. The hook's
            // queued work follows activation on the same main queue.
            %init(Thermal, CommonProduct = productClass);
        } else {
            if (notify_register_dispatch(settingsName, &settingsEvent, dispatch_get_main_queue(), ^(int t) {
                    (void)t; if (active) PCRefreshSettings();
                }) != NOTIFY_STATUS_OK ||
                notify_register_dispatch(requestName, &requestEvent, dispatch_get_main_queue(), ^(int t) {
                    (void)t; if (active) PCRefreshSettings();
                }) != NOTIFY_STATUS_OK) { PCCleanup(); NSLog(@"[Powercuff] Publisher registration failed; inactive."); return; }
            lowPowerObserver = [NSNotificationCenter.defaultCenter addObserverForName:NSProcessInfoPowerStateDidChangeNotification
                object:nil queue:NSOperationQueue.mainQueue usingBlock:^(NSNotification *note) { (void)note; if (active) PCRefreshSettings(); }];
            if (!lowPowerObserver) { PCCleanup(); NSLog(@"[Powercuff] Low-power observer failed; inactive."); return; }
            dispatch_async(dispatch_get_main_queue(), ^{ active = YES; PCRefreshSettings(); });
        }
    }
}
