"""Verify exact release inputs; build outputs are explicitly excluded, not trusted as source."""
import hashlib,json,pathlib,re,sys
from package_format import UniqueDictionary

def verify(root):
    root=pathlib.Path(root).resolve()
    manifest=json.loads((root/'SOURCE-SHA256.json').read_text(),object_pairs_hook=lambda pairs:unique(pairs))
    assert manifest and type(manifest) is UniqueDictionary, 'source manifest missing/invalid'
    for name,digest in manifest.items():
        path=pathlib.PurePosixPath(name)
        assert not path.is_absolute() and all(x not in ('','.','..') for x in name.split('/')), 'source manifest unsafe path'
        assert type(digest) is str and re.fullmatch('[0-9a-f]{64}',digest), 'source digest invalid'
        p=root/name
        assert p.is_file() and not p.is_symlink() and hashlib.sha256(p.read_bytes()).hexdigest()==digest, 'source input hash mismatch: '+name
    actual={str(p.relative_to(root)) for p in root.rglob('*') if p.is_file()
            and not any(x in ('.theos','packages','__pycache__') for x in p.relative_to(root).parts)
            and str(p.relative_to(root)) not in ('SOURCE-SHA256.json','BUILD-LOG.txt')}
    assert actual==set(manifest), 'source input set differs'
    return len(manifest)
def unique(pairs):
    d=UniqueDictionary()
    for k,v in pairs:d[k]=v
    return d
if __name__=='__main__':print('Source inputs:',verify(pathlib.Path(__file__).resolve().parents[1]),'hashes and exact set PASS')
