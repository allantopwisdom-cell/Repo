import pathlib,plistlib,struct,sys,unittest,zlib
def clone(value):return plistlib.loads(plistlib.dumps(value))
r=pathlib.Path(__file__).resolve().parents[1]
sys.path.insert(0,str(r/'scripts'))
from package_format import load_plist
from module_contract import validate_module,validate_preferences,validate_png
info=load_plist((r/'cc/Info.plist').read_bytes())
panel=load_plist((r/'layout/Library/PreferenceLoader/Preferences/Powercuff/Powercuff.plist').read_bytes())
resources=[(r/'cc/Resources'/n,size) for n,size in [('Icon@2x.png',(96,96)),('Icon@3x.png',(144,144)),('SettingsIcon@2x.png',(58,58)),('SettingsIcon@3x.png',(87,87))]]
resources += [(r/'layout/Library/PreferenceLoader/Preferences/Powercuff'/n,size) for n,size in [('Powercuff@2x.png',(58,58)),('Powercuff@3x.png',(87,87)),('icon.png',(29,29))]]
class ContractTests(unittest.TestCase):
    def test_valid_inputs(self):
        validate_module(info,'1.2.6');validate_preferences(panel)
        for p,dimensions in resources:validate_png(p.read_bytes(),dimensions)
    def test_missing_family(self):
        obj=clone(info);obj.pop('UIDeviceFamily')
        with self.assertRaisesRegex(AssertionError,'UIDeviceFamily'):validate_module(obj,'1.2.6')
    def test_wrong_discovery_types(self):
        for key,value in [('UIDeviceFamily',[True,2]),('CFBundleVersion','125'),('NSPrincipalClass','Wrong'),('CCSGetModuleSizeAtRuntime',0)]:
            obj=clone(info);obj[key]=value
            with self.subTest(key=key),self.assertRaises(AssertionError):validate_module(obj,'1.2.6')
    def test_notification_mismatch(self):
        obj=clone(panel)
        for item in obj['items']:
            if 'key' in item:item['PostNotification']='com.dao.powercuff.update'
        with self.assertRaisesRegex(AssertionError,'notification'):validate_preferences(obj)
    def test_domain_duplicate_and_profile_types(self):
        for case in range(3):
            obj=clone(panel);keyed=[x for x in obj['items'] if 'key' in x]
            if case==0:keyed[0]['defaults']='com.rpetrich.powercuff'
            if case==1:obj['items'].append(clone(keyed[0]))
            if case==2:keyed[0]['validValues'][0]=False
            with self.subTest(case=case),self.assertRaises(AssertionError):validate_preferences(obj)
    def test_png_crc(self):
        b=bytearray(resources[0][0].read_bytes());b[29]^=1
        with self.assertRaisesRegex(AssertionError,'CRC'):validate_png(b,resources[0][1])
    def test_png_truncation_and_dimensions(self):
        b=resources[0][0].read_bytes()
        with self.assertRaises(AssertionError):validate_png(b[:-1],resources[0][1])
        with self.assertRaisesRegex(AssertionError,'dimensions'):validate_png(b,(1,1))
    def test_png_trailer(self):
        with self.assertRaisesRegex(AssertionError,'trailer'):validate_png(resources[0][0].read_bytes()+b'EXTRA',resources[0][1])
if __name__=='__main__':unittest.main(verbosity=2)
