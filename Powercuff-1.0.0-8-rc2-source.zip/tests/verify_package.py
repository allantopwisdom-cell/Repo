import hashlib, plistlib, subprocess, sys, tempfile, tarfile
from pathlib import Path
package=Path(sys.argv[1]).resolve();root=Path(__file__).resolve().parents[1]
assert subprocess.check_output(['dpkg-deb','-f',str(package),'Package'],text=True).strip()=='com.baldaran.powercuff-r3vamp'
assert subprocess.check_output(['dpkg-deb','-f',str(package),'Architecture'],text=True).strip()=='iphoneos-arm64e'
assert subprocess.check_output(['dpkg-deb','-f',str(package),'Version'],text=True).strip()=='1.0.0-8~rc2+roothide16.5'
with tempfile.TemporaryDirectory() as tmp:
    tmp=Path(tmp);out=tmp/'pkg'
    subprocess.run(['dpkg-deb','-R',str(package),str(out)],check=True)
    dylib=out/'Library/MobileSubstrate/DynamicLibraries/Powercuff.dylib'
    subprocess.run([sys.executable,str(root/'tests/verify_macho.py'),str(dylib)],check=True)
    for script in ['postinst','postrm']:
        p=out/'DEBIAN'/script
        assert p.read_bytes()==(root/'layout/DEBIAN'/script).read_bytes()
        assert p.stat().st_mode & 0o111
    pref=Path('Library/PreferenceLoader/Preferences/Powercuff/Powercuff.plist')
    assert plistlib.loads((out/pref).read_bytes())==plistlib.loads((root/'layout'/pref).read_bytes())
    filter=plistlib.loads((out/'Library/MobileSubstrate/DynamicLibraries/Powercuff.plist').read_bytes())
    assert filter=={'Filter':{'Executables':['thermalmonitord','SpringBoard']}}
    payload=tmp/'payload.tar'
    with payload.open('wb') as f:subprocess.run(['dpkg-deb','--fsys-tarfile',str(package)],stdout=f,check=True)
    with tarfile.open(payload) as tf:
        files={m.name.removeprefix('./') for m in tf if m.isfile()}
        assert files=={str(pref),'Library/MobileSubstrate/DynamicLibraries/Powercuff.dylib','Library/MobileSubstrate/DynamicLibraries/Powercuff.plist'}
        for m in tf:
            assert m.uid==0 and m.gid==0
            assert not m.issym() and not m.islnk()
    # Ensure the code-page checker rejects real payload tampering.
    altered=bytearray(dylib.read_bytes());altered[4096]^=1
    mutated=tmp/'mutated.dylib';mutated.write_bytes(altered)
    result=subprocess.run([sys.executable,str(root/'tests/verify_macho.py'),str(mutated)],capture_output=True)
    assert result.returncode!=0,'mutated payload unexpectedly accepted'
print('PASS: package metadata, exact payload, script/source and plist/source comparison, root ownership, signature tamper rejection')
print('SHA256',hashlib.sha256(package.read_bytes()).hexdigest())
