#import <Foundation/Foundation.h>
#import <assert.h>
#import "../Protocol.h"
#import "../Runtime.h"
@interface CommonProduct : NSObject
@property unsigned calls;
@property unsigned mode;
@property BOOL shouldThrow;
- (id)initProduct:(id)data;
- (void)putDeviceInThermalSimulationMode:(NSString *)mode;
@end
@implementation CommonProduct
- (id)initProduct:(id)data { (void)data; return self; }
- (BOOL)isEqual:(id)other { return [other isKindOfClass:CommonProduct.class]; }
- (NSUInteger)hash { return 1; }
- (void)putDeviceInThermalSimulationMode:(NSString *)mode {
    self.calls++;
    if(self.shouldThrow) [NSException raise:@"FixtureFailure" format:@"simulated"];
    self.mode=(unsigned)[@[@"off",@"nominal",@"light",@"moderate",@"heavy"] indexOfObject:mode];
}
@end
static BOOL active;
static PCSession session;
static NSHashTable<CommonProduct *> *products;
static NSMapTable<CommonProduct *,NSNumber *> *applied,*failures;
static unsigned lastStatus;
static void PCReport(unsigned code) { lastStatus=code; }
// ACTUAL_PRODUCTION_FUNCTIONS
static void TestApply(void) { @autoreleasepool { PCApply(); } }
int main(void) { @autoreleasepool {
    NSPointerFunctionsOptions keys=NSPointerFunctionsWeakMemory|NSPointerFunctionsObjectPointerPersonality;
    products=[NSHashTable hashTableWithOptions:keys];
    applied=[NSMapTable mapTableWithKeyOptions:keys valueOptions:NSPointerFunctionsStrongMemory];
    failures=[NSMapTable mapTableWithKeyOptions:keys valueOptions:NSPointerFunctionsStrongMemory];
    __weak CommonProduct *weakA;
    @autoreleasepool {
    CommonProduct *a=[CommonProduct new],*b=[CommonProduct new];
    [products addObject:a];[products addObject:b];
    assert(products.count==2); // isEqual deliberately says equal; identity must win.
    PCStartSession(&session,42);session.mode=3;
    TestApply(); assert(a.calls==0&&b.calls==0);
    active=YES; TestApply(); assert(a.calls==0&&b.calls==0);
    session.received=true; TestApply();
    assert(a.calls==1&&b.calls==1&&a.mode==3&&b.mode==3&&lastStatus==3);
    TestApply(); assert(a.calls==1&&b.calls==1);
    a.shouldThrow=YES;session.mode=2;TestApply();
    assert(a.calls==2&&b.calls==2&&b.mode==2&&lastStatus==98);
    session.mode=1;TestApply();
    assert(a.calls==2&&b.calls==3&&b.mode==1&&lastStatus==98);
    weakA=a;a=nil;
    CommonProduct *c=[CommonProduct new];[products addObject:c];TestApply();
    assert(c.calls==1&&c.mode==1&&b.calls==3&&lastStatus==1);
    [applied removeObjectForKey:b];TestApply();assert(b.calls==4);
    b=nil;c=nil;
    } // Drain weak-load/autoreleased snapshot temporaries before lifetime assertions.
    assert(weakA==nil);
    assert(products.allObjects.count==0);
    TestApply();assert(lastStatus==10); // No live receiver cannot mean successfully applied.
    puts("PASS: extracted production apply code, inactive/waiting guards, identity, dedup, reinit, exception isolation, weak lifetime and empty receiver status");
} return 0; }
