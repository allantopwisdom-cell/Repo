/*
 * Copyright (c) 2005-2021 Apple Inc. All rights reserved.
 *
 * @APPLE_OSREFERENCE_LICENSE_HEADER_START@
 *
 * This file contains Original Code and/or Modifications of Original Code
 * as defined in and that are subject to the Apple Public Source License
 * Version 2.0 (the 'License'). You may not use this file except in
 * compliance with the License. The rights granted to you under the License
 * may not be used to create, or enable the creation or redistribution of,
 * unlawful or unlicensed copies of an Apple operating system, or to
 * circumvent, violate, or enable the circumvention or violation of, any
 * terms of an Apple operating system software license agreement.
 *
 * Please obtain a copy of the License at
 * http://www.opensource.apple.com/apsl/ and read it before using this file.
 *
 * The Original Code and all software distributed under the License are
 * distributed on an 'AS IS' basis, WITHOUT WARRANTY OF ANY KIND, EITHER
 * EXPRESS OR IMPLIED, AND APPLE HEREBY DISCLAIMS ALL SUCH WARRANTIES,
 * INCLUDING WITHOUT LIMITATION, ANY WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE, QUIET ENJOYMENT OR NON-INFRINGEMENT.
 * Please see the License for the specific language governing rights and
 * limitations under the License.
 *
 * @APPLE_OSREFERENCE_LICENSE_HEADER_END@
 */

// Minimal ABI declarations from xnu-8796.101.5 for SDKs without libproc headers.
// Modified 2026: namespaced constants/struct, no private-header dependency.
// Only interface declarations; no Apple implementation code is included.
#ifndef VDT_PROC_COMPAT_H
#define VDT_PROC_COMPAT_H
#include <stdint.h>
#include <stddef.h>
#define VDT_PROC_ALL_PIDS 1
#define VDT_PROC_PIDTBSDINFO 3
#define VDT_PROC_PIDPATHINFO_MAXSIZE 4096
typedef struct {
    uint32_t pbi_flags, pbi_status, pbi_xstatus, pbi_pid, pbi_ppid;
    uint32_t pbi_uid, pbi_gid, pbi_ruid, pbi_rgid, pbi_svuid, pbi_svgid, rfu_1;
    char pbi_comm[16];
    char pbi_name[32];
    uint32_t pbi_nfiles, pbi_pgid, pbi_pjobc, e_tdev, e_tpgid;
    int32_t pbi_nice;
    uint64_t pbi_start_tvsec, pbi_start_tvusec;
} VDTProcBSDInfo;
typedef int (*VDTListPIDsFn)(uint32_t,uint32_t,void *,int);
typedef int (*VDTPIDInfoFn)(int,int,uint64_t,void *,int);
typedef int (*VDTPIDPathFn)(int,void *,uint32_t);
#ifdef __cplusplus
static_assert(sizeof(VDTProcBSDInfo)==136,"proc_bsdinfo ABI size");
static_assert(offsetof(VDTProcBSDInfo,pbi_start_tvsec)==120,"proc_bsdinfo start offset");
static_assert(offsetof(VDTProcBSDInfo,pbi_start_tvusec)==128,"proc_bsdinfo microseconds offset");
#else
_Static_assert(sizeof(VDTProcBSDInfo)==136,"proc_bsdinfo ABI size");
_Static_assert(offsetof(VDTProcBSDInfo,pbi_start_tvsec)==120,"proc_bsdinfo start offset");
_Static_assert(offsetof(VDTProcBSDInfo,pbi_start_tvusec)==128,"proc_bsdinfo microseconds offset");
#endif
#endif

