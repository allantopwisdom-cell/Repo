// GPLv3. Shared strict schema validation for runtime and preferences.
#import <Foundation/Foundation.h>
#import <CoreFoundation/CoreFoundation.h>
#include "VDTPolicy.h"
#include <string.h>
#include <errno.h>
#include <stdlib.h>
static inline BOOL VDTIntegerObject(id value) {
    if(![value isKindOfClass:NSNumber.class] || CFGetTypeID((__bridge CFTypeRef)value)==CFBooleanGetTypeID())return NO;
    const char *type=[value objCType];return type && type[0] && type[1]==0 && strchr("csilqCSILQ",type[0]);
}
static inline BOOL VDTInteger(id value,int minimum,int maximum,int *result) {
    if(![value isKindOfClass:NSString.class] && !VDTIntegerObject(value))return NO;
    NSString *text=[value isKindOfClass:NSString.class]?value:[value stringValue];
    NSData *bytes=[text dataUsingEncoding:NSUTF8StringEncoding];
    if(!bytes || bytes.length==0 || bytes.length>32 || bytes.length!=strlen(text.UTF8String))return NO;
    return vdt_parse_integer(text.UTF8String,minimum,maximum,result);
}
static inline BOOL VDTFlag(id value,BOOL *result) {
    if(!result)return NO;
    if([value isKindOfClass:NSNumber.class] && CFGetTypeID((__bridge CFTypeRef)value)==CFBooleanGetTypeID()){*result=[value boolValue];return YES;}
    int n=0;if(!VDTInteger(value,0,1,&n))return NO;*result=n!=0;return YES;
}
static inline BOOL VDTFlagOr(id value,BOOL fallback) {BOOL flag=NO;return VDTFlag(value,&flag)?flag:fallback;}
static inline BOOL VDTUnsigned(id value,uint64_t maximum,uint64_t *result) {
    if(!VDTIntegerObject(value) || !result)return NO;
    const char *text=[[value stringValue] UTF8String];if(!text || !*text)return NO;
    for(const char *p=text;*p;p++)if(*p<'0'||*p>'9')return NO;
    errno=0;char *end=NULL;unsigned long long number=strtoull(text,&end,10);
    if(errno || !end || *end || number>maximum)return NO;*result=number;return YES;
}
static inline BOOL VDTIdentifier(id value) {
    if(![value isKindOfClass:NSString.class] || ![value length] || [value length]>512)return NO;
    NSData *bytes=[value dataUsingEncoding:NSUTF8StringEncoding];
    if(!bytes || bytes.length!=[value length])return NO;
    const unsigned char *s=(const unsigned char *)bytes.bytes;
    for(NSUInteger i=0;i<bytes.length;i++)if(!((s[i]>='a'&&s[i]<='z')||(s[i]>='A'&&s[i]<='Z')||(s[i]>='0'&&s[i]<='9')||s[i]=='.'||s[i]=='_'||s[i]=='-'))return NO;
    return YES;
}
static inline BOOL VDTAbsolutePath(id value) {
    return [value isKindOfClass:NSString.class] && [value hasPrefix:@"/"] && [value length]>1 && [value length]<=4096 &&
        [value rangeOfCharacterFromSet:NSCharacterSet.controlCharacterSet].location==NSNotFound &&
        [[value stringByStandardizingPath] isEqual:value] && ![value hasSuffix:@"/"];
}
