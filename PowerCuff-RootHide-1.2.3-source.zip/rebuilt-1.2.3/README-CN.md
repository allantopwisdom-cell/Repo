# PowerCuff RootHide Rebuilt 1.2.3

目标：iPhone 14 Pro Max / iPhone15,3 / iOS 16.5 / RootHide Dopamine 3.0.4。

此工程根据上传的 1.2.2 DEB 的功能逆向结果重建，核心采用用户已有 allantopwisdom-cell/Repo 的 Powercuff 1.3.13 通信与接口检查实现并作适配；不是原作者完整源码恢复。保留五档热模拟、仅低电模式门控、PreferenceLoader 和原生控制中心菜单。生产主插件、控制中心和诊断工具均从源码编译，未复用 1.2.2 的 Mach-O。

## 构建

固定 RootHide Theos：cfba89a53a05b4a1b822121158acc3669c20602f。
固定 theos/sdks：0222fd5413cf4b9af096f37b4621afa2688572f7，使用 iPhoneOS16.5.sdk。
macOS 15 / Xcode 16.4。RootHide Theos 依赖与 SDK 就绪后：

```sh
export THEOS=/absolute/path/to/theos-roothide
sh build.sh
```

产物预期路径为 packages/com.powercuff.roothide_1.2.3_iphoneos-arm64e.deb。只有构建命令成功并通过 verify_package.py 才能把它称为已编译交付；本说明不是构建成功证据。

随工程附上 .github/workflows/powercuff-rebuilt.yml，可在已授权的 allantopwisdom-cell/Repo 的 rebuild/powercuff-1.2.3 分支运行并上传 DEB 和证据。

## 安装和验证

1. 备份现有插件配置，先卸载冲突的其他 Powercuff；首次测试关闭 Hello CPU 等其他热管理插件。
2. 安装 DEB。安装器不停止/强杀 thermalmonitord。
3. 使用越狱工具提供的“重启用户空间”，让 SpringBoard 和 thermalmonitord 都加载本版。单独 respring 不一定重载 thermalmonitord。
4. 添加 PowerCuff 控制中心模块，依次验证关闭→轻度→关闭。默认档位为关闭，但已有 com.dao.powercuff 保存值会沿用。
5. 验证低电模式门控开关与实际系统低电量模式切换。控制中心分别显示选中档位及接口返回档位；接口返回不等于频率、电流或节能效果测量。
6. 在手机终端执行 `pcctl status` 可读会话状态；其结果是快照，不是实时心跳证明。
7. 卸载前维护脚本会调用 `pcctl disable`，最多等待 3 秒。只有 thermalmonitord 的接口返回并写回匹配随机值才认为收到关闭确认。收不到确认会提示用户空间重启，且不会阻止卸载。

## 范围

不再提供直接改写 com.apple.coreduetd.batterysaver 的未经验证选项，也不盲目恢复这些设置的旧值。过往 1.2.2 写过的值需要根据用户备份处理；本版无法知道其修改前值。

没有固定频率/充电限流功能，没有 A16 专属频率表。不能从编译与包验证推导零 watchdog、真机 PAC 兼容或确定续航增益。信号崩溃无法用 Objective-C 异常捕获兜底。
