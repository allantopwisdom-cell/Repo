#include "PCShortcut.h"
#include <assert.h>
#include <limits.h>
#include <stdio.h>
int main(void) {
    for (unsigned selected=0;selected<=4;++selected)
        for (unsigned last=0;last<=4;++last)
            assert(PCShortcutTarget(selected,last)==(selected ? 0 : last ? last : 2));
    assert(PCShortcutTarget(0,UINT_MAX)==2);
    assert(PCShortcutTarget(UINT_MAX,0)==2);
    assert(PCShortcutTarget(UINT_MAX,3)==3);
    puts("Shortcut: 25 profile/remembered combinations and invalid fallback PASS");
}
