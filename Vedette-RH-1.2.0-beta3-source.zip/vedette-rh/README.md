# Vedette RH Development 1.2.0~beta3

面向 iPhone 14 Pro Max（iPhone15,3）/ iOS 16.5（20F66）/ RootHide Dopamine 3.0.4 的开发分支。

**开发版本：1.2.0~beta3。编译结果以匹配提交的 GitHub Actions 产物为准；尚未完成设备安装或真机验证。**

上游：https://github.com/udevsharold/vedette
基线：e406387f9fd06bc352e36beaa9163e816705164e，版本 1.1.4。
开发分支保留 GPLv3；Choicy 派生文件保留原 MIT 版权声明。VDTProcCompat.h 保留 Apple 接口声明的 APSL 2.0 声明与许可证副本。

## 本版改变

- 修复 PID 枚举将字节数当数量的问题，使用 RAII 释放缓冲区。
- 每个进程记录绑定自己的规则、完整路径和启动时间，不依赖平行数组顺序。
- 单串行队列统一处理发现、配置变化、恢复与应用。
- 仅向 runningboardd 注入，不再向被管理的每个进程注入。
- 每 30 秒枚举 PID，容差 5 秒；不采样 CPU，不承诺短命进程可被捕获。
- 先恢复旧策略，再切换新策略；全局关闭、单项关闭、删除规则、开启 dry-run 都触发恢复。
- 应用前写恢复日志，重载控制器时先清理日志中的旧策略；恢复失败保留记录。
- 拒绝关键进程，独立检查执行接口能力与参数；Terminate 需要额外总开关。
- 仅允许 20–100 的整数百分比；Terminate 时间窗口为 60–3600 秒。
- 新增状态查看；无状态不能视作已生效，检查状态时间是否新鲜。
- 原安装/卸载脚本的强杀 runningboardd 已移除；有恢复日志时阻止普通卸载。
- RootHide Theos 构建配置、arm64e 目标和偏好路径调整。
- UI 使用系统 SF Symbols，未包含上游 PNG 美术资源；功能源码与许可证已保留。

## 默认状态

全局 Enabled 默认关闭，Dry run 默认开启，Allow Terminate 默认关闭；单进程默认关闭，默认策略改为 Throttle。
旧配置仍可读取，但缺失 dryRun 时按 true 处理，避免旧开关直接开启新执行逻辑。

Dry run 只验证进程匹配、规则解析和状态输出，不读取 CPU 使用率，也不施加新限制。
从执行状态切入 dry-run 时会恢复本插件已记录的限制，因此仍可能调用清理 API。

## 构建

需要完整 RootHide Theos、带 arm64e 支持的编译链接工具链、iOS SDK、RootHide 开发头文件/库、AltList 开发 framework，以及 ldid 等 Theos 打包依赖。
运行时另需匹配 RootHide 的 PreferenceLoader、AltList 和注入框架。

```sh
export THEOS=/你的/roothide-theos/实际目录
./scripts/build.sh
./scripts/verify_deb.sh packages/实际生成的包.deb
```

构建脚本不会自动下载或修改工具链。源码初版的本地环境没有这些依赖；GitHub 编译记录以交付的 SOURCE_COMMIT 和 BUILD_RESULT.txt 为准。构建脚本使用 dpkg-deb --root-owner-group 将控制与载荷归档属主统一为 0/0，不修改签名二进制内容。
`verify_deb.sh` 只验证包身份和必要载荷，不能替代 Mach-O、签名与真机检查。

## 验证顺序

1. 在合适的测试设备构建安装后，通过正常 userspace restart 加载插件；仅 respring 不保证 runningboardd 重载。
2. 打开设置，确认 Controller status 的时间新鲜。首次启用只保留 dry-run。
3. 仅添加一个可恢复的非关键测试 App，核对 matched；测试规则关闭、删除、并发启动。
4. 确认参数匹配和身份识别后，再关闭 dry-run 测试 Throttle；核实系统调用成功与真实 CPU 行为。
5. 测试关闭后 tracked=0、日志消失、任务性能恢复；测试控制器重启后的恢复。
6. 最后再评估 Terminate；应先测试非关键进程，不用于 thermalmonitord 等服务。
7. 在任何叠加测试前记录其他插件状态；不要让两个组件同时修改同一进程的 CPU 配额。
8. 卸载前关闭、等待至少 35 秒、核对 tracked=0。异常日志不要直接删除，以免丢失恢复依据。

不要同时安装上游 Vedette。由上游版本迁移前，先在原版清理限制并正常重启用户空间；新分支无法识别上游未记录的所有旧限制。

## 必须理解的边界

- 仍然在 runningboardd 内执行；缩小注入范围不代表消除了服务注入风险。
- PID 启动时间与路径检查降低误操作风险，但 PID 型系统调用仍有检查与使用之间的竞态，不能保证绝对消除。
- CPU monitor 清理恢复系统默认值，不能重建外部组件先前的自定义配置或 fatal 标志。
- Throttle 没有可靠读取先前外部配额的实现，清除时不能保证恢复其他组件的旧配额。
- 写日志采用原子文件替换，未实现对任意突然断电的 fsync 级持久性保证。
- 关键进程名单不是系统所有关键服务的完整证明；未列入名单不代表适合限制。
- RootHide 偏好共享路径、API 权限、注入加载和 arm64e ABI 都仍需真机验证。
- 自发现延迟约 0–35 秒，短命任务可能完全错过；此版没有前台/后台识别。
- 限制正常任务可能导致耗时延长、超时或重试；没有省电幅度或稳定性承诺。

## 主机测试

```sh
./tests/run.sh
```

对实际用于产品的纯 C 参数解析、PID 字节数换算和状态决策函数执行测试；不模拟已完成 iOS 运行测试。
测试环境无法运行 LeakSanitizer 的进程追踪，故禁用泄漏检测；AddressSanitizer 和 UndefinedBehaviorSanitizer 保持启用。
完整记录见 docs/VALIDATION_CN.md。

## beta3 恢复修复

- 初始恢复失败时保留恢复状态，直到清理成功。
- 清理前写入 pending 标记，写回失败后不会误认作已生效。
- PID 列表失败时仍尝试清理已知记录，并发布新的 blocked/discoveryFailed 状态。
- 原始进程身份与可操作进程判断分离，避免 PID 被关键服务复用后永久保留过期记录。
- macOS 上直接编译并执行生产 VDTProcessManager.mm 的故障注入测试；所有系统操作替换成 mock，文件路径限制在独立临时目录。

Linux 的 105 项纯 C 断言不包含 Foundation 管理器测试；macOS 管理器实际通过数量以 CI 日志为准。此测试不执行真实 iOS 私有 API，不代表真机验证。
