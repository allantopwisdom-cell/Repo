#ifndef PC_SHORTCUT_H
#define PC_SHORTCUT_H
// Toggle the saved requested profile. LPM gating is applied independently by PCRValidatedMode.
static inline unsigned PCShortcutTarget(unsigned selected, unsigned last) {
    if (selected>=1 && selected<=4) return 0;
    return last>=1 && last<=4 ? last : 2;
}
#endif
