// Execute the actual production controller with Foundation and small UIKit/notify adapters.
// This is NOT iOS private-framework or device UI validation.
#import <Foundation/Foundation.h>
#import <CoreFoundation/CoreFoundation.h>
#import <notify.h>
#import "PCRProtocol.h"
#import "PCRPreferences.h"
#include <assert.h>
#include <stdio.h>
#include <string.h>

static NSMutableDictionary *TestPrefs;
static NSMutableArray *Actions,*Timers;
static NSMutableDictionary<NSNumber *,NSString *> *TokenNames;
static NSMutableDictionary<NSNumber *,id> *Callbacks;
static BOOL RegisterFails,PostFails,SyncFails,MenuSupported=YES,DetailedMenu=YES,TestLowPower,ReadFails;
static unsigned Posts,Cancels,NextToken,Session=100;
static uint64_t Applied;
static NSString *MenuTitle;
static BOOL TileSelected;
@interface UIViewController : NSObject
- (instancetype)initWithNibName:(id)nib bundle:(id)bundle;
- (void)viewDidLoad;
- (void)viewWillAppear:(BOOL)animated;
@end
@implementation UIViewController
- (instancetype)initWithNibName:(id)nib bundle:(id)bundle {(void)nib;(void)bundle;return [super init];}
- (void)viewDidLoad {}
- (void)viewWillAppear:(BOOL)animated {(void)animated;}
@end
@interface UIImage : NSObject
+ (instancetype)imageNamed:(id)name inBundle:(id)bundle compatibleWithTraitCollection:(id)traits;
+ (instancetype)systemImageNamed:(id)name;
@end
@implementation UIImage
+ (instancetype)imageNamed:(id)name inBundle:(id)bundle compatibleWithTraitCollection:(id)traits {(void)name;(void)bundle;(void)traits;return [self new];}
+ (instancetype)systemImageNamed:(id)name {(void)name;return [self new];}
@end
@interface UIColor : NSObject
+ (instancetype)colorWithRed:(double)r green:(double)g blue:(double)b alpha:(double)a;
@end
@implementation UIColor
+ (instancetype)colorWithRed:(double)r green:(double)g blue:(double)b alpha:(double)a {(void)r;(void)g;(void)b;(void)a;return [self new];}
@end
@interface TestDefaults : NSUserDefaults
@end
@implementation TestDefaults
- (NSDictionary *)persistentDomainForName:(NSString *)domain {(void)domain;return [TestPrefs copy];}
- (void)setObject:(id)value forKey:(NSString *)key {TestPrefs[key]=value;}
- (BOOL)synchronize {return !SyncFails;}
@end
@interface TestProcessInfo : NSObject
+ (instancetype)processInfo;
- (BOOL)lowPowerModeEnabled;
@end
@implementation TestProcessInfo
+ (instancetype)processInfo {return [self new];}
- (BOOL)lowPowerModeEnabled {return TestLowPower;}
@end
static uint32_t Register(const char *name,int *token) {
    if (RegisterFails) return 1;
    *token=(int)++NextToken;TokenNames[@(*token)]=@(name);return 0;
}
static uint32_t Observe(const char *name,int *token,dispatch_queue_t queue,void (^callback)(int)) {
    (void)queue;uint32_t status=Register(name,token);
    if (!status)Callbacks[@(*token)]=[callback copy];return status;
}
static uint32_t GetState(int token,uint64_t *word) {
    if (ReadFails) { *word=0;return 1; }
    *word=[TokenNames[@(token)] isEqual:@"com.powercuff.roothide.request"] ? PCREncodeRequest(Session) : Applied;
    return 0;
}
static uint32_t Post(const char *name) {
    ++Posts;if (PostFails)return 1;
    if (!strcmp(name,PCRProbeName)) {
        ++Session;
        unsigned mode=(unsigned)PCRValidatedMode(TestPrefs[@"PowerMode"],TestPrefs[@"RequireLowPowerMode"],TestLowPower);
        Applied=PCREncodeStatus(Session,mode);
    }
    return 0;
}
static uint32_t Cancel(int token) {(void)token;++Cancels;return 0;}
static void After(dispatch_time_t when,dispatch_queue_t queue,dispatch_block_t block) {
    (void)when;(void)queue;[Timers addObject:[block copy]];
}
#define PCR_CC_HOST_TEST 1
#define NSUserDefaults TestDefaults
#define NSProcessInfo TestProcessInfo
#define notify_register_check Register
#define notify_register_dispatch Observe
#define notify_get_state GetState
#define notify_post Post
#define notify_cancel Cancel
#define dispatch_after After
#import "../cc/PowercuffCC.m"
#undef NSUserDefaults
#undef NSProcessInfo
#undef notify_register_check
#undef notify_register_dispatch
#undef notify_get_state
#undef notify_post
#undef notify_cancel
#undef dispatch_after

@implementation CCUIMenuModuleViewController
- (void)setTitle:(NSString *)title {MenuTitle=[title copy];}
- (void)setGlyphImage:(UIImage *)image {(void)image;}
- (void)setSelected:(BOOL)selected {TileSelected=selected;}
- (void)setSelectedGlyphColor:(UIColor *)color {(void)color;}
- (void)removeAllActions {[Actions removeAllObjects];}
- (void)addActionWithTitle:(NSString *)title glyph:(UIImage *)glyph handler:(void (^)(void))handler {
    (void)glyph;assert(handler);[Actions addObject:@{@"title":title,@"handler":[handler copy]}];
}
- (void)addActionWithTitle:(NSString *)title subtitle:(NSString *)subtitle glyph:(UIImage *)glyph handler:(void (^)(void))handler {
    (void)subtitle;[self addActionWithTitle:title glyph:glyph handler:handler];
}
- (void)willTransitionToExpandedContentMode:(BOOL)expanded {(void)expanded;}
- (BOOL)respondsToSelector:(SEL)selector {
    if (sel_isEqual(selector,@selector(removeAllActions)) ||
        sel_isEqual(selector,@selector(addActionWithTitle:glyph:handler:)))return MenuSupported;
    if (sel_isEqual(selector,@selector(addActionWithTitle:subtitle:glyph:handler:)))return MenuSupported && DetailedMenu;
    return [super respondsToSelector:selector];
}
@end
static void Invoke(unsigned index) {
    assert(Actions.count==5 && index<5);
    dispatch_block_t handler=Actions[index][@"handler"];handler();
}
int main(void) {
    @autoreleasepool {
        TestPrefs=[NSMutableDictionary new];Actions=[NSMutableArray new];Timers=[NSMutableArray new];
        TokenNames=[NSMutableDictionary new];Callbacks=[NSMutableDictionary new];
        PowercuffCCModuleViewController *vc=[PowercuffCCModuleViewController new];
        [vc viewDidLoad];assert(Actions.count==5);
        for (unsigned mode=0;mode<=4;++mode) {Invoke(mode);assert([TestPrefs[@"PowerMode"] unsignedIntValue]==mode && TileSelected==(mode>0));}
        puts("Actual CC: five installed action handlers select all five production profiles PASS");
        [vc chooseMode:3];[vc buttonTapped:nil forEvent:nil];assert([TestPrefs[@"PowerMode"] intValue]==0);
        [vc buttonTapped:nil forEvent:nil];assert([TestPrefs[@"PowerMode"] intValue]==3);
        [TestPrefs removeObjectForKey:@"LastEnabledMode"];TestPrefs[@"PowerMode"]=@0;
        [vc buttonTapped:nil forEvent:nil];assert([TestPrefs[@"PowerMode"] intValue]==2);
        puts("Actual CC: short tap Off/restore and first-use Light use production writer PASS");
        TestPrefs[@"RequireLowPowerMode"]=@YES;TestLowPower=NO;[vc chooseMode:4];
        [vc refreshStatus];assert([TestPrefs[@"PowerMode"] intValue]==4 && [vc.statusText containsString:@"关闭"] && !TileSelected);
        TestLowPower=YES;[vc queryStatus];[vc refreshStatus];assert([vc.statusText containsString:@"重度"] && TileSelected);
        puts("Actual CC: saved selection and effective LPM profile are distinguished PASS");
        unsigned before=Posts;SyncFails=YES;[vc chooseMode:0];assert(Posts==before && [vc.statusText containsString:@"同步失败"]);SyncFails=NO;
        PostFails=YES;[vc chooseMode:0];assert([vc.statusText containsString:@"通知发送失败"]);PostFails=NO;
        puts("Actual CC: synchronization and notification failures stay explicit PASS");
        RegisterFails=YES;
        PowercuffCCModuleViewController *failed=[PowercuffCCModuleViewController new];
        [failed queryStatus];assert([failed.statusText containsString:@"注册失败"]);RegisterFails=NO;
        DetailedMenu=NO;[vc refresh];assert(Actions.count==5);Invoke(2);
        MenuSupported=NO;[vc refresh];assert([MenuTitle containsString:@"菜单接口不可用"]);MenuSupported=YES;DetailedMenu=YES;
        puts("Actual CC: failed registration, basic-action fallback and unavailable-menu warning PASS");
        [vc viewWillAppear:NO];[vc controlCenterWillPresent];[vc willTransitionToExpandedContentMode:YES];
        assert([vc shouldBeginTransitionToExpandedContentModule] && [vc _canShowWhileLocked]);
        while (Timers.count) {dispatch_block_t block=Timers[0];[Timers removeObjectAtIndex:0];block();}
        assert([vc.statusText containsString:@"接口已返回"]);
        PowercuffCCModule *module=[PowercuffCCModule new];assert(module.contentViewController && !module.backgroundViewController);
        puts("Actual CC: presentation hooks, obsolete timer generations and module entry PASS");
        TestPrefs[@"PowerMode"]=@1;
        for (NSNumber *token in [Callbacks.allKeys copy]) {
            if ([TokenNames[token] isEqual:@"com.dao.powercuff.settingschanged"]) {
                void (^callback)(int)=Callbacks[token];callback(token.intValue);
            }
        }
        [vc refreshStatus];assert(vc.selectedIndex==1 && [vc.statusText containsString:@"正常"]);
        ReadFails=YES;[vc queryStatus];[vc refreshStatus];
        assert(![vc.statusText containsString:@"接口已返回"]);
        while (Timers.count) {dispatch_block_t block=Timers[0];[Timers removeObjectAtIndex:0];block();}
        assert([vc.statusText containsString:@"本次确认未完成"]);
        ReadFails=NO;[vc queryStatus];[vc refreshStatus];assert([vc.statusText containsString:@"接口已返回"]);
        puts("Actual CC: registered edit callbacks and failed reads cannot falsely acknowledge; fresh query recovers PASS");
        while (Timers.count) {dispatch_block_t block=Timers[0];[Timers removeObjectAtIndex:0];block();}
        unsigned cancelsBefore=Cancels;__weak PowercuffCCModuleViewController *released;
        @autoreleasepool {
            PowercuffCCModuleViewController *temporary=[PowercuffCCModuleViewController new];
            released=temporary;[temporary viewDidLoad];[temporary queryStatus];temporary=nil;
        }
        assert(!released && Cancels==cancelsBefore+3);
        while (Timers.count) {dispatch_block_t block=Timers[0];[Timers removeObjectAtIndex:0];block();}
        puts("Actual CC: weak menu/observer/timer captures release controller and cancel three tokens PASS");
    }
}
