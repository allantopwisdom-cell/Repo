#!/bin/sh
set -eu
cd "$(dirname "$0")/.."
for file in build.sh scripts/check.sh layout/DEBIAN/*; do sh -n "$file"; done
python3 scripts/test_maintainer_scripts.py
python3 tests/test_package_format.py
python3 tests/test_module_contract.py
out=$(mktemp)
trap 'rm -f "$out"' EXIT
cc -std=c11 -Wall -Wextra -Werror -I. tests/test_protocol.c -o "$out"
"$out"
cc -std=c11 -Wall -Wextra -Werror -I. tests/test_ui_state.c -o "$out"
"$out"
cc -std=c11 -Wall -Wextra -Werror -I. tests/test_shortcut.c -o "$out"
"$out"
python3 - <<'PY'
import pathlib,plistlib
for p in pathlib.Path('.').rglob('*.plist'):
    if '.theos' not in p.parts: plistlib.loads(p.read_bytes())
print('all plist files parsed PASS')
PY
if [ "$(uname -s)" = Darwin ]; then
    clang -fobjc-arc -Wall -Wextra -Werror -I. -framework Foundation -framework CoreFoundation tests/test_preferences.m -o "$out"
    "$out"
    clang -fobjc-arc -Wall -Wextra -Werror -I. -framework Foundation tests/test_runtime.m -o "$out"
    "$out"
    clang -fobjc-arc -Wall -Wextra -Werror -I. -framework Foundation -framework CoreFoundation tests/test_core.m -o "$out"
    "$out"
    clang -fobjc-arc -Wall -Wextra -Werror -I. -framework Foundation -framework CoreFoundation tests/test_cc.m -o "$out"
    "$out"
    clang -fobjc-arc -Wall -Wextra -Werror -I. -framework Foundation tests/test_ctl.m -o "$out"
    "$out"
else
    echo 'Foundation preferences/runtime tests: pending macOS runner'
fi
