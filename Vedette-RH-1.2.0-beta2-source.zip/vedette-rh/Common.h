// Original code Copyright (c) 2021 udevs. GPLv3; development changes 2026.
#import <Foundation/Foundation.h>
#import <objc/runtime.h>
#ifndef VDT_HOST_TEST
#import <HBLog.h>
#import <roothide.h>
#endif
#define VEDETTE_IDENTIFIER @"com.udevs.vedette"
// Shared mobile preferences remain outside the relocated package root.
#ifdef VDT_HOST_TEST
NSString *VDTTestPath(NSString *name);
#define PREFS_PATH VDTTestPath(@"preferences.plist")
#define PREFS_PATH_TMP VDTTestPath(@"temporary.plist")
#else
#define PREFS_PATH @"/var/mobile/Library/Preferences/com.udevs.vedette.plist"
#define PREFS_PATH_TMP @"/var/tmp/com.udevs.vedette.plist"
#endif
#define PREFS_CHANGED_NN @"com.udevs.vedette.prefschanged"
#define RESTORE_ALL_MONITORS_NN @"com.udevs.vedette.restore-all-monitors"
#ifdef VDT_HOST_TEST
#define VDT_RUNTIME_PATH VDTTestPath(@"runtime.plist")
#define VDT_STATUS_PATH VDTTestPath(@"status.plist")
#else
#define VDT_RUNTIME_PATH @"/var/mobile/Library/Preferences/com.udevs.vedette.runtime.plist"
#define VDT_STATUS_PATH @"/var/mobile/Library/Preferences/com.udevs.vedette.status.plist"
#endif
