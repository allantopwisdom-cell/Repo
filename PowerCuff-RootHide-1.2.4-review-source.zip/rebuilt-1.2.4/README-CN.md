# PowerCuff RootHide Rebuilt 1.2.4 — 修复源码，等待正式构建

目标：iPhone 14 Pro Max（iPhone15,3/A16）、iOS 16.5、RootHide Dopamine 3.0.4。

这是基于 1.2.2 功能逆向和用户已有 Powercuff 工程重建的可读完整工程，不是原作者完整源码的逐字恢复。1.2.4 在已交付 1.2.3 上修复控制中心状态确认、诊断退出码及安装包验证覆盖问题。

本目录不含可安装的 1.2.4 正式 DEB。Linux 交叉编译候选虽然通过包结构和哈希检查，但反汇编发现该工具链不满足生产指针认证要求，已否决。不要仅凭 Mach-O subtype 或签名哈希通过判断可安装性。

## 正式构建

必须使用 macOS + Apple Xcode clang；建议沿用 1.2.3 成功使用的 macOS 15 / Xcode 16.4。
RootHide Theos 固定 cfba89a53a05b4a1b822121158acc3669c20602f；theos/sdks 固定 0222fd5413cf4b9af096f37b4621afa2688572f7，使用 iPhoneOS16.5.sdk。

```sh
export THEOS=/absolute/path/to/theos-roothide
export SOURCE_DATE_EPOCH=1793700000
sh build.sh
```

三个生产目标均强制包含 PCRBuildGuard.h，拒绝非 Apple clang、非 arm64e 或未启用 ptrauth 的编译。build.sh 拒绝 Linux 正式构建，并依次运行协议/UI测试、macOS Foundation测试、编译签名、归档规范化、实际包验证及7类故障注入。任一失败都不得发布。

成功产物路径：packages/com.powercuff.roothide_1.2.4_iphoneos-arm64e.deb。SOURCE-SHA256.json 记录源码文件；重建后包哈希可能随工具链或签名变化，应以该次构建产物的 verification.json 为准。

## 配置与功能

偏好域 com.dao.powercuff；PowerMode 仅接受 NSNumber 整数0至4，默认0；布尔、字符串、负数、越界和小数档位回退关闭。RequireLowPowerMode 缺失或0表示不门控，1表示系统真实低电量模式开启时才应用所选档位，非法值回退关闭。
0/off 关闭模拟；1/nominal 正常模拟仍不等于关闭；2/light 轻度；3/moderate 适中；4/heavy 重度。

本工程不提供固定CPU频率、充电限流或A16专属频率表；接口返回状态不能代表频率、电流、温度或节能收益。

## 真机验收

先停用其他热管理插件，包括 Hello CPU，备份偏好并记录系统/越狱版本；安装后通过越狱工具重启用户空间。检查关闭→轻度→关闭，设置页面和控制中心互改、快速切换、低电模式门控、后台缺失/重启、卸载关闭确认。已有偏好会沿用，默认关闭不等于强制清空旧配置。

pcctl status 是会话一致性快照，不是实时心跳；成功状态0至4退出0，无匹配确认退出3，已报告的失败状态退出4。
pcctl disable 等待最多约3秒，只在匹配随机nonce确认后报告关闭接口已返回；这会锁定本进程会话关闭，恢复需用户空间重启。

脚本不强杀 thermalmonitord。SIGBUS/SIGSEGV/PAC故障和watchdog不能由 Objective-C 异常捕获解决。未连接目标手机，设备稳定性、私有API线程约束和续航均待实测。
