#import <Foundation/Foundation.h>
#import <notify.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#import "../PCRProtocol.h"
int main(int argc, char **argv) {
    @autoreleasepool {
        if (argc == 2 && strcmp(argv[1], "disable") == 0) {
            int command = -1, ack = -1;
            if (notify_register_check(PCRDisableName, &command) != NOTIFY_STATUS_OK) return 2;
            if (notify_register_check(PCRDisableAckName, &ack) != NOTIFY_STATUS_OK) { notify_cancel(command); return 2; }
            uint64_t nonce = ((uint64_t)arc4random() << 32) | arc4random();
            if (!nonce) nonce = 1;
            BOOL sent = notify_set_state(command, nonce) == NOTIFY_STATUS_OK && notify_post(PCRDisableName) == NOTIFY_STATUS_OK;
            BOOL accepted = NO;
            for (unsigned n=0; sent && n<30; ++n) {
                uint64_t value=0;
                if (notify_get_state(ack,&value)==NOTIFY_STATUS_OK && value==nonce) { accepted=YES; break; }
                usleep(100000);
            }
            notify_cancel(command); notify_cancel(ack);
            puts(accepted ? "Thermal API returned after off request; this process session is disabled." :
                 "No matching disable acknowledgement. Use a userspace restart to clear any residual thermal simulation.");
            return accepted ? 0 : 3;
        }
        if (argc==2 && strcmp(argv[1],"status")==0) {
            int req=-1, ack=-1; uint64_t rw=0,aw=0; uint32_t session=0; unsigned status=255;
            BOOL valid=notify_register_check("com.powercuff.roothide.request",&req)==NOTIFY_STATUS_OK &&
                notify_register_check(PCRAppliedName,&ack)==NOTIFY_STATUS_OK &&
                notify_get_state(req,&rw)==NOTIFY_STATUS_OK && notify_get_state(ack,&aw)==NOTIFY_STATUS_OK &&
                PCRDecodeRequest(rw,&session) && PCRDecodeStatus(aw,session,&status);
            if (req>=0) notify_cancel(req); if (ack>=0) notify_cancel(ack);
            printf("session=%u status=%u matching=%s (snapshot, not frequency measurement)\n", session,status,valid?"yes":"no");
            return valid ? 0 : 3;
        }
        fprintf(stderr,"Usage: pcctl status | disable\n");return 1;
    }
}
