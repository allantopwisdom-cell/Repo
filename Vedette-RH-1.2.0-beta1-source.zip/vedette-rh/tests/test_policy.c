#include "../VDTPolicy.h"
#include "../VDTProcCompat.h"
#include <assert.h>
#include <stdio.h>
#include <limits.h>
static int assertions;
#define CHECK(x) do { assert(x); ++assertions; } while(0)
int main(void) {
    int n=0;
    CHECK(sizeof(VDTProcBSDInfo)==136);
    CHECK(offsetof(VDTProcBSDInfo,pbi_start_tvsec)==120);
    CHECK(offsetof(VDTProcBSDInfo,pbi_start_tvusec)==128);
    CHECK(vdt_parse_integer("20",20,100,&n) && n==20);
    CHECK(vdt_parse_integer("100",20,100,&n) && n==100);
    const char *bad[]={"", "-1", "19", "101", "20x", "80.5", " 80", "80 ", "+80", "9999999999999999999999999999"};
    for(size_t i=0;i<sizeof(bad)/sizeof(bad[0]);i++) CHECK(!vdt_parse_integer(bad[i],20,100,&n));
    CHECK(!vdt_parse_integer(NULL,20,100,&n));
    CHECK(!vdt_parse_integer("80",20,100,NULL));
    CHECK(vdt_valid_rule(VDTThrottle,80,0));
    CHECK(vdt_valid_rule(VDTTerminate,80,120));
    CHECK(!vdt_valid_rule(VDTMonitor,80,120));
    CHECK(!vdt_valid_rule(VDTTerminate,80,59));
    CHECK(!vdt_valid_rule(VDTTerminate,80,3601));
    CHECK(!vdt_valid_rule(VDTThrottle,0,120));
    CHECK(vdt_pid_count(12,12)==3);
    CHECK(vdt_pid_count(12,8)==2);
    CHECK(vdt_pid_count(-1,4096)==0);
    CHECK(vdt_pid_count(11,12)==2);
    CHECK(vdt_pid_count(INT_MAX,16)==4);
    const char *protected[]={"runningboardd","thermalmonitord","SpringBoard","launchd","watchdogd","Preferences"};
    for(size_t i=0;i<sizeof(protected)/sizeof(protected[0]);i++) CHECK(vdt_protected_name(protected[i]));
    CHECK(vdt_protected_name(NULL));
    CHECK(!vdt_protected_name("example-test-daemon"));
    // Exhaustive transition truth table for the production decision function.
    for(int old=0;old<2;old++)for(int same=0;same<2;same++)for(int enabled=0;enabled<2;enabled++)
    for(int dry=0;dry<2;dry++)for(int recovery=0;recovery<2;recovery++)for(int desired=0;desired<2;desired++) {
        VDTAction a=vdt_next_action(old,same,enabled,dry,recovery,desired);
        if(old && (!same || !enabled || dry || recovery || !desired))CHECK(a==VDTRestore);
        else if(old)CHECK(a==VDTKeep);
        else if(enabled && !dry && desired)CHECK(a==VDTApply);
        else CHECK(a==VDTIdle);
    }
    // Rule removal, disable, mode/threshold change, dry-run and restart all require cleanup.
    CHECK(vdt_next_action(1,1,0,0,0,1)==VDTRestore);
    CHECK(vdt_next_action(1,0,1,0,0,1)==VDTRestore);
    CHECK(vdt_next_action(1,1,1,1,0,1)==VDTRestore);
    CHECK(vdt_next_action(1,1,1,0,1,1)==VDTRestore);
    CHECK(vdt_next_action(1,1,1,0,0,0)==VDTRestore);
    printf("PASS: %d assertions (includes 64 transition combinations)\n",assertions);
}
