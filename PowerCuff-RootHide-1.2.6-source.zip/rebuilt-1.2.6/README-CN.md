# PowerCuff RootHide 1.2.6

融合重建版，目标iPhone14 Pro Max/A16、iOS16.5、RootHide Dopamine3.0.4。基于已交付1.2.5完整源码，结合上传R3vamp1.5.1的图标和开关交互思路；不复用其主插件或控制中心旧二进制。

默认Off，PowerMode整数0..4：off/nominal/light/moderate/heavy。nominal仍在模拟。RequireLowPowerMode默认关闭，开启后真实LPM关闭请求Off且保留保存档位。持久偏好域com.dao.powercuff，沿用1.2.5偏好；不自动迁移R3vamp的com.rpetrich.powercuff。

控制中心短按：当前非零则关闭；当前关闭则恢复LastEnabledMode，缺失/非法时首次用Light(2)。长按展开五档选择。LastEnabledMode只记录请求值，不表示后台实际应用；LPM门控仍然有效。保留会话核对、故障缓存说明、3.2秒确认窗口与pcctl诊断。

固化UIDeviceFamily=[1,2]，此修正在用户设备上使1.2.5组件恢复显示。新增版本完整安装后的发现/点击/长按/状态仍需真机验收。

保留1.2.5角色隔离、偏好严格校验、有限通信恢复、方法ABI检查、弱对象/局部强引用、异常熔断、停用握手。安装脚本不killall thermalmonitord。升级/卸载后经越狱工具重启用户空间，先单独Off→Light→Off。

没有新增锁屏Heavy、后台冻结、两秒唤醒引擎、固定频率/30FPS/性能百分比或充电限流。实际热管理/续航、PAC和watchdog必须由设备测试，不能保证比旧版更省电。

构建：macOS15/Xcode16.4，固定RootHide Theos与iPhoneOS16.5 SDK；设置THEOS及SOURCE_DATE_EPOCH后sh build.sh。执行核心/协议/UI/CLI/偏好/格式/快捷开关/模块元数据检查，再完整编译三个生产目标，签名、规范化、验证最终DEB及22类变异。实际构建结果以交付日志为准。

## 本轮审查修订

展开菜单改用带弱引用handler的addAction接口，移除动态CCUIMenuModuleItem和setMenuItems假设；运行时先检查方法可用性，支持无subtitle的基本action回退，完全缺失时明确提示。API头文件参考来自运行时提取，不代替iOS16.5实机验证。折叠方块高亮随当前配置经LPM门控的请求值更新，不表示后台真实生效。

新增独立设置/模块契约、7张PNG的CRC/边界/图像流检查及实际控制器Foundation模拟；新增源码清单校验，构建前核对全部输入。当前Linux检查已执行；Foundation实际控制器/偏好/runtime/核心/CLI和22类真实DEB变异必须在新macOS构建中执行。公开上传仍待明确授权，当前没有1.2.6 DEB。
