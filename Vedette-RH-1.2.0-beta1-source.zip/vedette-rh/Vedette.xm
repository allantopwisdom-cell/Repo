// Original project Copyright (c) 2021 udevs; rewritten controller, GPLv3.
#import "VDTProcessManager.h"
#import "VDTShared.h"
#include <notify.h>
#include <sys/sysctl.h>
#include <sys/utsname.h>
static dispatch_queue_t controllerQueue;
static dispatch_source_t discoveryTimer;
static int prefsToken;
static int resetToken;
static void reconcile(void) { @autoreleasepool { VDTReconcile(getPrefs()); } }
%ctor {
    @autoreleasepool {
        if (![[NSProcessInfo processInfo].processName isEqualToString:@"runningboardd"]) return;
        // This beta is intentionally restricted to the user's verified target identity.
        struct utsname systemInfo={}; uname(&systemInfo);
        char build[64]={0}; size_t length=sizeof(build);
        if (sysctlbyname("kern.osversion",build,&length,NULL,0)!=0 ||
            strcmp(build,"20F66") || strcmp(systemInfo.machine,"iPhone15,3")) {
            NSLog(@"[Vedette RH] unsupported target; controller inactive"); return;
        }
        controllerQueue=dispatch_queue_create("com.udevs.vedette.controller",DISPATCH_QUEUE_SERIAL);
        notify_register_dispatch("com.udevs.vedette.prefschanged",&prefsToken,controllerQueue,^(int token){(void)token;reconcile();});
        notify_register_dispatch("com.udevs.vedette.restore-all-monitors",&resetToken,controllerQueue,^(int token){(void)token;reconcile();});
        // PID discovery only: no high-frequency CPU sampling and no per-process injection.
        discoveryTimer=dispatch_source_create(DISPATCH_SOURCE_TYPE_TIMER,0,0,controllerQueue);
        dispatch_source_set_timer(discoveryTimer,dispatch_time(DISPATCH_TIME_NOW,0),30*NSEC_PER_SEC,5*NSEC_PER_SEC);
        dispatch_source_set_event_handler(discoveryTimer,^{reconcile();});
        dispatch_resume(discoveryTimer);
    }
}
