#import <Foundation/Foundation.h>
#import <CoreFoundation/CoreFoundation.h>
#include <stdio.h>
#include <errno.h>
#include <fcntl.h>
#include <sys/stat.h>
#include <unistd.h>
// Explicit read-only diagnostic. Never instantiate a module, call principalClass,
// load executable code, edit preferences, post notifications or reload services.
static BOOL PCIntegerEquals(id value, NSInteger expected) {
    return [value isKindOfClass:NSNumber.class] &&
        CFGetTypeID((__bridge CFTypeRef)value)!=CFBooleanGetTypeID() &&
        !CFNumberIsFloatType((__bridge CFNumberRef)value) &&
        [value doubleValue]==(double)expected;
}
// Bound reads on an already-open regular file. Do not follow file symlinks or
// block on a FIFO/device supplied in place of a packaged plist.
static NSDictionary *PCModuleDictionary(NSString *path) {
    int fd=open(path.fileSystemRepresentation,O_RDONLY|O_NONBLOCK|O_NOFOLLOW|O_CLOEXEC);
    if (fd<0) return nil;
    struct stat st;
    if (fstat(fd,&st)!=0 || !S_ISREG(st.st_mode) || st.st_size<=0 || st.st_size>65536) {close(fd);return nil;}
    NSMutableData *data=[NSMutableData dataWithLength:65537];size_t used=0;
    while (used<data.length) {
        ssize_t n=read(fd,(char *)data.mutableBytes+used,data.length-used);
        if (n<0 && errno==EINTR) continue;
        if (n<0) {close(fd);return nil;}
        if (!n) break;
        used+=(size_t)n;
    }
    close(fd);
    if (used!=(size_t)st.st_size || used>65536) return nil;
    data.length=used;
    id value=[NSPropertyListSerialization propertyListWithData:data options:NSPropertyListImmutable format:NULL error:nil];
    return [value isKindOfClass:NSDictionary.class] ? value : nil;
}
static BOOL PCModuleRegularFile(NSString *path,BOOL executable) {
    struct stat st;
    return lstat(path.fileSystemRepresentation,&st)==0 && S_ISREG(st.st_mode) &&
        access(path.fileSystemRepresentation,R_OK|(executable ? X_OK : 0))==0;
}
static NSDictionary *PCModuleReport(NSString *path, BOOL (^preflight)(NSBundle *,NSError **)) {
    NSMutableDictionary *report=[NSMutableDictionary new];
    NSMutableArray *issues=[NSMutableArray new];
    report[@"schema"]=@1;report[@"bundle_path"]=path ?: @"";
    report[@"code_loaded"]=@NO;report[@"injection_verified"]=@NO;
    report[@"runtime_verified"]=@NO;report[@"preflight"]=@"skipped";
    if (!path.isAbsolutePath) { [issues addObject:@"bundle path must be absolute"];report[@"issues"]=issues;return report; }
    NSFileManager *fm=NSFileManager.defaultManager;BOOL directory=NO;
    BOOL exists=[fm fileExistsAtPath:path isDirectory:&directory] && directory;
    report[@"bundle_directory_exists"]=@(exists);
    NSString *infoPath=[path stringByAppendingPathComponent:@"Info.plist"];
    NSDictionary *info=exists ? PCModuleDictionary(infoPath) : nil;
    if (!exists) [issues addObject:@"module directory missing or inaccessible"];
    if (!info) [issues addObject:@"Info.plist missing, unreadable, oversized or not a dictionary"];
    NSDictionary *expected=@{@"CFBundleIdentifier":@"com.dao.powercuff.ccmodule",
        @"CFBundleExecutable":@"PowercuffCC",@"NSPrincipalClass":@"PowercuffCCModule",
        @"CFBundlePackageType":@"BNDL",@"MinimumOSVersion":@"16.0"};
    NSMutableDictionary *metadata=[NSMutableDictionary new];
    for (NSString *key in expected) {
        id value=info[key];metadata[key]=value ? [value description] : @"<missing>";
        if (![value isKindOfClass:NSString.class] || ![value isEqual:expected[key]])
            [issues addObject:[@"unexpected metadata: " stringByAppendingString:key]];
    }
    for (NSString *key in @[@"CFBundleVersion",@"CFBundleShortVersionString"]) {
        id value=info[key];metadata[key]=value ? [value description] : @"<missing>";
        if (![value isKindOfClass:NSString.class] || ![value length])
            [issues addObject:[@"missing or invalid version metadata: " stringByAppendingString:key]];
    }
    id family=info[@"UIDeviceFamily"];
    if (![family isKindOfClass:NSArray.class] || [family count]!=2 ||
        !PCIntegerEquals(family[0],1) || !PCIntegerEquals(family[1],2))
        [issues addObject:@"UIDeviceFamily must be integer [1,2]"];
    report[@"metadata"]=metadata;
    NSString *executable=[path stringByAppendingPathComponent:@"PowercuffCC"];
    BOOL executableExists=PCModuleRegularFile(executable,YES);
    report[@"executable_accessible"]=@(executableExists);
    if (!executableExists) [issues addObject:@"module executable must be a readable executable regular file"];
    // The caller supplies jbroot's resolved bundle path; derive the same root for CCSupport.
    NSString *root=path;
    for (unsigned i=0;i<4;++i) root=root.stringByDeletingLastPathComponent;
    NSString *base=[root stringByAppendingPathComponent:@"Library/MobileSubstrate/DynamicLibraries/CCSupport"];
    BOOL supportExists=PCModuleRegularFile([base stringByAppendingString:@".dylib"],NO);
    report[@"ccsupport_dylib_exists"]=@(supportExists);
    if (!supportExists) [issues addObject:@"CCSupport dylib must be a readable regular file"];
    NSDictionary *filter=PCModuleDictionary([base stringByAppendingString:@".plist"]);
    id filterBody=filter[@"Filter"];
    id bundles=[filterBody isKindOfClass:NSDictionary.class] ? filterBody[@"Bundles"] : nil;
    BOOL filterValid=[bundles isKindOfClass:NSArray.class] &&
        [bundles containsObject:@"com.apple.springboard"] && [bundles containsObject:@"com.apple.Preferences"];
    report[@"ccsupport_expected_filter"]=@(filterValid);
    if (!filterValid) [issues addObject:@"CCSupport SpringBoard/Settings filter missing or unexpected"];
    if (!issues.count) {
        NSBundle *bundle=[NSBundle bundleWithPath:path];NSError *error=nil;
        BOOL ok=bundle && preflight(bundle,&error);
        report[@"preflight"]=ok ? @"passed" : @"failed";
        if (error) {report[@"preflight_error_domain"]=error.domain;report[@"preflight_error_code"]=@(error.code);
                    report[@"preflight_error"]=error.localizedDescription;}
        if (!ok) [issues addObject:@"bundle preflight failed; this does not identify every possible link/load error"];
    }
    report[@"issues"]=issues;
    report[@"note"]=@"Preflight does not load executable code and does not prove SpringBoard/Settings injection, module discovery or actual thermal operation.";
    return report;
}
static int PCPrintModuleCheck(NSString *path) {
    NSDictionary *report=PCModuleReport(path, ^BOOL(NSBundle *bundle,NSError **error) {
        return [bundle preflightAndReturnError:error];
    });
    NSData *json=[NSJSONSerialization dataWithJSONObject:report options:NSJSONWritingPrettyPrinted error:nil];
    if (!json) return 2;
    fwrite(json.bytes,1,json.length,stdout);fputc('\n',stdout);
    return [report[@"issues"] count] ? 3 : 0;
}
