#!/bin/sh
set -eu
cd "$(dirname "$0")/.."
: "${THEOS:?Set THEOS to a fully installed RootHide Theos directory}"
if [ ! -d "$THEOS/vendor/mod/roothide" ]; then
  echo 'RootHide Theos package module is missing; refusing a generic/rootless build.' >&2
  exit 1
fi
command -v make >/dev/null
# AltList framework and the RootHide development headers/libraries must already be installed.
# Keep dependency acquisition separate so builds do not silently change the toolchain.
make clean
make package FINALPACKAGE=1 THEOS_PACKAGE_SCHEME=roothide
# Darwin account IDs must never leak into installable iOS archives.
command -v dpkg-deb >/dev/null
for package in packages/*.deb; do
  [ -f "$package" ] || { echo 'No package produced' >&2; exit 1; }
  normalize_work=$(mktemp -d)
  trap 'rm -rf "$normalize_work"' EXIT HUP INT TERM
  dpkg-deb -R "$package" "$normalize_work/root"
  dpkg-deb --build --root-owner-group -Zxz "$normalize_work/root" "$normalize_work/normalized.deb"
  mv "$normalize_work/normalized.deb" "$package"
  rm -rf "$normalize_work"
  trap - EXIT HUP INT TERM
 done
printf '%s\n' 'Build and root ownership normalization finished; run scripts/verify_deb.sh on the produced file.'
