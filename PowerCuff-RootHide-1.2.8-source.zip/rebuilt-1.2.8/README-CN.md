# PowerCuff RootHide 1.2.8

融合重建版，目标iPhone14 Pro Max/A16、iOS16.5、RootHide Dopamine3.0.4。基于已交付1.2.5完整源码，结合上传R3vamp1.5.1的图标和开关交互思路；不复用其主插件或控制中心旧二进制。

默认Off，PowerMode整数0..4：off/nominal/light/moderate/heavy。nominal仍在模拟。RequireLowPowerMode默认关闭，开启后真实LPM关闭请求Off且保留保存档位。持久偏好域com.dao.powercuff，沿用1.2.5偏好；不自动迁移R3vamp的com.rpetrich.powercuff。

控制中心短按：当前非零则关闭；当前关闭则恢复LastEnabledMode，缺失/非法时首次用Light(2)。长按展开五档选择。LastEnabledMode只记录请求值，不表示后台实际应用；LPM门控仍然有效。保留会话核对、故障缓存说明、3.2秒确认窗口与pcctl诊断。

固化UIDeviceFamily=[1,2]，此修正在用户设备上使1.2.5组件恢复显示。新增版本完整安装后的发现/点击/长按/状态仍需真机验收。

保留1.2.5角色隔离、偏好严格校验、有限通信恢复、方法ABI检查、弱对象/局部强引用、异常熔断、停用握手。安装脚本不killall thermalmonitord。升级/卸载后经越狱工具重启用户空间，先单独Off→Light→Off。

没有新增锁屏Heavy、后台冻结、两秒唤醒引擎、固定频率/30FPS/性能百分比或充电限流。实际热管理/续航、PAC和watchdog必须由设备测试，不能保证比旧版更省电。

构建：macOS15/Xcode16.4，固定RootHide Theos与iPhoneOS16.5 SDK；设置THEOS及SOURCE_DATE_EPOCH后sh build.sh。执行核心/协议/UI/CLI/偏好/格式/快捷开关/模块元数据检查，再完整编译三个生产目标，签名、规范化、验证最终DEB及23类变异。实际构建结果以交付日志为准。

## 1.2.8 控制中心复审

用户报告1.2.7安装后未显示模块，当前根因未确定。本版补齐二进制入口导出验证及只读诊断，保留热控核心和CC交互，不宣称已解决真机显示问题。新增pcctl module-check "$(jbroot /Library/ControlCenter/Bundles/PowercuffCC.bundle)"，仅读取当前RootHide路径下模块/CCSupport文件、配置和NSBundle预检结果，不实际加载模块代码、不改设置或重启服务。预检通过不能证明注入/模块发现或热控生效，详见AUDIT-1.2.8.md。

构建前执行24组Python与原协议/UI/快捷测试；macOS执行37组核心、8组CC及4组新诊断和原Foundation/CLI回归，完整编译三目标、签名打包并验证23类实际包反例。封存时新macOS链尚待执行，最终结果以实际日志为准。
