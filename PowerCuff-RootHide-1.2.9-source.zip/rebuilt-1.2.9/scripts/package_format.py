"""Project-specific unambiguous archive/plist parsing shared by build and verification."""
from contextlib import contextmanager
import io,lzma,zlib,tarfile,plistlib
LIMIT=16*1024*1024
DECODER_MEMORY_LIMIT=128*1024*1024
class UniqueDictionary(dict):
    def __setitem__(self,key,value):
        assert type(key) is str and key not in self, 'duplicate/invalid plist dictionary key'
        super().__setitem__(key,value)
def load_plist(data):return plistlib.loads(data,dict_type=UniqueDictionary)
def plist_equal(a,b):
    if isinstance(b,dict):return isinstance(a,dict) and a.keys()==b.keys() and all(plist_equal(a[k],v) for k,v in b.items())
    if isinstance(b,list):return type(a) is list and len(a)==len(b) and all(plist_equal(x,y) for x,y in zip(a,b))
    return type(a) is type(b) and a==b
@contextmanager
def open_tar(blob,name):
    assert len(blob)<=LIMIT, 'compressed archive exceeds project limit'
    try:
        if name.endswith(('.xz','.lzma')):
            d=lzma.LZMADecompressor(format=lzma.FORMAT_XZ if name.endswith('.xz') else lzma.FORMAT_ALONE,
                                    memlimit=DECODER_MEMORY_LIMIT);raw=d.decompress(blob,max_length=LIMIT+1)
            assert d.eof and not d.unused_data, 'compression trailer/stream mismatch'
        elif name.endswith('.gz'):
            d=zlib.decompressobj(31);raw=d.decompress(blob,LIMIT+1)
            assert d.eof and not d.unused_data and not d.unconsumed_tail, 'compression trailer/stream mismatch'
        else:raise AssertionError('unsupported compression suffix')
        assert len(raw)<=LIMIT and len(raw)%512==0, 'tar block framing/project limit'
        with tarfile.open(fileobj=io.BytesIO(raw),mode='r:') as archive:
            archive.getmembers();trailer=raw[archive.offset:]
            assert len(trailer)>=1024 and not any(trailer), 'tar end markers/trailer'
            assert not archive.pax_headers, 'unexpected global archive metadata'
            assert all(not m.pax_headers for m in archive), 'unexpected extended archive metadata'
            yield archive
    except (lzma.LZMAError,zlib.error,tarfile.TarError,EOFError) as e:
        raise AssertionError('invalid compression/tar data') from e

import re
def control_fields(contents):
    text = contents.decode('utf-8').replace('\r\n', '\n')
    assert all(c in '\t\n' or ord(c) >= 32 and ord(c) != 127 for c in text), 'invalid control character'
    fields, current, seen, ended = {}, None, set(), False
    # Debian binary metadata is one stanza with LF/CRLF physical lines. Unicode
    # splitlines()/isspace() would give a different interpretation from dpkg.
    for line in text.split('\n'):
        if not line.strip(' \t'):
            if fields: ended = True
            continue
        assert not ended, 'multiple control stanzas are forbidden'
        if line[0] in ' \t':
            assert current, 'control continuation without a field'
            fields[current] += '\n' + line[1:]
            continue
        assert ':' in line, 'control field has no separator'
        key, value = line.split(':', 1)
        assert re.fullmatch(r'[!-9;-~]+', key) and key[0] not in '#-', 'invalid control field name'
        assert key.lower() not in seen, f'duplicate control field: {key}'
        seen.add(key.lower())
        value = value.strip(' \t')
        assert value, 'empty binary control field'
        fields[key] = value
        current = key
    assert fields, 'empty binary control stanza'
    return fields

def decode_boolean_entitlements(data):
    # The project emits a SET of (UTF8 key, BOOLEAN) sequences. Reject other
    # entitlement types/layouts rather than silently interpreting an extension.
    def tlv(blob,pos):
        assert pos+2<=len(blob), 'DER entitlement truncation'
        tag,first=blob[pos:pos+2];pos+=2
        if first<128:n=first
        else:
            count=first&127
            assert 1<=count<=4 and pos+count<=len(blob) and blob[pos]!=0, 'DER entitlement length'
            n=int.from_bytes(blob[pos:pos+count],'big');pos+=count
            assert n>=128, 'nonminimal DER entitlement length'
        assert pos+n<=len(blob), 'DER entitlement bounds'
        return tag,blob[pos:pos+n],pos+n
    tag,body,end=tlv(data,0);assert tag==0x31 and end==len(data), 'DER entitlement SET/trailer'
    pos=0;result={}
    while pos<len(body):
        tag,entry,pos=tlv(body,pos);assert tag==0x30, 'DER entitlement pair'
        tag,key,at=tlv(entry,0);assert tag==0xc and key, 'DER entitlement key'
        key=key.decode('utf-8');assert key not in result, 'duplicate DER entitlement key'
        tag,value,at=tlv(entry,at)
        assert tag==1 and len(value)==1 and value[0] in (0,1,255) and at==len(entry), 'DER entitlement Boolean'
        result[key]=value!=b'\0'
    return result
