import pathlib,struct,sys,unittest
sys.path.insert(0,str(pathlib.Path(__file__).resolve().parents[1]/'scripts'))
from module_binary import validate_module_exports,EXPECTED

def fixture(imported=False,section=b'__objc_data'):
    # Minimal independent Mach-O with one data section and two exported class symbols.
    names=[('_OBJC_CLASS_$_'+x).encode()+b'\0' for x in EXPECTED]
    strings=b'\0'+b''.join(names);symbols=b'';index=1
    for i,name in enumerate(names):
        symbols+=struct.pack('<IBBHQ',index,1 if imported else 15,0 if imported else 1,0,0x1000+40*i)
        index+=len(name)
    segment=struct.pack('<II16sQQQQIIII',0x19,152,b'__DATA',0x1000,80,0,0,3,3,1,0)
    segment+=struct.pack('<16s16sQQIIIIIIII',section,b'__DATA',0x1000,80,0,3,0,0,0,0,0,0)
    table=struct.pack('<6I',2,24,208,2,240,len(strings))
    return struct.pack('<8I',0xfeedfacf,0x100000c,0x80000002,6,2,176,0,0)+segment+table+symbols+strings
class ModuleBinaryTests(unittest.TestCase):
    def test_defined(self):self.assertEqual(validate_module_exports(fixture()),sorted(EXPECTED))
    def test_import_not_definition(self):
        with self.assertRaisesRegex(AssertionError,'class export'):validate_module_exports(fixture(imported=True))
    def test_wrong_section(self):
        with self.assertRaisesRegex(AssertionError,'class export'):validate_module_exports(fixture(section=b'__text'))
    def test_missing_name(self):
        with self.assertRaisesRegex(AssertionError,'class export'):validate_module_exports(fixture().replace(b'PowercuffCCModule\0',b'XowercuffCCModule\0'))
    def test_truncated(self):
        for length in [0,31,32,200,240]:
            with self.subTest(length=length),self.assertRaises(AssertionError):validate_module_exports(fixture()[:length])
    def test_bad_string_index(self):
        data=bytearray(fixture());struct.pack_into('<I',data,208,99999)
        with self.assertRaisesRegex(AssertionError,'name bounds'):validate_module_exports(data)
if __name__=='__main__':unittest.main(verbosity=2)
