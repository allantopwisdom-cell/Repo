#!/bin/sh
set -eu
cd "$(dirname "$0")"
: "${THEOS:?Set THEOS to RootHide Theos}"
export THEOS_PACKAGE_SCHEME=roothide
if [ "$(uname -s)" != Darwin ]; then
    echo 'Release build requires macOS and Apple Xcode clang; no Linux candidate may be released.' >&2
    exit 1
fi
xcrun clang --version | grep 'Apple clang version' >/dev/null
xcodebuild -version
python3 scripts/verify_source.py
sh scripts/check.sh
make clean
make package DEBUG=0 FINALPACKAGE=1 messages=yes
package=packages/com.powercuff.roothide_1.2.9_iphoneos-arm64e.deb
test -f "$package"
if [ -n "${SOURCE_DATE_EPOCH:-}" ]; then
    epoch=$SOURCE_DATE_EPOCH
else
    epoch=$(git log -1 --format=%ct)
fi
python3 scripts/normalize_package.py "$package" "$epoch"
python3 scripts/verify_package.py "$package" > packages/verification.json
python3 scripts/test_built_package.py "$package" > packages/negative-tests.txt
cat packages/verification.json
cat packages/negative-tests.txt
