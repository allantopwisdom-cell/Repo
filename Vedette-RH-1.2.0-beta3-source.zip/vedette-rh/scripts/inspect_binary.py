import hashlib,struct,json,sys,pathlib

def inspect(path):
 b=path.read_bytes();assert len(b)>=32
 magic,cpu,subtype,filetype,ncmds,cmdbytes,flags,res=struct.unpack_from('<8I',b)
 assert magic==0xfeedfacf and cpu==0x100000c and subtype==0x80000002,(hex(magic),hex(cpu),hex(subtype))
 assert ncmds<4096 and 32+cmdbytes<=len(b)
 pos=32;signature=None;identity=None;deps=[];build=None
 for _ in range(ncmds):
  cmd,size=struct.unpack_from('<II',b,pos);assert size>=8 and pos+size<=32+cmdbytes
  if cmd==0x32:build=struct.unpack_from('<4I',b,pos+8)
  if cmd==0x1d:signature=struct.unpack_from('<II',b,pos+8)
  if cmd in (0xd,0xc,0x80000018,0x8000001f):
   off=struct.unpack_from('<I',b,pos+8)[0];assert off<size
   name=b[pos+off:pos+size].split(b'\0',1)[0].decode()
   if cmd==0xd:identity=name
   else:deps.append(name)
  pos+=size
 assert pos==32+cmdbytes and signature
 assert build and build[0]==2 and build[1]==0x100000,build
 off,size=signature;assert off+size<=len(b)
 sig=b[off:off+size];magic,length,count=struct.unpack_from('>III',sig)
 assert magic==0xfade0cc0 and length<=size and count<256
 cds=[]
 for i in range(count):
  kind,where=struct.unpack_from('>II',sig,12+i*8);assert where+8<=length
  cmagic,clen=struct.unpack_from('>II',sig,where);assert where+clen<=length
  if cmagic!=0xfade0c02:continue
  cd=sig[where:where+clen]
  _,_,version,cflags,hashoff,identoff,special,slots,limit=struct.unpack_from('>9I',cd)
  hsize,htype,platform,pagepower=struct.unpack_from('>4B',cd,36)
  assert pagepower<=20 and hashoff+slots*hsize<=clen and limit<=off and identoff<clen
  page=1<<pagepower;assert slots==(limit+page-1)//page
  algorithms={1:'sha1',2:'sha256',3:'sha256',4:'sha384'};assert htype in algorithms
  for slot in range(slots):
   expected=cd[hashoff+slot*hsize:hashoff+(slot+1)*hsize]
   got=hashlib.new(algorithms[htype],b[slot*page:min((slot+1)*page,limit)]).digest()[:hsize]
   assert got==expected,(path,slot)
  cds.append({'version':hex(version),'algorithm':algorithms[htype],'pages_verified':slots})
 assert cds
 return {'file':str(path),'bytes':len(b),'arch':'arm64e','cpu_subtype':hex(subtype),'platform':build[0],'minimum_os':hex(build[1]),'sdk':hex(build[2]),'install_id':identity,'dependencies':deps,'code_directories':cds}

if __name__=='__main__':
 print(json.dumps([inspect(pathlib.Path(x)) for x in sys.argv[1:]],indent=2))
