#include "PCUIState.h"
#include <assert.h>
#include <stdio.h>
int main(void) {
    PCUIQuery q={0};unsigned status=255;
    uint64_t first=PCUIBegin(&q,100);
    assert(PCUIEvaluate(&q,100,PCREncodeStatus(100,3),100,3,&status)==PCUIWaiting);
    assert(PCUIEvaluate(&q,101,PCREncodeStatus(100,3),101,3,&status)==PCUIWaiting);
    assert(PCUIEvaluate(&q,101,PCREncodeStatus(101,3),102,3,&status)==PCUIWaiting);
    assert(PCUIEvaluate(&q,101,PCREncodeStatus(101,3),101,3,&status)==PCUIAccepted);
    assert(PCUIEvaluate(&q,101,PCREncodeStatus(101,3),101,0,&status)==PCUIMismatch);
    assert(PCUIEvaluate(&q,101,PCREncodeStatus(101,0),101,0,&status)==PCUIAccepted);
    PCUIBegin(&q,101);assert(!PCUIIsCurrent(&q,first));
    assert(PCUIEvaluate(&q,101,PCREncodeStatus(101,0),101,0,&status)==PCUIWaiting);
    assert(PCUIEvaluate(&q,102,PCREncodeStatus(102,11),102,0,&status)==PCUITimeout);
    assert(PCUIEvaluate(&q,102,PCREncodeStatus(102,98),102,0,&status)==PCUIException);
    assert(PCUIEvaluate(&q,102,PCREncodeStatus(102,99),102,0,&status)==PCUIUnsupported);
    PCUIInvalidate(&q);
    assert(PCUIEvaluate(&q,102,PCREncodeStatus(102,3),102,3,&status)==PCUIIgnore);
    puts("UI status: stale sessions, torn snapshots, external edits, LPM mismatch, obsolete timers and failed writes PASS");
}
