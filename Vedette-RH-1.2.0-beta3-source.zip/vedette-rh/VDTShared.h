//  Copyright (c) 2021 udevs
//
//  This file is subject to the terms and conditions defined in
//  file 'LICENSE', which is part of this source code package.

#import "Common.h"

typedef NS_ENUM(NSUInteger, VDTConfigType) {
    VDTConfigTypeApp,
    VDTConfigTypeDaemon
};

typedef NS_ENUM(NSUInteger, VDTViolationPolicy) {
    VDTViolationPolicyNone,
    VDTViolationPolicyMonitor,
    VDTViolationPolicyMonitorAndTerminate,
    VDTViolationPolicyThrottle
};

#ifdef __cplusplus
extern "C" {
#endif

NSDictionary* getPrefs();
NSDictionary* getTempPrefs();
id valueForKey(NSString *key);
id valueForKeyWithPrefs(NSString *key, NSDictionary *prefs);
BOOL setValueForKey(NSString *key, id value);
BOOL setValueForKeyWithPrefs(NSString *key, id value, NSDictionary *prefs);
id valueForProcessConfigKey(NSString *identifier, NSString *key, id defaultValue, VDTConfigType type);
id valueForProcessConfigKeyWithPrefs(NSString *identifier, NSString *key, id defaultValue, VDTConfigType type, NSDictionary *prefs);
BOOL setValueForProcessConfigKey(NSString *identifier, NSString *key, id value, VDTConfigType type);
BOOL setValueForProcessConfigKeyWithPrefs(NSString *identifier, NSString *key, id value, VDTConfigType type, NSDictionary *prefs);

#ifdef __cplusplus
}
#endif



#ifdef __cplusplus
extern "C" {
#endif
BOOL VDTResetPreferences(void);
#ifdef __cplusplus
}
#endif

#ifdef __cplusplus
extern "C" {
#endif
BOOL VDTSetProcessConfigValue(NSString *identifier, NSString *key, id value, VDTConfigType type, NSString *executablePath);
BOOL VDTCancelRemoval(void);
NSDictionary *VDTGetStatus(void);
#ifdef __cplusplus
}
#endif
