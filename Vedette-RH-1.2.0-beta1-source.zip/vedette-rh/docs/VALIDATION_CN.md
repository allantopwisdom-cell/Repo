# Vedette RH 1.2.0~beta1 开发验证记录

日期：2026-11-04（北京时间）。

## 交付结论

这是修改后的源码工程，不是已经编译或真机验证的插件。未生成 deb，未推送 GitHub，未运行 Actions，未测量省电收益。

## 已完成

- 已以指定提交的上游源文件为基础重写核心执行链路。
- PID 数量换算、缓冲区释放、规则对应关系、串行状态更新、恢复日志、关闭/切换策略处理已实现。
- 已实现路径与启动时间检查、关键进程拒绝、默认关闭、默认 dry-run、Terminate 显式开关。
- 已调整 RootHide 构建、包标识与依赖，使用控制器单点注入。
- 已更新偏好配置、参数校验和状态查看，补充构建/验包脚本。

## 实际运行的测试

`./tests/run.sh`：

- 102 项断言通过，其中包含状态决策全部 64 种布尔组合。
- 覆盖无效/越界/溢出整数、阈值边界、PID 返回字节数换算、关键进程拒绝。
- 覆盖关闭、dry-run、重启恢复、规则移除和规则变化时应清理旧策略的决策。
- 纯 C 代码通过 `-Wall -Wextra -Werror`，AddressSanitizer 与 UndefinedBehaviorSanitizer。
- XML plist 全部解析通过；注入过滤、包配置及维护脚本约束通过。
- 所有维护脚本通过 `sh -n`。

首次测试因运行环境限制导致 LeakSanitizer 无法访问进程追踪数据；随后只关闭该项泄漏检测重新测试通过。纯 C 被测模块自身没有动态分配内存。
这些测试不覆盖 Foundation、Objective-C/Logos 编译、进程枚举的 iOS 系统行为、私有 API 调用或恢复日志的设备权限。

## 尚未验证的关键项目

| 项目 | 状态 |
|---|---|
| Objective-C / Objective-C++ / Logos 全量编译 | 未执行：缺少 Theos、iOS SDK 与 Apple 工具链 |
| arm64e Mach-O / ABI / 链接符号 | 未验证 |
| RootHide 签名、安装和加载 | 未验证 |
| AltList、PreferenceLoader 实际兼容 | 未验证 |
| runningboardd 权限与 CPU API 执行效果 | 未验证 |
| 多 App 真实阈值绑定与 PID 重用压力测试 | 未验证 |
| 关闭、重启、部分失败后的真机恢复 | 未验证 |
| 与 PowerCuff / Hello CPU / Hello Memory Status 叠加 | 未验证 |
| 功耗、温度、性能、watchdog 与长期稳定性 | 未验证 |

## 未宣称解决的边界

没有消除 runningboardd 注入风险，没有保证 PID 调用竞态为零，没有保存外部自定义 CPU 限制的精确原始状态，没有实现高频 CPU 监测或短命进程全捕获。恢复日志损坏时阻止新策略，保留现场供诊断。

## 来源

- Vedette 上游：https://github.com/udevsharold/vedette/tree/e406387f9fd06bc352e36beaa9163e816705164e
- Apple libproc API 签名参考：https://github.com/apple-oss-distributions/xnu/blob/main/libsyscall/wrappers/libproc/libproc_internal.h
- RootHide 路径 API：https://github.com/roothide/libroothide/blob/main/roothide.h
- RootHide Theos：https://github.com/roothide/theos

Apple main 分支头文件只用于核对函数声明，不能作为 iOS 16.5 私有 API 行为已验证的证据。
