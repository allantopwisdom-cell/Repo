from pathlib import Path
import sys
root=Path(__file__).resolve().parents[1]
s=(root/'Powercuff.x').read_text()
functions=s[s.index('static BOOL PCReadResponse(void)'):s.index('static void PCPublish(void)')]
Path(sys.argv[1]).write_text((root/'tests/response.m').read_text().replace('// ACTUAL_RESPONSE_FUNCTIONS',functions))
