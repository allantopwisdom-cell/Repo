#import <Foundation/Foundation.h>
#import <assert.h>
#import <math.h>
#import "../Preferences.h"
#import "../Runtime.h"
static Class Fixture(const char *name, const char *initType, const char *applyType) {
    Class cls = objc_allocateClassPair(NSObject.class, name, 0);
    // Only type encodings are inspected; these IMPs are never invoked.
    if (initType) class_addMethod(cls,@selector(initProduct:),(IMP)imp_implementationWithBlock(^id(id self,id data){(void)data;return self;}),initType);
    if (applyType) class_addMethod(cls,@selector(putDeviceInThermalSimulationMode:),(IMP)imp_implementationWithBlock(^(id self,id data){(void)self;(void)data;}),applyType);
    objc_registerClassPair(cls);
    return cls;
}
int main(void) { @autoreleasepool {
    for (NSUInteger mode=0;mode<5;mode++) {
        for (NSUInteger require=0;require<2;require++) for (NSUInteger lpm=0;lpm<2;lpm++) {
            assert(PCNormalizeSettings(@{@"PowerMode":@(mode),@"RequireLowPowerMode":@(require)},YES,lpm)==(require&&!lpm?0:mode));
        }
    }
    NSArray *invalid=@[@YES,@NO,@"3",@-1,@5,@3.5,@(NAN),@(INFINITY),NSNull.null,@[],@{}];
    for (id raw in invalid) assert(PCNormalizeSettings(@{@"PowerMode":raw},YES,YES)==0);
    for (id raw in @[@2,@-1,@0.5,@"1",NSNull.null,@(NAN)])
        assert(PCNormalizeSettings(@{@"PowerMode":@3,@"RequireLowPowerMode":raw},YES,YES)==0);
    assert(PCNormalizeSettings(nil,YES,YES)==0);
    assert(PCNormalizeSettings(@{@"PowerMode":@4},NO,YES)==0);
    assert(PCNormalizeSettings(@{@"PowerMode":@3,@"RequireLowPowerMode":@YES},YES,YES)==3);
    assert(PCNormalizeSettings(@{@"PowerMode":@3,@"RequireLowPowerMode":@YES},YES,NO)==0);
    assert(PCNormalizeSettings(@{@"PowerMode":@3,@"RequireLowPowerMode":@NO},YES,NO)==3);
    assert(PCCheckProductABI(Fixture("PCValid","@@:@","v@:@")));
    Class applyOnly=Fixture("PCApplyOnly",NULL,"v@:@");
    assert(!PCCheckProductABI(applyOnly) && PCCheckApplyABI(applyOnly));
    assert(!PCCheckProductABI(Nil));
    assert(!PCCheckProductABI(Fixture("PCMissing",NULL,"v@:@")));
    assert(!PCCheckProductABI(Fixture("PCBlock","@@:@","v@:@?")));
    assert(!PCCheckProductABI(Fixture("PCScalar","@@:@","v@:q")));
    assert(!PCCheckProductABI(Fixture("PCBadReturn","@@:@","q@:@")));
    assert(!PCCheckProductABI(Fixture("PCExtra","@@:@","v@:@@")));
    assert(!PCCheckProductABI(Fixture("PCBadInit","q@:@","v@:@")));
    puts("PASS: real Foundation preference types, LPM truth table, failure fallback, production Objective-C ABI checks");
} return 0; }
