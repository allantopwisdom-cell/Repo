import gzip,io,lzma,pathlib,sys,tarfile,tempfile,unittest
from contextlib import redirect_stdout
sys.path.insert(0,str(pathlib.Path(__file__).resolve().parents[1]/'scripts'))
from normalize_package import normalize,members
from package_format import open_tar,load_plist,plist_equal,control_fields,decode_boolean_entitlements
class FormatTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        output=io.BytesIO()
        with tarfile.open(fileobj=output,mode='w',format=tarfile.USTAR_FORMAT) as t:
            item=tarfile.TarInfo('file');item.size=1;t.addfile(item,io.BytesIO(b'x'))
        cls.raw=output.getvalue()
    def test_valid_encodings(self):
        for suffix,encoder in [('.xz',lzma.compress),('.gz',gzip.compress),('.lzma',lambda b:lzma.compress(b,format=lzma.FORMAT_ALONE))]:
            with self.subTest(suffix=suffix),open_tar(encoder(self.raw),'data.tar'+suffix) as t:self.assertEqual(t.extractfile('file').read(),b'x')
    def test_bad_xz_frames(self):
        for blob in [lzma.compress(self.raw)+b'x',lzma.compress(self.raw)+lzma.compress(b''),lzma.compress(self.raw)[:-5],lzma.compress(gzip.compress(self.raw))]:
            with self.subTest(size=len(blob)),self.assertRaises(AssertionError):
                with open_tar(blob,'data.tar.xz'):pass
    def test_bad_lzma_frames(self):
        encoded=lzma.compress(self.raw,format=lzma.FORMAT_ALONE)
        for blob in [encoded+b'x',encoded+encoded,encoded[:-5]]:
            with self.subTest(size=len(blob)),self.assertRaises(AssertionError):
                with open_tar(blob,'data.tar.lzma'):pass
    def test_bad_gzip_frames(self):
        for blob in [gzip.compress(self.raw)+b'x',gzip.compress(self.raw)+gzip.compress(b''),gzip.compress(self.raw)[:-5]]:
            with self.subTest(size=len(blob)),self.assertRaises(AssertionError):
                with open_tar(blob,'data.tar.gz'):pass
    def test_tar_trailers(self):
        for raw in [self.raw+b'x',self.raw+b'x'+bytes(511),self.raw[:1024]]:
            with self.subTest(size=len(raw)),self.assertRaises(AssertionError):
                with open_tar(lzma.compress(raw),'data.tar.xz'):pass
    def test_duplicate_plist(self):
        for xml in [b'<dict><key>x</key><integer>1</integer><key>x</key><integer>2</integer></dict>',b'<dict><key>x</key><dict><key>a</key><true/><key>a</key><false/></dict></dict>']:
            with self.subTest(xml=xml),self.assertRaises(AssertionError):load_plist(b'<plist version="1.0">'+xml+b'</plist>')
    def test_scalar_types(self):
        for a,b in [(False,0),(1,1.0),([True],[1]),({'x':False},{'x':0})]:self.assertFalse(plist_equal(a,b))
        self.assertTrue(plist_equal({'x':[False,1,1.0]},{'x':[False,1,1.0]}))
    def test_der_entitlements(self):
        good=bytes.fromhex('310830060c0178010101')
        self.assertEqual(decode_boolean_entitlements(good),{'x':True})
        bad=[good+b'x',good[:-1],bytes.fromhex('310830060c0178020101'),bytes.fromhex('311030060c017801010130060c0178010100')]
        for data in bad:
            with self.subTest(data=data),self.assertRaises(AssertionError):decode_boolean_entitlements(data)
    def test_normalizer_atomic_rejection(self):
        def ar(entries):
            result=bytearray(b'!<arch>\n')
            for name,blob in entries.items():
                result+=f'{name+"/":<16}{0:<12}{0:<6}{0:<6}{"100644":<8}{len(blob):<10}`\n'.encode()+blob
                if len(blob)%2:result+=b'\n'
            return bytes(result)
        base={'debian-binary':b'2.0\n','control.tar.xz':lzma.compress(self.raw),'data.tar.xz':lzma.compress(self.raw)}
        with tempfile.TemporaryDirectory() as tmp:
            path=pathlib.Path(tmp)/'test.deb'
            for which in ['extra-ar','trailer']:
                bad=dict(base)
                if which=='extra-ar':bad['extra']=b'x'
                else:bad['data.tar.xz']+=b'x'
                original=ar(bad);path.write_bytes(original)
                with self.subTest(which=which),self.assertRaises(AssertionError):normalize(path,0)
                self.assertEqual(path.read_bytes(),original)
            path.write_bytes(ar(base))
            with redirect_stdout(io.StringIO()):normalize(path,0)
            self.assertEqual(list(members(path.read_bytes())),list(base))
    def test_control_ambiguity(self):
        for raw in [b'Package: a\npackage: b\n',b'Package: a\n\nVersion: 1\n',b'Package: a\x00\n',b' continuation\n']:
            with self.subTest(raw=raw),self.assertRaises(AssertionError):control_fields(raw)
        self.assertEqual(control_fields(b'Package: a\nDescription: test\n continued\n')['Description'],'test\ncontinued')
if __name__=='__main__':unittest.main(verbosity=2)
