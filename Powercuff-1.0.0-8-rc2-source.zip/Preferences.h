#pragma once
#import <Foundation/Foundation.h>
#import <CoreFoundation/CoreFoundation.h>
#import "Policy.h"
// This parser is also compiled and exercised on macOS with real Foundation values.
static inline unsigned PCNormalizeSettings(NSDictionary *snapshot, BOOL synchronized, BOOL lowPower) {
    id mode = snapshot[@"PowerMode"];
    id require = snapshot[@"RequireLowPowerMode"];
    if (!synchronized) return 0;
    if (![mode isKindOfClass:NSNumber.class] || CFGetTypeID((__bridge CFTypeRef)mode) == CFBooleanGetTypeID()) return 0;
    if (require && (![require isKindOfClass:NSNumber.class] ||
        !([require doubleValue] == 0.0 || [require doubleValue] == 1.0))) return 0;
    return PCEffectiveMode(PCModeFromDouble([mode doubleValue]), require && [require boolValue], lowPower);
}
