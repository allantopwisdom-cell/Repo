from pathlib import Path
import sys
root=Path(__file__).resolve().parents[1]
s=(root/'Powercuff.x').read_text()
mode=s[s.index('static NSString *PCModeString('):s.index('static void PCApply(')]
apply=s[s.index('static void PCApply('):s.index('static BOOL PCReadResponse(')]
template=(root/'tests/runtime.m').read_text().replace('#import "../Protocol.h"','#import "Protocol.h"').replace('#import "../Runtime.h"','#import "Runtime.h"')
assert template.count('// ACTUAL_PRODUCTION_FUNCTIONS')==1
Path(sys.argv[1]).write_text(template.replace('// ACTUAL_PRODUCTION_FUNCTIONS',mode+apply))
