# PowerCuff RootHide 1.2.7

融合重建版，目标iPhone14 Pro Max/A16、iOS16.5、RootHide Dopamine3.0.4。基于已交付1.2.5完整源码，结合上传R3vamp1.5.1的图标和开关交互思路；不复用其主插件或控制中心旧二进制。

默认Off，PowerMode整数0..4：off/nominal/light/moderate/heavy。nominal仍在模拟。RequireLowPowerMode默认关闭，开启后真实LPM关闭请求Off且保留保存档位。持久偏好域com.dao.powercuff，沿用1.2.5偏好；不自动迁移R3vamp的com.rpetrich.powercuff。

控制中心短按：当前非零则关闭；当前关闭则恢复LastEnabledMode，缺失/非法时首次用Light(2)。长按展开五档选择。LastEnabledMode只记录请求值，不表示后台实际应用；LPM门控仍然有效。保留会话核对、故障缓存说明、3.2秒确认窗口与pcctl诊断。

固化UIDeviceFamily=[1,2]，此修正在用户设备上使1.2.5组件恢复显示。新增版本完整安装后的发现/点击/长按/状态仍需真机验收。

保留1.2.5角色隔离、偏好严格校验、有限通信恢复、方法ABI检查、弱对象/局部强引用、异常熔断、停用握手。安装脚本不killall thermalmonitord。升级/卸载后经越狱工具重启用户空间，先单独Off→Light→Off。

没有新增锁屏Heavy、后台冻结、两秒唤醒引擎、固定频率/30FPS/性能百分比或充电限流。实际热管理/续航、PAC和watchdog必须由设备测试，不能保证比旧版更省电。

构建：macOS15/Xcode16.4，固定RootHide Theos与iPhoneOS16.5 SDK；设置THEOS及SOURCE_DATE_EPOCH后sh build.sh。执行核心/协议/UI/CLI/偏好/格式/快捷开关/模块元数据检查，再完整编译三个生产目标，签名、规范化、验证最终DEB及22类变异。实际构建结果以交付日志为准。

## 1.2.7 审查修订

以已交付1.2.6为直接基线，修复停用路径绕过同对象异常熔断、停用异常不熔断及重复Off调用。永久停用后的对象替换先重置对象缓存，再仅请求Off。详见AUDIT-1.2.7.md；历史AUDIT-1.2.6.md仅描述该旧版本。

新增四组核心、两组CC源码主机测试，核心总计37组、CC总计8组；其他参数/资源/协议/CLI保持。CI要求先在封存1.2.6复现预期故障，再在修订版全部回归、clean编译和22类真实包变异通过。封存源码时macOS新检查尚待执行，最终结果以本次实际构建记录及交付报告为准。用户已授权在独立审查分支公开提交和Actions构建；不等于真机测试已执行。
