// Original project Copyright (c) 2021 udevs; rewritten manager, GPLv3.
#import "VDTProcessManager.h"
#import "VDTPolicy.h"
#include "VDTProcCompat.h"
#include <dlfcn.h>
#include <unistd.h>
#include <errno.h>
#include <signal.h>
#include <limits.h>
#include <string.h>
#include <vector>

// ABI signatures checked against Apple's libproc_internal.h. No private-header SDK dependency.
typedef int (*PIDCall)(pid_t);
typedef int (*ThrottleCall)(pid_t,int,int);
typedef int (*MonitorCall)(pid_t,int,int);
static VDTListPIDsFn listPIDs;
static VDTPIDInfoFn pidInfo;
static VDTPIDPathFn pidPath;
static PIDCall clearCPU,disableMonitor,defaultsMonitor,resumeMonitor;
static ThrottleCall throttleCPU;
static MonitorCall fatalMonitor;
static NSMutableDictionary<NSString *,NSDictionary *> *tracked;
static BOOL initialized;
static BOOL recovery;
static NSString *lastError=@"";
static NSString *loadError;

#ifdef VDT_HOST_TEST
extern void *VDTTestLookup(const char *name);
extern BOOL VDTTestProcessGone(pid_t pid);
#define VDT_LOOKUP(name) VDTTestLookup(name)
#else
#define VDT_LOOKUP(name) dlsym(RTLD_DEFAULT,name)
#endif

static BOOL processGone(pid_t pid) {
#ifdef VDT_HOST_TEST
    return VDTTestProcessGone(pid);
#else
    errno=0;
    return kill(pid,0)==-1 && errno==ESRCH;
#endif
}
static BOOL integer(id value,int lo,int hi,int *out) {
    if (![value isKindOfClass:NSString.class] && ![value isKindOfClass:NSNumber.class]) return NO;
    return vdt_parse_integer([[value description] UTF8String],lo,hi,out);
}
static BOOL flag(id value,BOOL fallback) {
    int n=0; return value ? (integer(value,0,1,&n) ? n!=0 : fallback) : fallback;
}
static void failure(NSString *message) {
    if (![lastError isEqualToString:message]) NSLog(@"[Vedette RH] %@",message);
    lastError=message;
}
static BOOL result(int rc,NSString *operation,pid_t pid) {
    if(rc==0)return YES;
    failure([NSString stringWithFormat:@"%@ pid=%d rc=%d errno=%d",operation,pid,rc,errno]); return NO;
}
static NSDictionary *identity(pid_t pid) {
    if(pid<=1)return nil;
    VDTProcBSDInfo bsd={};
    if(pidInfo(pid,VDT_PROC_PIDTBSDINFO,0,&bsd,sizeof(bsd))!=(int)sizeof(bsd))return nil;
    char path[VDT_PROC_PIDPATHINFO_MAXSIZE]={0};
    int n=pidPath(pid,path,sizeof(path));
    if(n<=0 || !memchr(path,0,sizeof(path)))return nil;
    NSString *pathString=[NSString stringWithUTF8String:path];
    if(!pathString.length)return nil;
    return @{@"pid":@(pid),@"path":pathString,@"startSec":@(bsd.pbi_start_tvsec),@"startUSec":@(bsd.pbi_start_tvusec)};
}
static BOOL eligible(NSDictionary *process) {
    return process && [process[@"pid"] intValue]!=getpid() &&
        !vdt_protected_name([process[@"path"] lastPathComponent].UTF8String);
}
static BOOL sameIdentity(NSDictionary *a,NSDictionary *b) {
    return a && b && [a[@"pid"] isEqual:b[@"pid"]] && [a[@"path"] isEqual:b[@"path"]] &&
        [a[@"startSec"] isEqual:b[@"startSec"]] && [a[@"startUSec"] isEqual:b[@"startUSec"]];
}
static NSArray<NSNumber *> *allPIDs(void) {
    int bytes=listPIDs(VDT_PROC_ALL_PIDS,0,NULL,0);
    if(bytes<=0 || bytes>4*1024*1024){failure(@"PID sizing failed");return nil;}
    for(int attempt=0;attempt<3;attempt++) {
        size_t capacity=(size_t)bytes+4096;
        std::vector<pid_t> buffer((capacity+sizeof(pid_t)-1)/sizeof(pid_t));
        int actualBytes=(int)(buffer.size()*sizeof(pid_t));
        int used=listPIDs(VDT_PROC_ALL_PIDS,0,buffer.data(),actualBytes);
        if(used<=0){failure(@"PID enumeration failed");return nil;}
        if(used>=actualBytes){bytes=actualBytes*2;continue;}
        NSMutableArray *pids=[NSMutableArray array];
        for(size_t i=0;i<vdt_pid_count(used,(size_t)actualBytes);i++)if(buffer[i]>1)[pids addObject:@(buffer[i])];
        return pids;
    }
    failure(@"PID list kept growing; cycle skipped");return nil;
}
static BOOL saveJournal(void) {
    if(!tracked.count) {
        if(![[NSFileManager defaultManager] fileExistsAtPath:VDT_RUNTIME_PATH])return YES;
        NSError *error=nil;
        if(![[NSFileManager defaultManager] removeItemAtPath:VDT_RUNTIME_PATH error:&error]) {
            failure([NSString stringWithFormat:@"Journal removal failed: %@",error]);return NO;
        }
        return YES;
    }
    if(![@{@"schema":@1,@"records":tracked} writeToFile:VDT_RUNTIME_PATH atomically:YES]) {
        failure(@"Journal write failed; no new policy will be applied");return NO;
    }
    return YES;
}
static BOOL validRecord(NSString *key,NSDictionary *record) {
    int pid=0,mode=0,p=0,t=0;
    return [record isKindOfClass:NSDictionary.class] && integer(key,2,INT_MAX,&pid) &&
        integer(record[@"pid"],2,INT_MAX,&pid) && [key isEqualToString:[record[@"pid"] description]] &&
        [record[@"path"] isKindOfClass:NSString.class] && [record[@"path"] hasPrefix:@"/"] &&
        [record[@"startSec"] isKindOfClass:NSNumber.class] && [record[@"startUSec"] isKindOfClass:NSNumber.class] &&
        integer(record[@"mode"],VDTTerminate,VDTThrottle,&mode) &&
        integer(record[@"percentage"],20,100,&p) && integer(record[@"interval"],60,3600,&t) &&
        vdt_valid_rule(mode,p,t) && [record[@"active"] isKindOfClass:NSNumber.class];
}
static void initialize(void) {
    if(initialized)return;
    initialized=YES; recovery=YES; tracked=[NSMutableDictionary dictionary];
    listPIDs=(VDTListPIDsFn)VDT_LOOKUP("proc_listpids");
    pidInfo=(VDTPIDInfoFn)VDT_LOOKUP("proc_pidinfo");
    pidPath=(VDTPIDPathFn)VDT_LOOKUP("proc_pidpath");
    if(!listPIDs || !pidInfo || !pidPath){loadError=@"Process discovery APIs unavailable; controller blocked.";return;}
    clearCPU=(PIDCall)VDT_LOOKUP("proc_clear_cpulimits");
    disableMonitor=(PIDCall)VDT_LOOKUP("proc_disable_cpumon");
    defaultsMonitor=(PIDCall)VDT_LOOKUP("proc_set_cpumon_defaults");
    resumeMonitor=(PIDCall)VDT_LOOKUP("proc_resume_cpumon");
    throttleCPU=(ThrottleCall)VDT_LOOKUP("proc_setcpu_percentage");
    fatalMonitor=(MonitorCall)VDT_LOOKUP("proc_set_cpumon_params_fatal");
    if(![[NSFileManager defaultManager] fileExistsAtPath:VDT_RUNTIME_PATH])return;
    NSDictionary *journal=[NSDictionary dictionaryWithContentsOfFile:VDT_RUNTIME_PATH];
    id records=journal[@"records"];
    if(![journal[@"schema"] isEqual:@1] || ![records isKindOfClass:NSDictionary.class] || [records count]>4096) {
        loadError=@"Runtime journal is invalid; enforcement blocked. Preserve it for diagnosis.";return;
    }
    for(id key in records) {
        if(![key isKindOfClass:NSString.class] || !validRecord(key,records[key])) {
            loadError=@"Runtime journal has an invalid record; enforcement blocked.";return;
        }
        tracked[key]=records[key];
    }
}
// Only clear the policy family previously touched by this controller.
// CPU monitor restoration uses system defaults, not an exact prior fatal/nonfatal configuration.
static BOOL restore(NSDictionary *record) {
    pid_t pid=[record[@"pid"] intValue];
    if(!sameIdentity(record,identity(pid))) {
        // Never act on a reused PID. If the process still exists but cannot be identified, retain the record.
        if(processGone(pid))return YES;
        NSDictionary *now=identity(pid);
        if(now && !sameIdentity(record,now))return YES;
        failure([NSString stringWithFormat:@"Identity unavailable for restore pid=%d; retained",pid]);return NO;
    }
    if(!eligible(record)){failure(@"Refusing cleanup of a protected process");return NO;}
    if([record[@"mode"] intValue]==VDTThrottle) {
        if(!clearCPU){failure(@"Missing proc_clear_cpulimits");return NO;}
        if(!sameIdentity(record,identity(pid)))return NO;
        return result(clearCPU(pid),@"clear throttle",pid);
    }
    if(!disableMonitor || !defaultsMonitor || !resumeMonitor){failure(@"Missing CPU monitor recovery APIs");return NO;}
    if(!sameIdentity(record,identity(pid)))return NO;
    BOOL disabled=result(disableMonitor(pid),@"disable monitor",pid);
    if(!disabled)return NO;
    if(!sameIdentity(record,identity(pid)))return NO;
    BOOL reset=result(defaultsMonitor(pid),@"restore monitor defaults",pid);
    if(!sameIdentity(record,identity(pid)))return NO;
    BOOL resumed=result(resumeMonitor(pid),@"resume monitor",pid);
    return reset && resumed;
}
static BOOL apply(NSDictionary *record) {
    pid_t pid=[record[@"pid"] intValue]; int p=[record[@"percentage"] intValue];
    if(!eligible(record) || !sameIdentity(record,identity(pid)))return NO;
    if([record[@"mode"] intValue]==VDTThrottle) {
        return throttleCPU && clearCPU && result(throttleCPU(pid,1,p),@"apply throttle",pid);
    }
    if(!disableMonitor || !defaultsMonitor || !resumeMonitor || !fatalMonitor)return NO;
    if(!result(disableMonitor(pid),@"disable before monitor",pid))return NO;
    if(!sameIdentity(record,identity(pid)))return NO;
    BOOL configured=result(fatalMonitor(pid,p,[record[@"interval"] intValue]),@"apply fatal monitor",pid);
    if(!sameIdentity(record,identity(pid)))return NO;
    BOOL resumed=result(resumeMonitor(pid),@"resume configured monitor",pid);
    return configured && resumed;
}
static NSDictionary *rulesFromPrefs(NSDictionary *prefs,BOOL apps,NSUInteger *invalid) {
    id list=prefs[apps?@"appConfigs":@"daemonConfigs"];
    if(!list)return @{};
    if(![list isKindOfClass:NSArray.class] || [list count]>1024){++*invalid;return @{};}
    NSMutableDictionary *rules=[NSMutableDictionary dictionary]; NSMutableSet *duplicates=[NSMutableSet set];
    for(id item in list) {
        if(![item isKindOfClass:NSDictionary.class]){++*invalid;continue;}
        if(!flag(item[@"enabled"],NO))continue;
        id ident=item[apps?@"bundleIdentifier":@"daemonName"];
        int mode=VDTThrottle,p=80,t=120;
        if(![ident isKindOfClass:NSString.class] || ![ident length] || [ident length]>512 ||
            (item[@"violationPolicy"] && !integer(item[@"violationPolicy"],2,3,&mode)) ||
            (item[@"percentage"] && !integer(item[@"percentage"],20,100,&p)) ||
            (mode==VDTTerminate && item[@"interval"] && !integer(item[@"interval"],60,3600,&t)) ||
            !vdt_valid_rule(mode,p,t)) {++*invalid;continue;}
        if(!apps && vdt_protected_name([ident UTF8String])){++*invalid;continue;}
        if(mode==VDTTerminate && !flag(prefs[@"allowTerminate"],NO)){++*invalid;continue;}
        if(rules[ident] || [duplicates containsObject:ident]) {
            [rules removeObjectForKey:ident];[duplicates addObject:ident];++*invalid;continue;
        }
        rules[ident]=@{@"mode":@(mode),@"percentage":@(p),@"interval":@(t)};
    }
    return rules;
}
static NSDictionary *ruleForIdentity(NSDictionary *process,NSDictionary *apps,NSDictionary *daemons) {
    NSString *path=process[@"path"];
    NSRange appRange=[path rangeOfString:@".app/" options:NSBackwardsSearch];
    if(appRange.location!=NSNotFound) {
        NSString *bundle=[path substringToIndex:appRange.location+4];
        NSDictionary *info=[NSDictionary dictionaryWithContentsOfFile:[bundle stringByAppendingPathComponent:@"Info.plist"]];
        id executable=info[@"CFBundleExecutable"],identifier=info[@"CFBundleIdentifier"];
        if(![executable isKindOfClass:NSString.class] || ![identifier isKindOfClass:NSString.class])return nil;
        // Explicitly exclude extensions/helpers and Preferences; do not classify these as daemons.
        if(![path isEqualToString:[bundle stringByAppendingPathComponent:executable]] ||
            [identifier isEqualToString:@"com.apple.Preferences"] || [identifier isEqualToString:@"com.apple.springboard"])return nil;
        return apps[identifier];
    }
    return daemons[path.lastPathComponent];
}
void VDTReconcile(NSDictionary *prefs) {
    initialize();
    if(loadError){
        failure(loadError);
        [@{@"schema":@1,@"date":[NSDate date],@"blocked":@YES,@"lastError":loadError,
          @"tracked":@(tracked.count),@"journalInvalid":@YES} writeToFile:VDT_STATUS_PATH atomically:YES];
        return;
    }
    BOOL enabled=flag(prefs[@"enabled"],NO);
    BOOL dryRun=flag(prefs[@"dryRun"],YES);
    NSUInteger invalid=0;
    NSDictionary *apps=rulesFromPrefs(prefs,YES,&invalid), *daemons=rulesFromPrefs(prefs,NO,&invalid);
    NSMutableDictionary *desired=[NSMutableDictionary dictionary];
    NSArray *pids=(enabled && (apps.count || daemons.count))?allPIDs():@[];
    // Snapshot failure forbids new policy application but must not bypass cleanup.
    BOOL discoveryFailed=(pids==nil);
    if(discoveryFailed)pids=@[];
    for(NSNumber *pid in pids) {
        NSDictionary *process=identity(pid.intValue); if(!eligible(process))continue;
        NSDictionary *rule=ruleForIdentity(process,apps,daemons); if(!rule)continue;
        NSMutableDictionary *record=[process mutableCopy];[record addEntriesFromDictionary:rule];record[@"active"]=@YES;
        desired[pid.stringValue]=record;
    }
    BOOL blocked=discoveryFailed;
    for(NSString *key in [tracked.allKeys copy]) {
        NSDictionary *old=tracked[key];
        if(vdt_next_action(YES,[old isEqual:desired[key]],enabled,dryRun,recovery,desired[key]!=nil)==VDTKeep)continue;
        // Persist a pending cleanup before touching the kernel. If deletion/writeback fails,
        // this record must never be mistaken for an already active rule on a later cycle.
        NSMutableDictionary *pending=[old mutableCopy];pending[@"active"]=@NO;
        tracked[key]=[pending copy];
        if(!saveJournal()){blocked=YES;continue;}
        if(restore(pending)) {
            [tracked removeObjectForKey:key];
            if(!saveJournal()){tracked[key]=[pending copy];blocked=YES;break;}
        } else blocked=YES;
    }
    // A failed initial recovery stays latched until a complete cleanup succeeds.
    recovery=recovery && blocked;
    if(!blocked && enabled && !dryRun) {
        for(NSString *key in desired) {
            if(vdt_next_action(tracked[key]!=nil,NO,enabled,dryRun,NO,YES)!=VDTApply)continue;
            int mode=[desired[key][@"mode"] intValue];
            if((mode==VDTThrottle && (!throttleCPU || !clearCPU)) ||
               (mode==VDTTerminate && (!fatalMonitor || !disableMonitor || !defaultsMonitor || !resumeMonitor))) {
                failure(@"Required CPU policy/recovery APIs unavailable; no new limits applied");blocked=YES;break;
            }
            NSMutableDictionary *record=[desired[key] mutableCopy];record[@"active"]=@NO;
            // Write-ahead record also covers a controller crash partway through an API sequence.
            tracked[key]=record;
            if(!saveJournal()){[tracked removeObjectForKey:key];blocked=YES;break;}
            if(apply(record)) {
                record[@"active"]=@YES;tracked[key]=[record copy];
                if(!saveJournal()){record[@"active"]=@NO;tracked[key]=[record copy];blocked=YES;break;}
            } else {
                failure([NSString stringWithFormat:@"Apply failed or API unavailable for pid %@; recovery pending",key]);
                // Keep pending journal; next cycle restores before retrying.
                blocked=YES;break;
            }
        }
    }
    if(!tracked.count && !saveJournal())blocked=YES;
    NSDictionary *status=@{@"schema":@1,@"date":[NSDate date],@"enabled":@(enabled),@"dryRun":@(dryRun),
      @"matched":@(desired.count),@"tracked":@(tracked.count),@"invalidRules":@(invalid),@"blocked":@(blocked),
      @"lastError":lastError,@"controller":@"runningboardd",@"discoverySeconds":@30,
      @"recovering":@(recovery),@"discoveryFailed":@(discoveryFailed)};
    if(![status writeToFile:VDT_STATUS_PATH atomically:YES])failure(@"Status write failed");
}
