// GPL-3.0-or-later. Development fork, 2026.
#include "VDTPolicy.h"
#include <errno.h>
#include <stdlib.h>
#include <string.h>
bool vdt_parse_integer(const char *s,int lo,int hi,int *out) {
    if (!s || !*s || !out) return false;
    for (const char *p=s; *p; ++p) if (*p<'0'||*p>'9') return false;
    errno=0; char *end=NULL; long n=strtol(s,&end,10);
    if (errno || !end || *end || n<lo || n>hi) return false;
    *out=(int)n; return true;
}
bool vdt_valid_rule(int mode,int p,int interval) {
    return (mode==VDTThrottle || mode==VDTTerminate) && p>=20 && p<=100 &&
        (mode==VDTThrottle || (interval>=60 && interval<=3600));
}
size_t vdt_pid_count(int bytes,size_t capacity) {
    if (bytes<=0) return 0;
    size_t n=(size_t)bytes; if(n>capacity)n=capacity;
    return n/sizeof(int32_t);
}
bool vdt_protected_name(const char *name) {
    if (!name || !*name) return true;
    static const char *const names[]={"launchd","kernel_task","runningboardd","thermalmonitord",
      "watchdogd","SpringBoard","backboardd","logd","notifyd","securityd","amfid",
      "installd","configd","wifid","commcenter","CommCenter","powerd","assertiond",
      "mediaserverd","audiomxd","bluetoothd","cfprefsd","xpcproxy","sshd",
      "jailbreakd","roothideinit","dopamine","Dopamine","Preferences",NULL};
    for(size_t i=0;names[i];++i) if(!strcmp(name,names[i]))return true;
    return false;
}

VDTAction vdt_next_action(bool old,bool same,bool enabled,bool dry,bool recovery,bool desired) {
    if(old)return !recovery && enabled && !dry && desired && same ? VDTKeep : VDTRestore;
    return enabled && !dry && desired ? VDTApply : VDTIdle;
}
