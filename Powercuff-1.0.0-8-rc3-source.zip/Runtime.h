#pragma once
#import <Foundation/Foundation.h>
#import <objc/runtime.h>
static inline BOOL PCObjectType(const char *type) { return type[0] == '@' && type[1] != '?'; }
static inline BOOL PCCheckApplyABI(Class cls) {
    Method method = class_getInstanceMethod(cls, @selector(putDeviceInThermalSimulationMode:));
    if (!method || method_getNumberOfArguments(method) != 3) return NO;
    char result[64] = {0}, arg[64] = {0};
    method_getReturnType(method, result, sizeof(result));
    method_getArgumentType(method, 2, arg, sizeof(arg));
    return result[0] == 'v' && result[1] == 0 && PCObjectType(arg);
}
static inline BOOL PCCheckInitializerABI(Class cls) {
    Method method = class_getInstanceMethod(cls, @selector(initProduct:));
    if (!method || method_getNumberOfArguments(method) != 3) return NO;
    char result[64] = {0}, arg[64] = {0};
    method_getReturnType(method, result, sizeof(result));
    method_getArgumentType(method, 2, arg, sizeof(arg));
    return PCObjectType(result) && PCObjectType(arg);
}
static inline BOOL PCCheckProductABI(Class cls) { return PCCheckInitializerABI(cls) && PCCheckApplyABI(cls); }
