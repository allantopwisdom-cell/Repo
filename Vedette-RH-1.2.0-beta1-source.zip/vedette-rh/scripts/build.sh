#!/bin/sh
set -eu
cd "$(dirname "$0")/.."
: "${THEOS:?Set THEOS to a fully installed RootHide Theos directory}"
if [ ! -d "$THEOS/vendor/mod/roothide" ]; then
  echo 'RootHide Theos package module is missing; refusing a generic/rootless build.' >&2
  exit 1
fi
command -v make >/dev/null
# AltList framework and the RootHide development headers/libraries must already be installed.
# Keep dependency acquisition separate so builds do not silently change the toolchain.
make clean
make package FINALPACKAGE=1 THEOS_PACKAGE_SCHEME=roothide
printf '%s\n' 'Build finished. Inspect packages/ and run scripts/verify_deb.sh on the produced file.'
