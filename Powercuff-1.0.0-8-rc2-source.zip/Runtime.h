#pragma once
#import <Foundation/Foundation.h>
#import <objc/runtime.h>
static inline BOOL PCObjectType(const char *type) { return type[0] == '@' && type[1] != '?'; }
static inline BOOL PCCheckProductABI(Class cls) {
    Method init = class_getInstanceMethod(cls, @selector(initProduct:));
    Method apply = class_getInstanceMethod(cls, @selector(putDeviceInThermalSimulationMode:));
    if (!init || !apply || method_getNumberOfArguments(init) != 3 || method_getNumberOfArguments(apply) != 3) return NO;
    char result[64] = {0}, arg[64] = {0}, initResult[64] = {0}, initArg[64] = {0};
    method_getReturnType(apply, result, sizeof(result));
    method_getArgumentType(apply, 2, arg, sizeof(arg));
    method_getReturnType(init, initResult, sizeof(initResult));
    method_getArgumentType(init, 2, initArg, sizeof(initArg));
    return result[0] == 'v' && result[1] == 0 && PCObjectType(arg) && PCObjectType(initResult) && PCObjectType(initArg);
}
