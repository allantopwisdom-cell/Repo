#!/usr/bin/env python3
"""Validate this rebuilt package, all Mach-O slices and CodeDirectory code pages and special slots.
No certificate-chain, device PAC, entitlements-policy or runtime verification is claimed.
"""
import hashlib,io,json,pathlib,plistlib,struct,subprocess,sys,tempfile,tarfile
from normalize_package import members
if not __debug__: raise RuntimeError('do not run verification with -O')
from macho_signature import verify_signature
SOURCE=pathlib.Path(__file__).resolve().parents[1]
def check_signature(b,off,size,entitlements=None):
    return verify_signature(b,off,size,entitlements)

def inspect(path):
    data=path.read_bytes();slices=[]
    if data[:4]==b'\xca\xfe\xba\xbe':
        for i in range(struct.unpack_from('>I',data,4)[0]):
            _,_,off,size,_=struct.unpack_from('>IIIII',data,8+20*i);slices.append(data[off:off+size])
    else:slices=[data]
    results=[]
    for b in slices:
        magic,cpu,sub,filetype,n,sz,flags,reserved=struct.unpack_from('<8I',b)
        assert magic==0xfeedfacf and cpu==0x100000c and sub==0x80000002, 'expected versioned arm64e'
        pos=32;loads=[];sig=None;minimum=None
        for _ in range(n):
            c,z=struct.unpack_from('<II',b,pos);assert z>=8 and pos+z<=32+sz
            if c in [0xc,0x80000018]:
                no=struct.unpack_from('<I',b,pos+8)[0]
                loads.append(b[pos+no:pos+z].split(b'\0')[0].decode())
            if c==0x32:
                platform,minimum,sdk=struct.unpack_from('<III',b,pos+8);assert platform==2
            if c==0x1d:sig=struct.unpack_from('<II',b,pos+8)
            if c in [0x21,0x2c]:assert struct.unpack_from('<I',b,pos+16)[0]==0, 'encrypted binary'
            pos+=z
        assert minimum == 0x100000, 'expected iOS 16.0 deployment target'
        assert sig is not None
        assert filetype==(2 if path.name=='pcctl' else 6), 'unexpected Mach-O file type'
        if path.name=='PowercuffRebuilt.dylib':
            assert '@loader_path/.jbroot/usr/lib/libsubstrate.dylib' in loads
            assert not any('/var/jb/' in x for x in loads)
        results.append({'subtype':hex(sub),'minimum':hex(minimum),'dependencies':loads,
                        'sha256':hashlib.sha256(b).hexdigest(),'signature':check_signature(b,*sig,plistlib.loads((SOURCE/'ctl/entitlements.plist').read_bytes()) if path.name=='pcctl' else None)})
    return results

def verify(deb):
    entries=members(deb.read_bytes())
    assert list(entries)==['debian-binary','control.tar.xz','data.tar.xz']
    expected_files={
        'Library/MobileSubstrate/DynamicLibraries/PowercuffRebuilt.dylib':0o755,
        'Library/MobileSubstrate/DynamicLibraries/PowercuffRebuilt.plist':0o644,
        'Library/ControlCenter/Bundles/PowercuffCC.bundle/PowercuffCC':0o755,
        'Library/ControlCenter/Bundles/PowercuffCC.bundle/Info.plist':0o644,
        'Library/PreferenceLoader/Preferences/Powercuff/Powercuff.plist':0o644,
        'usr/bin/pcctl':0o755}
    control_files={'control':0o644,'postinst':0o755,'prerm':0o755}
    for key in ['control.tar.xz','data.tar.xz']:
        expected=control_files if key.startswith('control') else expected_files
        found=set();seen=set();allowed_dirs={'.'}
        for name in expected:
            allowed_dirs.update(str(p) for p in pathlib.PurePosixPath(name).parents)
        with tarfile.open(fileobj=io.BytesIO(entries[key]),mode='r:*') as archive:
            for item in archive:
                assert item.uid==0 and item.gid==0, 'non-root numeric archive owner'
                assert item.isfile() or item.isdir(), 'unexpected archive member type'
                path=pathlib.PurePosixPath(item.name);name=str(path)
                assert not path.is_absolute() and '..' not in path.parts, 'unsafe archive path'
                assert name not in seen, 'duplicate normalized archive path'
                seen.add(name)
                if item.isdir(): assert name in allowed_dirs and item.mode==0o755, 'unexpected directory'
                else:
                    assert name in expected and item.mode==expected[name], 'unexpected file or permissions'
                    found.add(name)
                    if key.startswith('control') and name!='control':
                        assert archive.extractfile(item).read()==(SOURCE/'layout/DEBIAN'/name).read_bytes(), 'maintainer script differs from source'
        assert found==set(expected), 'package file set differs' 
    fields=subprocess.check_output(['dpkg-deb','-f',str(deb)]).decode()
    assert 'Package: com.powercuff.roothide\n' in fields and 'Version: 1.2.4\n' in fields
    assert 'Architecture: iphoneos-arm64e\n' in fields
    def control_fields(text):
        values={}
        for line in text.strip().splitlines():
            assert ': ' in line, 'malformed control field'
            k,v=line.split(': ',1);k=k.lower();assert k not in values, 'duplicate control field';values[k]=v
        return values
    actual=control_fields(fields);source=control_fields((SOURCE/'control').read_text())
    for key in ['depends','conflicts','replaces']:
        a=[x.strip() for x in actual[key].split(',')];b=[x.strip() for x in source[key].split(',')]
        assert len(a)==len(set(a)) and sorted(a)==sorted(b), 'dependency/conflict metadata differs from source'
    for key,value in source.items():
        if key not in ['depends','conflicts','replaces']: assert actual[key]==value, 'control metadata differs from source' 
    result={'package':deb.name,'sha256':hashlib.sha256(deb.read_bytes()).hexdigest(),'binaries':{}}
    with tempfile.TemporaryDirectory() as tmp:
        root=pathlib.Path(tmp);subprocess.run(['dpkg-deb','-x',str(deb),str(root)],check=True)
        for suffix in ['Library/MobileSubstrate/DynamicLibraries/PowercuffRebuilt.dylib',
                       'Library/ControlCenter/Bundles/PowercuffCC.bundle/PowercuffCC','usr/bin/pcctl']:
            matches=[p for p in root.rglob(pathlib.Path(suffix).name) if str(p).endswith(suffix)]
            assert len(matches)==1, f'missing or duplicate binary {suffix}'
            result['binaries'][suffix]=inspect(matches[0])
        filters=list(root.rglob('PowercuffRebuilt.plist'));assert len(filters)==1
        assert plistlib.loads(filters[0].read_bytes())=={'Filter':{'Executables':['thermalmonitord','SpringBoard']}}
        infos=list(root.rglob('Info.plist'));assert len(infos)==1
        info=plistlib.loads(infos[0].read_bytes());assert info==plistlib.loads((SOURCE/'cc/Info.plist').read_bytes()), 'module Info.plist differs from source'
        assert info['CFBundleShortVersionString']=='1.2.4'
        assert info['NSPrincipalClass']=='PowercuffCCModule'
        prefs=[p for p in root.rglob('Powercuff.plist') if 'PreferenceLoader' in p.parts];assert len(prefs)==1
        actual_prefs=plistlib.loads(prefs[0].read_bytes())
        expected_prefs=plistlib.loads((SOURCE/'layout/Library/PreferenceLoader/Preferences/Powercuff/Powercuff.plist').read_bytes())
        assert actual_prefs==expected_prefs, 'preferences differ from source'
        items=actual_prefs['items']
        mode=next(x for x in items if x.get('key')=='PowerMode')
        assert mode['validValues']==list(range(5)) and all(type(v) is int for v in mode['validValues'])
        assert type(mode['default']) is int and mode['default']==0
        gate=next(x for x in items if x.get('key')=='RequireLowPowerMode')
        assert type(gate['default']) is bool and gate['default'] is False
        keys={x['key'] for x in items if 'key' in x};assert keys=={'PowerMode','RequireLowPowerMode'}
        for x in items:
            if 'key' in x:assert x['defaults']=='com.dao.powercuff'
    return result
if __name__=='__main__':
    print(json.dumps(verify(pathlib.Path(sys.argv[1]).resolve()),ensure_ascii=False,indent=2))
