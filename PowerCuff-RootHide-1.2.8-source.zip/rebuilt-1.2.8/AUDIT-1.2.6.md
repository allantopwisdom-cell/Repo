# 1.2.6 源码循环审查摘要

基线为已准备的1.2.6源码ZIP（SHA256 7df574c07f330766c1a48a5e65136ecdfac39b5f50dc7a04a2b6e1bd4ad612aa），不是已编译安装包。

第一轮：发现展开菜单依赖未经目标验证的setMenuItems/dynamic-item路径；改为removeAllActions/addAction handler并检查可用性、弱引用和明确回退。增加生产CC控制器的Foundation主机模拟代码（待macOS执行）。独立契约补齐通知名、域、重复设置项、默认类型/档位与设备族声明校验。以基线源码临时副本复现：通知改成.update、PNG破坏CRC时，旧模块检查仍通过，新检查正确拒绝。

第二轮：发现折叠方块缺少显式选中状态更新，增加setSelected:可用性检查并按LPM门控后的请求值更新，明确不是后台回执。7张PNG加入CRC、IEND、解压界限和逐行filter检查；构建前逐项核验源码输入清单。真实DEB反例计划由20增至22（新增设置通知错配、重复设置项）。

第三轮：本地格式、模块/设置契约、协议、状态机、快捷开关和维护脚本回归未出现新失败；源码及资源清单、原资源哈希、核心字节保持情况一并核对。独立配置/PNG反例证明新增门禁能拒绝此前漏检输入，不声称是在已编译1.2.6 DEB上执行。

待执行：新Xcode构建，Foundation偏好/运行时/33组核心/生产CLI/实际CC模拟，22类新DEB变异和签名/路径校验，随后真机发现/短按/长按/LPM/重载/待机/watchdog/耗电验收。公开上传仍被上轮自动审批拦截所阻；本地通过不等于完整循环已闭合或软件绝对无缺陷。

菜单接口参考：https://github.com/nst/iOS-Runtime-Headers/blob/master/PrivateFrameworks/ControlCenterUIKit.framework/CCUIMenuModuleViewController.h（历史运行时提取，不能单独证明16.5可用；代码仍做可用性检查）。
