"""Validate arm64e code pages in the embedded CodeDirectory, not device trust."""
import hashlib, math, struct, sys
from pathlib import Path
b=Path(sys.argv[1]).read_bytes()
assert struct.unpack_from('<I',b)[0]==0xfeedfacf, 'expected thin Mach-O'
_,cpu,sub,kind,ncmd,sizecmd,flags,reserved=struct.unpack_from('<8I',b)
assert cpu==0x100000c and sub==0x80000002, 'expected versioned arm64e PAC00'
pos=32; sig=None; loads=[]
for _ in range(ncmd):
 cmd,size=struct.unpack_from('<II',b,pos);assert size>=8 and pos+size<=len(b)
 if cmd==0x1d: sig=struct.unpack_from('<II',b,pos+8)
 if cmd in (0xc,0xd):
  off=struct.unpack_from('<I',b,pos+8)[0]
  loads.append(b[pos+off:pos+size].split(b'\0')[0].decode())
 pos+=size
assert sig, 'missing embedded signature'
off,size=sig;s=b[off:off+size]
magic,length,count=struct.unpack_from('>III',s)
assert magic==0xfade0cc0 and length<=len(s)
verified=0
for i in range(count):
 slot,start=struct.unpack_from('>II',s,12+8*i)
 if slot!=0 and not (0x1000<=slot<=0x1005): continue
 magic,length,version,flags,hashoff,identoff,nspecial,ncode,limit=struct.unpack_from('>9I',s,start)
 assert magic==0xfade0c02
 cd=s[start:start+length];assert len(cd)==length
 hashsize,hashtype,platform,pagelog=struct.unpack_from('>4B',cd,36)
 assert pagelog<=20 and limit<=off
 page=1<<pagelog
 assert ncode==math.ceil(limit/page)
 algorithm={1:'sha1',2:'sha256',3:'sha256',4:'sha384'}[hashtype]
 for j in range(ncode):
  actual=hashlib.new(algorithm,b[j*page:min((j+1)*page,limit)]).digest()[:hashsize]
  assert actual==cd[hashoff+j*hashsize:hashoff+(j+1)*hashsize], ('bad code page',j)
 verified+=1
assert verified
assert any('libsubstrate' in name for name in loads), loads
print('PASS: arm64e, embedded CodeDirectory code-page hashes; device trust NOT tested')
print('\n'.join(loads))
