// GPL-3.0-or-later. All calls must execute on the controller's serial queue.
#import "Common.h"
void VDTReconcile(NSDictionary *preferences);
