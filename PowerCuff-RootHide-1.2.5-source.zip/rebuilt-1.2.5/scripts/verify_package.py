#!/usr/bin/env python3
"""Validate this rebuilt package, all Mach-O slices and CodeDirectory code pages and special slots.
No certificate-chain, device PAC, entitlements-policy or runtime verification is claimed.
"""
import hashlib,io,json,pathlib,plistlib,struct,subprocess,sys,tempfile,tarfile
from normalize_package import members
from package_format import open_tar,load_plist,plist_equal,control_fields
if not __debug__: raise RuntimeError('do not run verification with -O')
from macho_signature import verify_signature
SOURCE=pathlib.Path(__file__).resolve().parents[1]
def check_signature(b,off,size,entitlements=None):
    return verify_signature(b,off,size,entitlements)

def inspect(path):
    data=path.read_bytes();slices=[]
    assert data[:4]==b'\xcf\xfa\xed\xfe', 'expected thin Mach-O'
    slices=[data]
    results=[]
    for b in slices:
        magic,cpu,sub,filetype,n,sz,flags,reserved=struct.unpack_from('<8I',b)
        assert magic==0xfeedfacf and cpu==0x100000c and sub==0x80000002, 'expected versioned arm64e'
        assert n>0 and 32+sz<=len(b), 'Mach-O command bounds'
        pos=32;loads=[];sig=None;minimum=None;install_id=None
        for _ in range(n):
            c,z=struct.unpack_from('<II',b,pos);assert z>=8 and z%8==0 and pos+z<=32+sz
            if c in [0xc,0x20,0x80000018,0x8000001f,0x80000023,0xd]:
                assert z>=24
                no=struct.unpack_from('<I',b,pos+8)[0]
                assert 24<=no<z and b'\0' in b[pos+no:pos+z], 'dylib command name bounds'
                name=b[pos+no:pos+z].split(b'\0')[0].decode()
                if c==0xd:
                    assert install_id is None, 'duplicate install ID'
                    install_id=name
                else:loads.append(name)
            if c==0x32:
                assert minimum is None and z>=24, 'duplicate/truncated deployment command'
                platform,minimum,sdk=struct.unpack_from('<III',b,pos+8);assert platform==2
            if c==0x1d:
                assert sig is None and z==16, 'duplicate/truncated signature command'
                sig=struct.unpack_from('<II',b,pos+8)
            if c in [0x21,0x2c]:assert struct.unpack_from('<I',b,pos+16)[0]==0, 'encrypted binary'
            pos+=z
        assert pos==32+sz, 'unconsumed Mach-O load commands'
        assert sig is not None and sig[0]>=32+sz and sig[1]>0 and sum(sig)==len(b), 'signature bounds/trailer'
        expected_loads={'/usr/lib/libobjc.A.dylib','/System/Library/Frameworks/Foundation.framework/Foundation','/System/Library/Frameworks/CoreFoundation.framework/CoreFoundation','/usr/lib/libSystem.B.dylib'}
        if path.name=='PowercuffRebuilt.dylib':expected_loads.add('@loader_path/.jbroot/usr/lib/libsubstrate.dylib')
        if path.name=='PowercuffCC':expected_loads.update(['/System/Library/Frameworks/UIKit.framework/UIKit','/System/Library/PrivateFrameworks/ControlCenterUIKit.framework/ControlCenterUIKit'])
        assert len(loads)==len(set(loads)) and set(loads)==expected_loads, 'unexpected binary dependencies'
        ids={'PowercuffRebuilt.dylib':'@loader_path/.jbroot/Library/MobileSubstrate/DynamicLibraries/PowercuffRebuilt.dylib','PowercuffCC':'/Library/ControlCenter/Bundles/PowercuffCC.bundle/PowercuffCC','pcctl':None}
        assert install_id==ids[path.name], 'unexpected binary install ID'
        assert minimum == 0x100000, 'expected iOS 16.0 deployment target'
        assert sig is not None
        assert filetype==(2 if path.name=='pcctl' else 6), 'unexpected Mach-O file type'
        if path.name=='PowercuffRebuilt.dylib':
            assert '@loader_path/.jbroot/usr/lib/libsubstrate.dylib' in loads
            assert not any('/var/jb/' in x for x in loads)
        results.append({'subtype':hex(sub),'minimum':hex(minimum),'dependencies':loads,
                        'sha256':hashlib.sha256(b).hexdigest(),'signature':check_signature(b,*sig,load_plist((SOURCE/'ctl/entitlements.plist').read_bytes()) if path.name=='pcctl' else None)})
    return results

def verify(deb):
    source={k.lower():v for k,v in control_fields((SOURCE/'control').read_bytes()).items()}
    entries=members(deb.read_bytes());raw_control=None
    assert list(entries)==['debian-binary','control.tar.xz','data.tar.xz'], 'unexpected Debian member set/order'
    assert entries['debian-binary']==b'2.0\n', 'invalid Debian version'
    expected_files={
        'Library/MobileSubstrate/DynamicLibraries/PowercuffRebuilt.dylib':0o755,
        'Library/MobileSubstrate/DynamicLibraries/PowercuffRebuilt.plist':0o644,
        'Library/ControlCenter/Bundles/PowercuffCC.bundle/PowercuffCC':0o755,
        'Library/ControlCenter/Bundles/PowercuffCC.bundle/Info.plist':0o644,
        'Library/PreferenceLoader/Preferences/Powercuff/Powercuff.plist':0o644,
        'usr/bin/pcctl':0o755}
    control_files={'control':0o644,'postinst':0o755,'prerm':0o755}
    for key in ['control.tar.xz','data.tar.xz']:
        expected=control_files if key.startswith('control') else expected_files
        found=set();seen=set();allowed_dirs={'.'}
        for name in expected:
            allowed_dirs.update(str(p) for p in pathlib.PurePosixPath(name).parents)
        with open_tar(entries[key],key) as archive:
            for item in archive:
                assert item.uid==0 and item.gid==0, 'non-root numeric archive owner'
                assert item.isfile() or item.isdir(), 'unexpected archive member type'
                raw=item.name.removeprefix('./').rstrip('/') if item.isdir() else item.name.removeprefix('./')
                assert raw=='.' and item.isdir() or all(x not in ('','.','..') for x in raw.split('/')), 'noncanonical archive path'
                path=pathlib.PurePosixPath(item.name);name=str(path)
                assert not path.is_absolute() and '..' not in path.parts, 'unsafe archive path'
                assert name not in seen, 'duplicate normalized archive path'
                seen.add(name)
                if item.isdir(): assert name in allowed_dirs and item.mode==0o755, 'unexpected directory'
                else:
                    assert name in expected and item.mode==expected[name], 'unexpected file or permissions'
                    found.add(name)
                    if key.startswith('control') and name=='control':raw_control=archive.extractfile(item).read()
                    if key.startswith('control') and name!='control':
                        assert archive.extractfile(item).read()==(SOURCE/'layout/DEBIAN'/name).read_bytes(), 'maintainer script differs from source'
        assert found==set(expected), 'package file set differs' 
    fields=subprocess.check_output(['dpkg-deb','-f',str(deb)]).decode()
    assert 'Package: com.powercuff.roothide\n' in fields and ('Version: '+source['version']+'\n') in fields
    assert 'Architecture: iphoneos-arm64e\n' in fields
    actual={k.lower():v for k,v in control_fields(raw_control).items()}
    assert set(actual)-{'installed-size'}==set(source), 'unexpected control metadata'
    if 'installed-size' in actual:assert actual['installed-size'].isascii() and actual['installed-size'].isdecimal() and int(actual['installed-size'])>0, 'invalid Installed-Size'
    for key in ['depends','conflicts','replaces']:
        a=[x.strip() for x in actual[key].split(',')];b=[x.strip() for x in source[key].split(',')]
        assert len(a)==len(set(a)) and sorted(a)==sorted(b), 'dependency/conflict metadata differs from source'
    for key,value in source.items():
        if key not in ['depends','conflicts','replaces']: assert actual[key]==value, 'control metadata differs from source' 
    result={'package':deb.name,'sha256':hashlib.sha256(deb.read_bytes()).hexdigest(),'binaries':{}}
    with tempfile.TemporaryDirectory() as tmp:
        root=pathlib.Path(tmp);subprocess.run(['dpkg-deb','-x',str(deb),str(root)],check=True)
        for suffix in ['Library/MobileSubstrate/DynamicLibraries/PowercuffRebuilt.dylib',
                       'Library/ControlCenter/Bundles/PowercuffCC.bundle/PowercuffCC','usr/bin/pcctl']:
            matches=[p for p in root.rglob(pathlib.Path(suffix).name) if str(p).endswith(suffix)]
            assert len(matches)==1, f'missing or duplicate binary {suffix}'
            result['binaries'][suffix]=inspect(matches[0])
        filters=list(root.rglob('PowercuffRebuilt.plist'));assert len(filters)==1
        assert plist_equal(load_plist(filters[0].read_bytes()),{'Filter':{'Executables':['thermalmonitord','SpringBoard']}})
        infos=list(root.rglob('Info.plist'));assert len(infos)==1
        info=load_plist(infos[0].read_bytes());assert plist_equal(info,load_plist((SOURCE/'cc/Info.plist').read_bytes())), 'module Info.plist differs from source'
        assert info['CFBundleShortVersionString']==source['version']
        assert info['NSPrincipalClass']=='PowercuffCCModule'
        prefs=[p for p in root.rglob('Powercuff.plist') if 'PreferenceLoader' in p.parts];assert len(prefs)==1
        actual_prefs=load_plist(prefs[0].read_bytes())
        expected_prefs=load_plist((SOURCE/'layout/Library/PreferenceLoader/Preferences/Powercuff/Powercuff.plist').read_bytes())
        assert plist_equal(actual_prefs,expected_prefs), 'preferences differ from source'
        items=actual_prefs['items']
        mode=next(x for x in items if x.get('key')=='PowerMode')
        assert mode['validValues']==list(range(5)) and all(type(v) is int for v in mode['validValues'])
        assert type(mode['default']) is int and mode['default']==0
        gate=next(x for x in items if x.get('key')=='RequireLowPowerMode')
        assert type(gate['default']) is bool and gate['default'] is False
        keys={x['key'] for x in items if 'key' in x};assert keys=={'PowerMode','RequireLowPowerMode'}
        for x in items:
            if 'key' in x:assert x['defaults']=='com.dao.powercuff'
    return result
if __name__=='__main__':
    print(json.dumps(verify(pathlib.Path(sys.argv[1]).resolve()),ensure_ascii=False,indent=2))
