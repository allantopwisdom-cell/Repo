#!/usr/bin/env python3
"""Run maintainer scripts against a mocked pcctl, without installing anything."""
import os,pathlib,subprocess,tempfile
root=pathlib.Path(__file__).resolve().parents[1]
with tempfile.TemporaryDirectory() as tmp:
    d=pathlib.Path(tmp);tool=d/'pcctl';log=d/'calls'
    tool.write_text('#!/bin/sh\nprintf "%s\\n" "$*" >> "$MOCK_LOG"\nexit "$MOCK_EXIT"\n');tool.chmod(0o755)
    for action in ['remove','upgrade','deconfigure']:
        for code in ['0','3']:
            log.unlink(missing_ok=True)
            env={**os.environ,'PATH':tmp,'MOCK_LOG':str(log),'MOCK_EXIT':code}
            p=subprocess.run(['/bin/sh',str(root/'layout/DEBIAN/prerm'),action],env=env,capture_output=True,text=True,timeout=2)
            assert p.returncode==0 and log.read_text()=='disable\n'
            assert ('acknowledgement unavailable' in p.stderr)==(code!='0')
    log.unlink()
    p=subprocess.run(['/bin/sh',str(root/'layout/DEBIAN/prerm'),'remove'],env={**os.environ,'PATH':'/nonexistent'},capture_output=True,text=True,timeout=2)
    assert p.returncode==0 and 'tool unavailable' in p.stderr and not log.exists()
    for script,action in [('prerm','failed-upgrade'),('postinst','configure'),('postinst','abort-upgrade')]:
        p=subprocess.run(['/bin/sh',str(root/'layout/DEBIAN'/script),action],capture_output=True,text=True,timeout=2)
        assert p.returncode==0
print('Maintainer scripts: remove/upgrade/deconfigure, successful/failed/missing pcctl and ignored actions PASS')
