// GPLv3. Real preference I/O in a temporary directory, never the user's preferences.
#import <Foundation/Foundation.h>
#include <sys/file.h>
#include <fcntl.h>
#include <unistd.h>
#include <math.h>
static NSString *testDirectory;
NSString *VDTTestPath(NSString *name){return [testDirectory stringByAppendingPathComponent:name];}
#include "../VDTShared.mm"
static NSUInteger checks;
#define CHECK(expr) do{++checks;if(!(expr)){fprintf(stderr,"FAIL %s:%d %s\n",__FILE__,__LINE__,#expr);abort();}}while(0)
static void raw(NSDictionary *prefs){CHECK([prefs writeToFile:PREFS_PATH atomically:YES]);}
int main(void){@autoreleasepool{
 char temp[]="/tmp/vedette-prefs-XXXXXX";CHECK(mkdtemp(temp)!=NULL);testDirectory=[NSString stringWithUTF8String:temp];
 CHECK([valueForKey(@"enabled") isEqual:@NO]);CHECK([valueForKey(@"dryRun") isEqual:@YES]);
 CHECK(setValueForKey(@"enabled",@YES));CHECK([getPrefs()[@"enabled"] isEqual:@YES]);
 NSString *embedded=[NSString stringWithFormat:@"80%Cjunk",(unichar)0];int n=0;BOOL b=NO;
 NSArray *bad=@[@[],@{},NSNull.null,@YES,@80.0,@(NAN),@(INFINITY),embedded,@"80x",@"-1",@"999999999999999999999999"];
 for(id value in bad){CHECK(!VDTInteger(value,20,100,&n));CHECK(!setValueForProcessConfigKey(@"test.A",@"percentage",value,VDTConfigTypeApp));}
 CHECK(!VDTFlag(@1.0,&b));CHECK(VDTFlag(@YES,&b) && b);CHECK(VDTFlag(@"0",&b) && !b);
 CHECK(!VDTIdentifier(@"a/b"));CHECK(!VDTIdentifier(embedded));CHECK(!VDTAbsolutePath(@"/a/../b"));
 CHECK(!setValueForKey(@"enabled",@[]));CHECK([valueForKey(@"enabled") isEqual:@YES]);
 CHECK(!setValueForKey(@"unknown",@YES));CHECK(!setValueForProcessConfigKey(@"bad/name",@"enabled",@YES,VDTConfigTypeApp));
 CHECK(setValueForProcessConfigKey(@"test.A",@"percentage",@40,VDTConfigTypeApp));
 CHECK([valueForProcessConfigKey(@"test.A",@"percentage",nil,VDTConfigTypeApp) isEqual:@40]);
 NSDictionary *malformed=@{@"enabled":@[],@"dryRun":@{},@"appConfigs":@[@{@"bundleIdentifier":@"test.A",@"enabled":@[],@"percentage":@[]} ]};
 raw(malformed);CHECK([valueForKey(@"enabled") isEqual:@NO]);CHECK([valueForKey(@"dryRun") isEqual:@YES]);
 CHECK([valueForProcessConfigKey(@"test.A",@"enabled",@NO,VDTConfigTypeApp) isEqual:@NO]);
 CHECK([valueForProcessConfigKey(@"test.A",@"percentage",@80,VDTConfigTypeApp) isEqual:@80]);
 CHECK(!setValueForProcessConfigKey(@"exampled",@"enabled",@YES,VDTConfigTypeDaemon));
 CHECK(VDTSetProcessConfigValue(@"exampled",@"enabled",@YES,VDTConfigTypeDaemon,@"/usr/libexec/exampled"));
 CHECK([valueForProcessConfigKey(@"exampled",@"executablePath",nil,VDTConfigTypeDaemon) isEqual:@"/usr/libexec/exampled"]);
 CHECK(!VDTSetProcessConfigValue(@"thermalmonitord",@"enabled",@YES,VDTConfigTypeDaemon,@"/usr/libexec/thermalmonitord"));
 CHECK(!VDTSetProcessConfigValue(@"exampled",@"enabled",@YES,(VDTConfigType)99,@"/usr/libexec/exampled"));
 NSString *lock=[PREFS_PATH stringByAppendingString:@".lock"];int fd=open(lock.fileSystemRepresentation,O_RDWR);CHECK(fd>=0);CHECK(flock(fd,LOCK_EX|LOCK_NB)==0);
 NSDate *start=[NSDate date];CHECK(!setValueForKey(@"enabled",@YES));CHECK([[NSDate date] timeIntervalSinceDate:start]<5);flock(fd,LOCK_UN);close(fd);
 CHECK([[NSFileManager defaultManager] removeItemAtPath:lock error:NULL]);
 NSString *target=[testDirectory stringByAppendingPathComponent:@"sentinel"];CHECK([@"unchanged" writeToFile:target atomically:YES encoding:NSUTF8StringEncoding error:NULL]);
 CHECK([[NSFileManager defaultManager] createSymbolicLinkAtPath:lock withDestinationPath:target error:NULL]);CHECK(!setValueForKey(@"enabled",@YES));CHECK([[NSString stringWithContentsOfFile:target encoding:NSUTF8StringEncoding error:NULL] isEqual:@"unchanged"]);
 CHECK([[NSFileManager defaultManager] removeItemAtPath:lock error:NULL]);
 raw(@{@"appConfigs":@[@{@"bundleIdentifier":@"test.A",@"percentage":@20},@{@"bundleIdentifier":@"test.A",@"percentage":@90}]});
 CHECK([valueForProcessConfigKey(@"test.A",@"percentage",@80,VDTConfigTypeApp) isEqual:@80]);
 CHECK(setValueForProcessConfigKey(@"test.A",@"percentage",@50,VDTConfigTypeApp));CHECK([getPrefs()[@"appConfigs"] count]==1);
 CHECK(VDTResetPreferences());CHECK(![valueForKey(@"enabled") boolValue] && [valueForKey(@"dryRun") boolValue]);
 CHECK([@"" writeToFile:VDT_REMOVAL_PATH atomically:YES encoding:NSUTF8StringEncoding error:NULL]);CHECK(VDTRemovalRequested());CHECK(VDTCancelRemoval());CHECK(!VDTRemovalRequested());
 CHECK([NSMutableData dataWithLength:2*1024*1024] && [[NSMutableData dataWithLength:2*1024*1024] writeToFile:PREFS_PATH atomically:YES]);CHECK(getPrefs().count==0);
 [[NSFileManager defaultManager] removeItemAtPath:testDirectory error:NULL];
 printf("PASS: production preferences validation/I/O, %lu assertions\n",(unsigned long)checks);
}return 0;}
