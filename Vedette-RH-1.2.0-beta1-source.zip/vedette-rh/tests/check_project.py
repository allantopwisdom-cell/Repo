"""Artifact integrity checks only; does not substitute for an iOS build."""
from pathlib import Path
import plistlib
root=Path(__file__).resolve().parents[1]
for path in root.rglob('*.plist'):
    with path.open('rb') as f: plistlib.load(f)
filter=plistlib.loads((root/'Vedette.plist').read_bytes())
assert filter['Filter']=={'Executables':['runningboardd']}
assert 'killall' not in ''.join(p.read_text() for p in (root/'layout/DEBIAN').iterdir())
assert 'Xcode11' not in (root/'Makefile').read_text()
assert 'THEOS_PACKAGE_SCHEME = roothide' in (root/'Makefile').read_text()
assert not list(root.rglob('*.deb')), 'Do not mislabel an unbuilt source deliverable as a compiled package'
print('PASS: plist parsing, injection scope, packaging and script invariants')
