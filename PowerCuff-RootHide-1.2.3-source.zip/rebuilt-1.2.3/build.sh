#!/bin/sh
set -eu
cd "$(dirname "$0")"
: "${THEOS:?Set THEOS to RootHide Theos}"
export THEOS_PACKAGE_SCHEME=roothide
sh scripts/check.sh
make clean
make package DEBUG=0 FINALPACKAGE=1 messages=yes
package=packages/com.powercuff.roothide_1.2.3_iphoneos-arm64e.deb
test -f "$package"
python3 scripts/verify_package.py "$package" > packages/verification.json
cat packages/verification.json
