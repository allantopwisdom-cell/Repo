#include <assert.h>
#include <math.h>
#include <stdio.h>
#include "../Policy.h"
int main(void) {
    for (unsigned mode=0; mode<5; ++mode) {
        assert(PCModeFromDouble(mode)==mode);
        assert(PCEffectiveMode(mode,0,0)==mode);
        assert(PCEffectiveMode(mode,0,1)==mode);
        assert(PCEffectiveMode(mode,1,0)==0);
        assert(PCEffectiveMode(mode,1,1)==mode);
    }
    double invalid[]={-1,-0.5,0.5,3.9,4.1,5,1e100,INFINITY,-INFINITY,NAN};
    for (unsigned i=0;i<sizeof(invalid)/sizeof(*invalid);++i)
        assert(PCModeFromDouble(invalid[i])==0);
    assert(PCEffectiveMode(5,0,1)==0);
    assert(PCEffectiveMode(0xffffffffU,0,0)==0);
    puts("PASS: five modes, complete low-power truth table, invalid numeric boundaries");
}
