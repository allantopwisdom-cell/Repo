# Powercuff RootHide 1.0.0-8 rc1

这是基于 rpetrich/Powercuff 和 Mikasa-san/Powercuff 重建的验收候选版，**不是已完成真机验收的正式版**。目标设备为 iPhone 14 Pro Max、iOS 16.5、RootHide Dopamine 3.0.4。

## 源码来源
- https://github.com/rpetrich/Powercuff commit a97c445a4a8fd2ce1cfe9fbc16fdf82a930b62d1
- https://github.com/Mikasa-san/Powercuff commit 5397253bda51578b82dfbf7b804dd2839f48bfe7
两个项目均未提供明确的源码许可证文件，保留归属；公开可读不等于已获得任意再分发授权。

## 改动
- 保留上游五档映射、偏好域与配置键；默认关闭，不主动开启系统低电量模式。
- 恢复 SpringBoard 负责 mobile 用户偏好及低电状态、thermalmonitord 负责应用模拟状态的职责分工。
- 状态、事件、配置及请求通知使用独立 token；通知失败记录日志，避免错误 token 读写。
- 严格检查数字类型、整数范围和开关合法性；异常配置回退关闭。
- ARC 弱引用集合跟踪产品，应用时取得强引用，避免悬空产品指针并支持多个活跃实例。
- 对 CommonProduct 初始化与模拟接口检查方法存在性、返回值和参数 ABI；不匹配时不安装 hook。
- 初始化、状态事件都在主队列更新集合和应用；缓存已应用档位，避免同档重复调用。设备上仍需验证这一队列选择符合私有实现要求。
- daemon 启动请求 SpringBoard 重发状态，系统低电模式切换使用公开通知。
- 安装脚本仅 configure 生效；卸载脚本仅 remove/purge 生效。改用 TERM，避免无条件 SIGKILL。

## 功能与限制
档位：0 off、1 nominal、2 light、3 moderate、4 heavy。模拟热状态不等同于固定 CPU 频率，不能承诺续航增幅。仅低电模式开关开启时，退出系统低电模式会发布 off。

此版相比上传包重新启用 SpringBoard 注入，需要重启 SpringBoard 才能载入；安装会请求服务重启。没有控制中心独立模块，设置入口使用 PreferenceLoader。不会复刻上传二进制中来源不明的 GPProduct/定时轮询逻辑。

若系统类不存在、ABI 不符、通知注册失败，功能可能保持关闭并输出日志。Objective-C 异常后停止继续应用，已应用状态可能残留，需停用插件并重启 thermalmonitord；不能把这一处理视为消除了所有崩溃风险。C++/内存访问异常不由该异常捕获处理。

## 构建
macOS + RootHide Theos + iOS16.5 SDK + ldid/dpkg；执行 `sh tests/check.sh`，然后 `make clean package FINALPACKAGE=1`。Actions 固定 Theos 与 SDK 提交，输出 DEB、源码提交、构建环境、SHA256 及校验日志。

与原上传包使用同一包标识，可升级替换；版本 1.0.0-8~rc1 高于 1.0.0-7。卸载不会删除用户偏好。其它 Powercuff 包先移除，Hello CPU 等调度插件先停用以便单独验收。

## 真机验收清单（未执行）
1. 安装后检查 thermalmonitord/SpringBoard 无连续崩溃、watchdog 或安全模式；不符合立即移除并重启用户空间。
2. 逐档切换，并依据 daemon 实际状态/日志而不是 UI 选择判断效果；回到 off 后确认恢复。
3. 仅低电模式开关四种组合，系统低电模式快速切换与锁屏/解锁。
4. 重启 daemon、SpringBoard、设备及重越狱后配置和状态一致。
5. 快速切档、产品对象销毁重建、多实例、异常参数及未安装依赖场景。
6. 升级、卸载、清除及中断恢复，确认旧注入已卸载和模拟状态恢复。
7. 分别测试 Hello CPU/Hello Memory Status 等组合，检查相互覆盖。
8. 充电、通话、相机和高负载场景检查稳定性与真实温控保护。功耗使用固定负载对照测量。

本地 C 测试只验证模式策略与边界，不能替代 iOS API、注入、RootHide 路径、对象线程与实际温控的真机测试。
