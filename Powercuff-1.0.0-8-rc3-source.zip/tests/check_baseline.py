import resource,subprocess,sys
resource.setrlimit(resource.RLIMIT_CORE,(0,0))
r=subprocess.run([sys.argv[1]],capture_output=True,text=True)
assert r.returncode!=0, 'rc2 baseline unexpectedly passed new cache regression'
assert 'unsignedIntValue' in r.stderr and '==3' in r.stderr, r.stderr
print('PASS: unchanged rc2 apply baseline reproduces the reentrant cache defect; rc3 positive case passed')
