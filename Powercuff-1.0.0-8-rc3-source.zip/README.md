# Powercuff 1.0.0-8 rc3 — 验收候选版

目标：iPhone 14 Pro Max / iOS16.5（20F66）/ RootHide Dopamine3.0.4。
基线：rc2源码27f19bb90e0b20f33823f3a8dce402cdaff3cacf，DEB SHA256 3edce26f4f127c44ef389b9d69ba1222551c8117b3041c92920e3ad9c72254db。
上游来源：rpetrich/Powercuff a97c445a4a8fd2ce1cfe9fbc16fdf82a930b62d1；Mikasa-san/Powercuff 5397253bda51578b82dfbf7b804dd2839f48bfe7（用户原列表有一个重复链接）。保留作者归属。

## 本轮缺陷与修复
| 项目 | rc2问题 | rc3处理 |
| --- | --- | --- |
| 调用期间状态改变 | 原调用传旧档位，却用调用后的全局session.mode更新缓存和报告；可导致后续新档位被错误去重 | 固定当前会话/档位快照；实际传参和缓存一致；状态改变后停止旧循环并延后处理 |
| 重入调用 | 在私有方法中重入PCApply可能递归调用同一对象、打乱应用顺序 | applying/applyPending门控，最多排队一次最新处理，@finally确保门控释放 |
| 实际返回对象 | 每次应用还要求返回对象具有initProduct，拒绝仅具有效模拟方法的合法替换对象 | 分离初始化ABI与应用ABI；hook安装前检查两者，实际调用只核验应用方法 |
| 通知到达后短暂读取失败 | 一旦会话曾成功，原会话重试不再执行，后续响应事件读失败缺乏恢复 | 响应事件立即读取并在50/200/600ms有限重读；新事件/新会话/停用使旧任务失效；耗尽报告12 |

## 保留的行为与参数
仅注入SpringBoard和thermalmonitord，不注入App/Widget/Settings。
PowerMode默认0，非布尔NSNumber整数0..4分别为off/nominal/light/moderate/heavy；非法类型、非整数、NaN/无穷和越界回退off。
RequireLowPowerMode默认false，只接受布尔或数值0/1；开启且系统低电模式关闭时请求off，不修改保存档位。同步失败或非法开关回退off。
偏好域com.rpetrich.powercuff，设置通知com.rpetrich.powercuff.settingschanged。配置/LPM立即及150/600ms有限重读。
通信使用v2标记和40位非零随机会话，旧裸档位/旧会话拒绝。每个新会话最多4次请求和一次最终读取，不持续轮询。
弱引用对象按指针身份维护；方法异常/ABI错误按对象隔离；重新初始化使该对象应用缓存失效。
包after-package规范化数值owner为0/0，并要求所有文件内容和权限不变；包验证保持源码对照、PAC00和签名代码页检查。

## 回归与证据
- C生产策略/会话协议，非法参数与陈旧回复。
- macOS真实Foundation类型、初始化/应用ABI，包含仅具模拟方法的替换类。
- 提取实际PCApply执行：对象身份/去重/异常隔离/弱生命周期/空对象状态，以及模式改变、嵌套调用、调用期间新会话等待、off恢复和替换对象。
- 保留未修改rc2的PCApply作为反例，在相同fixture上必须复现缓存断言失败；当前生产实现必须通过。
- 提取实际响应读取函数，模拟通知读取失败：首次成功后短暂失败仍可恢复off、有限耗尽、旧会话/失效回调和停用后回调。
- 维护脚本84组阶段/域/失败组合（launchctl模拟），全部plist参数核查，实际新包源码对照和篡改反例。
主机fixture中的私有方法、通知、定时器边界均为模拟；不能冒充真机Apple服务运行。

## 状态与安装
v2.status：高16位0x5053，中40位会话，低8位状态。0..4=对应方法曾返回；10=等待；11=请求耗尽；12=后续响应刷新失败；98=对象异常；99=ABI不符。残留值不证明服务存活或真实节流。
同一包标识com.baldaran.powercuff-r3vamp，rc3高于rc2。安装/升级后手动注销；daemon重载不确定时使用越狱应用重启用户空间。卸载保留偏好。
无控制中心独立模块、CPU固定频率、后台冻结或强制低电功能。

## 验收边界
本版仍需iPhone15,3/iOS16.5/RootHide3.0.4真机确认：注入/偏好路径、私有对象与主队列要求、PAC、逐档与LPM生效、热保护恢复、重启升级卸载和watchdog。
有限通信全部失败后可保留旧模拟；异常对象停止调用也可能保留旧状态。Objective-C异常不能捕获SIGBUS/SIGSEGV/watchdog；随机nonce不是恶意代码认证。
与Hello CPU/Hello Memory Status联用、续航收益与流畅度必须实测。首次停用其它热控插件，从off→light→off开始。
没有设备证据时只能交付构建/静态与主机回归候选版，不能声明全部功能实际生效或无已知运行风险。
