"""Execute real maintainer scripts with only fixed paths redirected to a temporary root."""
from pathlib import Path
import subprocess,tempfile
root=Path(__file__).resolve().parents[1]
with tempfile.TemporaryDirectory() as tmp:
    base=Path(tmp); marker=base/'com.udevs.vedette.removing'; journal=base/'com.udevs.vedette.runtime.plist'; checks=0
    def run(script,arg,expected):
        global checks
        text=(root/'layout/DEBIAN'/script).read_text().replace('/var/mobile/Library/Preferences',tmp)
        result=subprocess.run(['sh','-s','--',arg],input=text,text=True,capture_output=True)
        assert result.returncode==expected,(script,arg,result.stderr); checks+=1
    run('prerm','upgrade',0); assert not marker.exists()
    journal.write_text('pending');run('prerm','remove',1);assert marker.is_file()
    journal.unlink();run('prerm','remove',0);assert marker.is_file()
    run('postinst','abort-remove',0);assert marker.exists()
    run('postinst','configure',0);assert not marker.exists()
    journal.symlink_to(base/'absent');run('prerm','remove',1);journal.unlink()
    run('postrm','remove',0);assert marker.exists()
    marker.unlink();target=base/'target';target.write_text('untouched');marker.symlink_to(target)
    run('prerm','remove',1);assert target.read_text()=='untouched'
    print(f'PASS: {checks} maintainer lifecycle scenarios (remove/upgrade/abort/symlinks)')
