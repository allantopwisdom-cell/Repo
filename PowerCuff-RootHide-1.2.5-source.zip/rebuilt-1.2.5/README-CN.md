# PowerCuff RootHide Rebuilt 1.2.5

目标：iPhone14 Pro Max / iPhone15,3 / A16 / iOS16.5 / RootHide Dopamine3.0.4。工程根据旧包功能逆向及用户已有工程重建，不是原作者源码逐字恢复。

本版在1.2.4上循环审查：修复故障记录被控制中心隐藏、缺少查询结束状态的问题；严格解析归档、Mach-O、plist、控制元数据及XML/DER权限；诊断工具移除未使用的两项存储权限。保留五档热模拟、LPM门控、原生控制中心和有限关闭握手，不改变既有档位强度。

## 构建

只接受macOS和Apple Xcode clang；三个生产目标由PCRBuildGuard.h强制检查arm64e及ptrauth特性。建议macOS15/Xcode16.4。
Theos固定cfba89a53a05b4a1b822121158acc3669c20602f；theos/sdks固定0222fd5413cf4b9af096f37b4621afa2688572f7，iPhoneOS16.5.sdk，最低部署iOS16.0。

```sh
export THEOS=/absolute/path/to/roothide-theos
export SOURCE_DATE_EPOCH=1793700000
sh build.sh
```

build.sh运行实际共享协议/UI、Python格式解析、维护脚本、Foundation偏好、运行时ABI、生产核心和诊断工具主函数测试，再完整编译三个目标、ldid签名、规范化UID/GID、验证实际DEB并执行18类负向变异。任一失败均不得安装失败构建遗留的包。成功产物：packages/com.powercuff.roothide_1.2.5_iphoneos-arm64e.deb。

SOURCE-SHA256.json是本次构建输入清单；最终构建状态以对应提交的BUILD-LOG.txt、verification.json、negative-tests.txt和外部交付报告为准，不在静态源码文档中预先声称CI或设备通过。

## 配置

持久偏好域com.dao.powercuff。PowerMode只接受NSNumber整数0..4，默认0；RequireLowPowerMode默认关闭，启用时系统真实LPM关闭会请求有效档位0但保留所选档位。异常类型/范围回退关闭。已有偏好会沿用，升级不会强制清空。

0/off关闭模拟；1/nominal正常但仍在模拟；2/light轻度；3/moderate适中；4/heavy重度。没有固定CPU频率、充电限流、A16频率表或独立后台冻结。接口已返回不代表实际频率或节能收益。

## 设备验证

首次单独验收停用Hello CPU等热管理插件，备份偏好并卸载冲突Powercuff变种。安装后通过越狱应用重启用户空间，不能把单独respring视为thermalmonitord已重载证明。先关闭→轻度→关闭，再测试五档、设置/控制中心互改、LPM、休眠唤醒和升级卸载。

控制中心“异常/不兼容记录”是缓存诊断，不证明后台当前存活；确认窗口结束但没有新应答会明确提示未完成，迟到的匹配新应答仍可恢复显示。通知注册失败不会继续伪装等待。

pcctl status是稳定读取的会话快照，不是心跳：成功状态0..4退出0，无匹配确认退出3，已报告失败退出4。pcctl disable以随机nonce确认关闭，最多约3秒；该进程会话关闭后需用户空间重启恢复。安装脚本不强杀thermalmonitord。Objective-C异常捕获不能捕捉SIGBUS/SIGSEGV/PAC或watchdog。真实私有API、RootHide加载、稳定性和续航必须由设备验收。
