#!/usr/bin/env python3
"""Negative tests mutate a real signed package; never execute its binaries or scripts."""
import hashlib,io,lzma,pathlib,struct,sys,tarfile,tempfile
from normalize_package import members
from verify_package import verify

def write_deb(path,entries):
    data=bytearray(b'!<arch>\n')
    for name,blob in entries.items():
        data+=f'{name+"/":<16}{0:<12}{0:<6}{0:<6}{"100644":<8}{len(blob):<10}`\n'.encode()+blob
        if len(blob)%2:data+=b'\n'
    path.write_bytes(data)
def mutate_tar(blob,change):
    output=io.BytesIO()
    with tarfile.open(fileobj=io.BytesIO(blob),mode='r:*') as source,tarfile.open(fileobj=output,mode='w',format=tarfile.USTAR_FORMAT) as target:
        for item in source:
            data=source.extractfile(item).read() if item.isfile() else None
            data=change(item,data)
            if item.isfile():item.size=len(data)
            target.addfile(item,io.BytesIO(data) if data is not None else None)
    return lzma.compress(output.getvalue(),format=lzma.FORMAT_XZ)
def signature_location(b):
    pos=32
    for _ in range(struct.unpack_from('<I',b,16)[0]):
        c,z=struct.unpack_from('<II',b,pos)
        if c==0x1d:return struct.unpack_from('<II',b,pos+8)
        pos+=z
    raise AssertionError('signature not found')
def damage_signature(b,slot):
    b=bytearray(b);off,size=signature_location(b);count=struct.unpack_from('>I',b,off+8)[0]
    for j in range(count):
        current,start=struct.unpack_from('>II',b,off+12+8*j)
        if current==slot:
            n=struct.unpack_from('>I',b,off+start+4)[0]
            b[off+start+n-1]^=1;return bytes(b)
    raise AssertionError('expected signature slot missing')
def change_der_policy(b):
    b=bytearray(damage_signature(b,7));off,size=signature_location(b)
    blobs={}
    for j in range(struct.unpack_from('>I',b,off+8)[0]):
        slot,start=struct.unpack_from('>II',b,off+12+8*j);n=struct.unpack_from('>I',b,off+start+4)[0]
        blobs[slot]=(off+start,n)
    start,n=blobs[7];payload=b[start:start+n]
    for slot,(start,n) in blobs.items():
        if slot==0 or 0x1000<=slot<0x1005:
            hash_offset=struct.unpack_from('>I',b,start+16)[0];hash_size,kind=struct.unpack_from('>BB',b,start+36)
            algorithm={1:'sha1',2:'sha256'}[kind]
            at=start+hash_offset-7*hash_size;b[at:at+hash_size]=hashlib.new(algorithm,payload).digest()[:hash_size]
    return bytes(b)
def run(path):
    verify(path);original=members(path.read_bytes())
    scenarios=[('owner','data.tar.xz','non-root numeric'),('mode','data.tar.xz','permissions'),
       ('requirements','data.tar.xz','special slot'),('entitlements','data.tar.xz','special slot'),
       ('script','control.tar.xz','maintainer script'),('conflict','control.tar.xz','metadata differs'),
       ('module-version','data.tar.xz','Info.plist differs'),
       ('compression-trailer','data.tar.xz','compression trailer'),('tar-trailer','data.tar.xz','tar end'),
       ('macho-trailer','data.tar.xz','signature bounds/trailer'),('duplicate-plist','data.tar.xz','duplicate/invalid plist'),
       ('plist-types','data.tar.xz','Info.plist differs'),('extra-control','control.tar.xz','unexpected control metadata'),
       ('path-alias','data.tar.xz','noncanonical archive path'),('debian-version','data.tar.xz','invalid Debian version'),
       ('der-policy','data.tar.xz','DER entitlement policy'),('tar-no-eof','data.tar.xz','tar end'),('extra-ar','data.tar.xz','Debian member')]
    with tempfile.TemporaryDirectory() as tmp:
        for label,archive,reason in scenarios:
            changed=[False]
            def change(item,data):
                name=str(pathlib.PurePosixPath(item.name))
                if label=='owner':item.gid=20;changed[0]=True
                if label=='mode' and name.endswith('PowercuffRebuilt.dylib'):item.mode=0o644;changed[0]=True
                if label=='requirements' and name.endswith('PowercuffRebuilt.dylib'):data=damage_signature(data,2);changed[0]=True
                if label=='entitlements' and name=='usr/bin/pcctl':data=damage_signature(data,7);changed[0]=True
                if label=='der-policy' and name=='usr/bin/pcctl':data=change_der_policy(data);changed[0]=True
                if label=='script' and name=='prerm':data+=b'\nexit 0\n';changed[0]=True
                if label=='conflict' and name=='control':data=data.replace(b'com.baldaran.powercuff-r3vamp, ',b'');changed[0]=True
                if label=='module-version' and name.endswith('/Info.plist'):
                    import plistlib
                    obj=plistlib.loads(data);obj['CFBundleShortVersionString']='9.9.9';data=plistlib.dumps(obj);changed[0]=True
                if name.endswith('PowercuffRebuilt.dylib'):
                    if label=='macho-trailer':data+=bytes(64);changed[0]=True
                    if label=='path-alias':item.name=item.name.replace('Library/','Library//',1);changed[0]=True
                if name.endswith('/Info.plist') and label in ['duplicate-plist','plist-types']:
                    import plistlib
                    obj=plistlib.loads(data)
                    if label=='plist-types':obj['CCSGetModuleSizeAtRuntime']=0
                    data=plistlib.dumps(obj)
                    if label=='duplicate-plist':data=data.replace(b'<dict>',b'<dict><key>CFBundleVersion</key><string>999</string>',1)
                    changed[0]=True
                if label=='extra-control' and name=='control':data+=b'Unexpected-Policy: enabled\n';changed[0]=True
                return data
            entries=dict(original);entries[archive]=mutate_tar(entries[archive],change)
            if label=='compression-trailer':entries[archive]+=b'UNVERIFIED';changed[0]=True
            if label=='tar-trailer':entries[archive]=lzma.compress(lzma.decompress(entries[archive])+b'UNVERIFIED'+bytes(502));changed[0]=True
            if label=='tar-no-eof':
                raw=lzma.decompress(entries[archive])
                with tarfile.open(fileobj=io.BytesIO(raw),mode='r:') as t:t.getmembers();end=t.offset
                entries[archive]=lzma.compress(raw[:end]);changed[0]=True
            if label=='debian-version':entries['debian-binary']=b'9.9\n';changed[0]=True
            if label=='extra-ar':entries['extra']=b'UNVERIFIED';changed[0]=True
            assert changed[0]
            damaged=pathlib.Path(tmp)/'negative.deb';write_deb(damaged,entries)
            try:verify(damaged)
            except AssertionError as e:assert reason in str(e),f'{label}: unrelated failure {e}'
            else:raise AssertionError('accepted '+label)
            print('Actual DEB negative test:',label,'rejected PASS')
if __name__=='__main__':run(pathlib.Path(sys.argv[1]).resolve())
