# Vedette RH 1.2.0~beta2 验证范围

基线：beta1 已成功构建的源码提交 cc716914f6e217b2f2e5492c7e03ec8c3cdf9335。

本轮确认并修复：启动恢复失败后过早解除恢复状态；清理写回失败后可能误保留 active 状态；PID 枚举失败跳过已知策略清理；PID 被关键服务复用后过期记录无法退出。

新增 macOS Foundation 故障注入直接包含生产管理器源码，覆盖反序 PID 参数绑定、未运行目标、关闭、规则移除、策略切换、重启后清理失败与再次尝试、枚举失败、PID 被关键服务复用、恢复日志写入失败、monitor defaults 恢复失败、dry-run 切换。系统调用均为 mock，文件仅写独立临时目录。

当前 Linux 可执行的 105 项纯 C 断言与 plist/脚本检查通过。Objective-C 管理器测试需在 macOS Actions 执行，实际测试数量与 iOS 全量构建结果以对应提交产物的 vedette-tests.txt、vedette-build.txt 和 BUILD_RESULT.txt 为准。未连接真机，未验证 iOS API 权限、PAC 实际执行、恢复行为或续航。

包采用 arm64e；维护脚本与数据归档数值属主强制为 0/0。主工程和偏好面板均固定 iPhoneOS16.5 SDK。仍默认关闭、dry-run 开启，仍只向 runningboardd 注入。

## 继续保留的限制

CPU monitor 清理恢复系统默认值，不能重建其他组件的自定义限制。PID 型接口仍有检查与调用之间的竞态。原子文件替换不等于突然断电时的 fsync 保证。日志损坏时保留现场并阻止新策略。每 30 秒发现 PID，短命进程可能错过。不宣称设备稳定性或省电幅度已验证。
