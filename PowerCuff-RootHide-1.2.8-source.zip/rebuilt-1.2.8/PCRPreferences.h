#import <Foundation/Foundation.h>
#import <CoreFoundation/CoreFoundation.h>
// Read one persistent-domain snapshot. objectForKey: also searches unrelated domains.
static inline NSDictionary *PCRPreferenceSnapshot(NSUserDefaults *defaults, NSString *domain) {
    return [[defaults persistentDomainForName:domain] copy];
}
// Same parser is compiled into SpringBoard and the CC module.
// Numeric strings are deliberately rejected consistently; normal UI writes NSNumber.
static inline NSInteger PCRSelectedMode(id raw) {
    if (![raw isKindOfClass:NSNumber.class] ||
        CFGetTypeID((__bridge CFTypeRef)raw) == CFBooleanGetTypeID()) return 0;
    double n = [raw doubleValue];
    return (n >= 0 && n <= 4 && n == (double)[raw integerValue]) ? [raw integerValue] : 0;
}
// Pure preference parsing, shared by the tweak and macOS Foundation regression tests.
static inline NSInteger PCRValidatedMode(id raw, id gate, BOOL lowPower) {
    if (![raw isKindOfClass:NSNumber.class] ||
        CFGetTypeID((__bridge CFTypeRef)raw) == CFBooleanGetTypeID()) return 0;
    double number = [raw doubleValue];
    if (!(number >= 0 && number <= 4) || number != (double)[raw integerValue]) return 0;
    if (gate) {
        if (![gate isKindOfClass:NSNumber.class]) return 0;
        double flag = [gate doubleValue];
        if (flag != 0 && flag != 1) return 0;
        if (flag == 1 && !lowPower) return 0;
    }
    return [raw integerValue];
}

// Called only by the Control Center writer. Preserve LPM and unrelated preference keys.
static inline BOOL PCRSaveControlCenterMode(NSUserDefaults *defaults, NSString *domain, NSInteger mode) {
    if (mode<0 || mode>4) return NO;
    NSDictionary *snapshot=PCRPreferenceSnapshot(defaults, domain);
    NSInteger previous=PCRSelectedMode(snapshot[@"PowerMode"]);
    NSInteger remembered=mode>0 ? mode : previous;
    if (remembered>0) [defaults setObject:@(remembered) forKey:@"LastEnabledMode"];
    [defaults setObject:@(mode) forKey:@"PowerMode"];
    return [defaults synchronize];
}
