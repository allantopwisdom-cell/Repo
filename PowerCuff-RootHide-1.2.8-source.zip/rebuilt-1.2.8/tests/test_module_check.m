#import "../ctl/PCModuleCheck.h"
#include <assert.h>
int main(void) {
    @autoreleasepool {
        NSString *root=[NSTemporaryDirectory() stringByAppendingPathComponent:NSUUID.UUID.UUIDString];
        NSFileManager *fm=NSFileManager.defaultManager;
        NSString *path=[root stringByAppendingPathComponent:@"Library/ControlCenter/Bundles/PowercuffCC.bundle"];
        NSString *base=[root stringByAppendingPathComponent:@"Library/MobileSubstrate/DynamicLibraries/CCSupport"];
        assert([fm createDirectoryAtPath:path withIntermediateDirectories:YES attributes:nil error:nil]);
        assert([fm createDirectoryAtPath:base.stringByDeletingLastPathComponent withIntermediateDirectories:YES attributes:nil error:nil]);
        NSMutableDictionary *info=[@{@"CFBundleIdentifier":@"com.dao.powercuff.ccmodule",@"CFBundleExecutable":@"PowercuffCC",
           @"NSPrincipalClass":@"PowercuffCCModule",@"CFBundlePackageType":@"BNDL",@"MinimumOSVersion":@"16.0",
           @"CFBundleVersion":@"128",@"CFBundleShortVersionString":@"1.2.8",@"UIDeviceFamily":@[@1,@2]} mutableCopy];
        NSString *ip=[path stringByAppendingPathComponent:@"Info.plist"],*ep=[path stringByAppendingPathComponent:@"PowercuffCC"];
        NSData *bytes=[@"non executable fixture; preflight is injected" dataUsingEncoding:NSUTF8StringEncoding];
        assert([bytes writeToFile:ep atomically:YES]);assert([fm setAttributes:@{NSFilePosixPermissions:@0755} ofItemAtPath:ep error:nil]);
        assert([bytes writeToFile:[base stringByAppendingString:@".dylib"] atomically:YES]);
        NSDictionary *filter=@{@"Filter":@{@"Bundles":@[@"com.apple.springboard",@"com.apple.Preferences"]}};
        assert([filter writeToFile:[base stringByAppendingString:@".plist"] atomically:YES]);
        __block unsigned calls=0;
        BOOL (^ok)(NSBundle *,NSError **)=^BOOL(NSBundle *bundle,NSError **error){(void)error;assert(bundle);++calls;return YES;};
        @try {
            assert([info writeToFile:ip atomically:YES]);NSData *before=[NSData dataWithContentsOfFile:ip];
            NSDictionary *report=PCModuleReport(path,ok);
            assert([report[@"issues"] count]==0 && [report[@"preflight"] isEqual:@"passed"] && calls==1);
            assert(![report[@"runtime_verified"] boolValue] && ![report[@"injection_verified"] boolValue]);
            assert([[NSData dataWithContentsOfFile:ip] isEqual:before] && [[NSData dataWithContentsOfFile:ep] isEqual:bytes]);
            puts("Module diagnostic: valid metadata, resolved path, support files and read-only report PASS");
            report=PCModuleReport(path,^BOOL(NSBundle *bundle,NSError **error){(void)bundle;*error=[NSError errorWithDomain:@"Fixture" code:42 userInfo:@{NSLocalizedDescriptionKey:@"unloadable fixture"}];return NO;});
            assert([report[@"preflight"] isEqual:@"failed"] && [report[@"preflight_error_code"] intValue]==42 && [report[@"issues"] count]>0);
            puts("Module diagnostic: preflight failure preserves domain/code/text without loading code PASS");
            unsigned count=calls;
            for (id value in @[@[@YES,@2],@[@1],@"1,2",NSNull.null]) {
                info[@"UIDeviceFamily"]=value;assert([info writeToFile:ip atomically:YES]);
                report=PCModuleReport(path,ok);assert([report[@"issues"] count]>0 && [report[@"preflight"] isEqual:@"skipped"]);
            }
            info[@"UIDeviceFamily"]=@[@1,@2];info[@"NSPrincipalClass"]=@"Wrong";assert([info writeToFile:ip atomically:YES]);
            report=PCModuleReport(path,ok);assert([report[@"issues"] count]>0 && calls==count);
            info[@"NSPrincipalClass"]=@"PowercuffCCModule";assert([info writeToFile:ip atomically:YES]);
            assert([fm setAttributes:@{NSFilePosixPermissions:@0644} ofItemAtPath:ep error:nil]);
            report=PCModuleReport(path,ok);assert(![report[@"executable_accessible"] boolValue] && calls==count);
            puts("Module diagnostic: malformed family, wrong entry and missing executable permission block preflight PASS");
            assert([fm setAttributes:@{NSFilePosixPermissions:@0755} ofItemAtPath:ep error:nil]);
            assert([@{@"Filter":@[]} writeToFile:[base stringByAppendingString:@".plist"] atomically:YES]);
            report=PCModuleReport(path,ok);assert(![report[@"ccsupport_expected_filter"] boolValue] && [report[@"issues"] count]>0);
            assert([fm removeItemAtPath:[base stringByAppendingString:@".dylib"] error:nil]);
            report=PCModuleReport(path,ok);assert(![report[@"ccsupport_dylib_exists"] boolValue] && calls==count);
            report=PCModuleReport(@"relative",ok);assert([report[@"issues"] count]>0);
            report=PCModuleReport([root stringByAppendingPathComponent:@"missing.bundle"],ok);assert([report[@"issues"] count]>0);
            assert(PCPrintModuleCheck(@"relative")==3);
            puts("Module diagnostic: missing support, invalid filter/path and CLI failure status remain explicit PASS");
        } @finally { [fm removeItemAtPath:root error:nil]; }
    }
}
