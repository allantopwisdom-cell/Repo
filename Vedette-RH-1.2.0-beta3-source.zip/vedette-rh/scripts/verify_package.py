"""Independent DEB payload, source/script equality and Mach-O integrity validation."""
import io,json,plistlib,subprocess,sys,tarfile,tempfile
from pathlib import Path,PurePosixPath
from inspect_binary import inspect
root=Path(__file__).resolve().parents[1]
def verify(package):
    source_control=dict(line.split(': ',1) for line in (root/'control').read_text().splitlines() if ': ' in line)
    control=subprocess.check_output(['dpkg-deb','-f',str(package)],text=True)
    fields=dict(line.split(': ',1) for line in control.splitlines() if ': ' in line)
    for key in ('Package','Version','Architecture','Depends','Conflicts'):assert fields[key]==source_control[key],key
    archives={}
    for kind,option in [('control','--ctrl-tarfile'),('data','--fsys-tarfile')]:
        raw=subprocess.check_output(['dpkg-deb',option,str(package)])
        with tarfile.open(fileobj=io.BytesIO(raw)) as archive:
            entries={}
            for m in archive:
                name=m.name.removeprefix('./').rstrip('/')
                assert not name.startswith('/') and '..' not in PurePosixPath(name).parts,name
                assert name not in entries,('duplicate',name)
                assert m.uid==m.gid==0 and not m.mode&0o6022,(name,m.uid,m.gid,oct(m.mode))
                assert m.isdir() or m.isfile(),('unexpected link/type',name)
                entries[name]=(m,archive.extractfile(m).read() if m.isfile() else None)
            archives[kind]=entries
    for name in ('postinst','postrm','prerm'):
        m,data=archives['control'][name];assert m.mode&0o111
        assert data==(root/'layout/DEBIAN'/name).read_bytes(),('script differs',name)
    data=archives['data']; files={k:v for k,v in data.items() if v[0].isfile()}
    main='Library/MobileSubstrate/DynamicLibraries/Vedette.dylib'
    bundle='Library/PreferenceBundles/VedettePrefs.bundle/'
    expected={main,main.replace('.dylib','.plist'),bundle+'VedettePrefs',bundle+'Info.plist','Library/PreferenceLoader/Preferences/VedettePrefs.plist'}
    assert set(files)==expected,('unexpected/missing payload',set(files)^expected)
    for packaged,source in [(main.replace('.dylib','.plist'),'Vedette.plist'),('Library/PreferenceLoader/Preferences/VedettePrefs.plist','vedetteprefs/layout/Library/PreferenceLoader/Preferences/VedettePrefs.plist')]:
        assert plistlib.loads(files[packaged][1])==plistlib.loads((root/source).read_bytes()),packaged
    info=plistlib.loads(files[bundle+'Info.plist'][1]);original=plistlib.loads((root/'vedetteprefs/Resources/Info.plist').read_bytes())
    for key in ('CFBundleIdentifier','CFBundleExecutable','CFBundleVersion','CFBundleShortVersionString'):assert info[key]==original[key],key
    reports=[]
    with tempfile.TemporaryDirectory() as temp:
        for name in (main,bundle+'VedettePrefs'):
            p=Path(temp)/Path(name).name;p.write_bytes(files[name][1]);report=inspect(p);report['file']=name
            assert not any('/Users/' in d or '/workspace/' in d for d in report['dependencies'])
            assert any('libroothide.dylib' in d for d in report['dependencies'])
            reports.append(report)
    print(json.dumps({'package':fields['Package'],'version':fields['Version'],'payload_files':len(files),'binaries':reports},indent=2))
    print('PASS: exact source metadata/scripts/plists, payload allowlist, archive permissions, arm64e and code-page hashes')
if __name__=='__main__':verify(Path(sys.argv[1]))
