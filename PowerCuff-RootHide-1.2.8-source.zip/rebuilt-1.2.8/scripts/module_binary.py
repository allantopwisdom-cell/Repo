"""Check that the declared module classes are defined exports, not just text/undefined imports.
This is a static linkage guard, not an Objective-C runtime or device load test.
"""
import struct
EXPECTED=('PowercuffCCModule','PowercuffCCModuleViewController')
def validate_module_exports(data):
    assert len(data)>=32 and data[:4]==b'\xcf\xfa\xed\xfe','module Mach-O header'
    commands,size=struct.unpack_from('<II',data,16)
    end=32+size;assert end<=len(data),'module load commands'
    pos=32;table=None;sections=[]
    for _ in range(commands):
        assert pos+8<=end,'module command header'
        kind,length=struct.unpack_from('<II',data,pos)
        assert length>=8 and pos+length<=end,'module command bounds'
        if kind==2:
            assert table is None and length==24,'module symbol table command'
            table=struct.unpack_from('<4I',data,pos+8)
        if kind==0x19:
            assert length>=72,'module segment header'
            count=struct.unpack_from('<I',data,pos+64)[0]
            assert length==72+80*count,'module section table bounds'
            for i in range(count):
                at=pos+72+80*i
                name=data[at:at+16].split(b'\0')[0]
                address,n=struct.unpack_from('<QQ',data,at+32)
                sections.append((name,address,n))
        pos+=length
    assert pos==end and table is not None,'module symbol table missing'
    offset,count,strings,strings_size=table
    assert count<=100000 and offset+16*count<=len(data) and strings_size>0 and strings+strings_size<=len(data),'module symbol table bounds'
    found=set()
    for i in range(count):
        name_offset,kind,section,description,address=struct.unpack_from('<IBBHQ',data,offset+16*i)
        assert name_offset<strings_size,'module symbol name bounds'
        start=strings+name_offset
        stop=data.find(b'\0',start,min(strings+strings_size,start+1024))
        assert stop>=start,'module symbol name terminator/project limit'
        name=data[start:stop]
        if kind&0xe0 or kind&0x0e!=0x0e or not kind&1:continue
        assert 1<=section<=len(sections),'module exported symbol section'
        section_name,start,n=sections[section-1]
        if section_name!=b'__objc_data' or not start<=address<start+n:continue
        for cls in EXPECTED:
            if name==('_OBJC_CLASS_$_'+cls).encode():found.add(cls)
    assert found==set(EXPECTED),'module class export missing or not defined in __objc_data'
    return sorted(found)
