#!/bin/sh
set -eu
cd "$(dirname "$0")/.."
testbin=$(mktemp)
runtime_src=$(mktemp -t pc-runtime.XXXXXX.m)
trap 'rm -f "$testbin" "$runtime_src"' EXIT
cc -std=c99 -Wall -Wextra -Werror tests/policy.c -o "$testbin"
"$testbin"
cc -std=c99 -Wall -Wextra -Werror tests/protocol.c -o "$testbin"
"$testbin"
if [ "$(uname -s)" = Darwin ]; then
  clang -fobjc-arc -Wall -Wextra -Werror -framework Foundation tests/foundation.m -o "$testbin"
  "$testbin"
  python3 tests/extract_runtime.py "$runtime_src"
  clang -fobjc-arc -Wall -Wextra -Werror -I. -framework Foundation -x objective-c "$runtime_src" -o "$testbin"
  "$testbin"
else
  echo "NOT RUN: macOS Foundation and Objective-C runtime tests (required in CI)"
fi
sh -n layout/DEBIAN/postinst
sh -n layout/DEBIAN/postrm
python3 tests/scripts.py
python3 - <<'PY'
import plistlib
from pathlib import Path
p=Path('layout/Library/PreferenceLoader/Preferences/Powercuff/Powercuff.plist')
d=plistlib.loads(p.read_bytes());items={v.get('key'):v for v in d['items'] if 'key' in v}
assert set(items)=={'PowerMode','RequireLowPowerMode'}
assert items['PowerMode']['validValues']==list(range(5))
assert len(items['PowerMode']['validTitles'])==5
assert items['PowerMode']['default']==0
assert items['RequireLowPowerMode']['default'] is False
for item in items.values():
 assert item['defaults']=='com.rpetrich.powercuff'
 assert item['PostNotification']=='com.rpetrich.powercuff.settingschanged'
print('PASS: preference schema, defaults, mode mapping and notification domain')
PY
