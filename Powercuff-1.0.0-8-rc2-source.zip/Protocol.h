#pragma once
#include <stdbool.h>
#include <stdint.h>
#define PC_NONCE_MASK UINT64_C(0xffffffffff)
#define PC_REQUEST_TAG UINT64_C(0x5051000000000000)
#define PC_RESPONSE_TAG UINT64_C(0x5052000000000000)
#define PC_STATUS_TAG UINT64_C(0x5053000000000000)
static inline uint64_t PCNonce(uint64_t value) { return (value >> 8) & PC_NONCE_MASK; }
static inline uint64_t PCRequest(uint64_t nonce) { return PC_REQUEST_TAG | ((nonce & PC_NONCE_MASK) << 8); }
static inline bool PCValidRequest(uint64_t value) {
    return (value & UINT64_C(0xffff0000000000ff)) == PC_REQUEST_TAG && PCNonce(value) != 0;
}
static inline uint64_t PCResponse(uint64_t nonce, unsigned mode) {
    return PC_RESPONSE_TAG | ((nonce & PC_NONCE_MASK) << 8) | mode;
}
static inline bool PCDecodeResponse(uint64_t value, uint64_t nonce, unsigned *mode) {
    if ((value & UINT64_C(0xffff000000000000)) != PC_RESPONSE_TAG ||
        !nonce || nonce > PC_NONCE_MASK || PCNonce(value) != nonce || (value & 255) > 4) return false;
    *mode = (unsigned)(value & 255);
    return true;
}
typedef struct { uint64_t nonce; bool received; unsigned mode; } PCSession;
static inline void PCStartSession(PCSession *session, uint64_t nonce) {
    session->nonce = nonce & PC_NONCE_MASK;
    session->received = false;
    session->mode = 0; // Not valid until a matching response arrives.
}
static inline bool PCAcceptResponse(PCSession *session, uint64_t value) {
    unsigned mode;
    if (!PCDecodeResponse(value, session->nonce, &mode)) return false;
    session->mode = mode;
    session->received = true;
    return true;
}
