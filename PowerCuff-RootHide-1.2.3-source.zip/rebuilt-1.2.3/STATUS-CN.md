# 本次执行状态（2026-11-03）

已实施：五档核心修复工程、共享偏好解析、会话通信与状态反馈、弱引用与 ABI 检查、原生控制中心重建、有限关闭确认工具、安装卸载脚本、包校验器、固定工具链 macOS Actions 流程。

已执行并通过：
- C 协议测试：当前会话、旧会话拒绝、模式边界、损坏头、全部256种状态编码，以及状态字不能当作模式字。
- 所有工程 plist 解析。
- 构建与维护 shell 脚本语法检查。
- Python 包校验器语法检查。
- 包校验器的代码页哈希函数：对原 1.2.2 的两个真实 arm64e Mach-O 校验通过；修改代码字节后均拒绝。

尚未执行：
- macOS Foundation 偏好、runtime 和生产核心模拟测试（已加入 CI）。
- iOS arm64e 编译、链接、ldid 签名、实际 DEB 打包与新包校验。
- iPhone 真机加载、界面、PAC、真实温控/频率、watchdog 和续航测试。

原因：当前主机没有 clang/iOS SDK/Theos；包管理器初始化也因容器 UID/组权限失败。GitHub 自动审批阻止上传具体公开源码及工作流，理由是需要用户明确授权此次公开上传。本次没有创建远端分支/提交，也没有运行 Actions。

待授权的具体动作：向用户可管理的公开仓库 allantopwisdom-cell/Repo 新增 rebuild/powercuff-1.2.3 分支；上传本源码包内 rebuilt-1.2.3/ 与 .github/workflows/powercuff-rebuilt.yml；运行 macOS Actions，检查日志、修复构建错误并下载实际 DEB。该工作流仅请求 contents:read，不创建 Release，不覆盖主分支或旧版本。

源码中 ctl/entitlements.plist 包含 RootHide 官方要求的命令行程序签名权限；不含账户凭据/API key。只有明确授权后才重试公开上传。

**本源码包不是可安装 DEB，也不是已通过编译的版本。**
