#import <UIKit/UIKit.h>
#import <Foundation/Foundation.h>
#import <objc/message.h>
#import <objc/runtime.h>
#import <notify.h>
#import "../PCRProtocol.h"
#import "../PCRPreferences.h"
// Deliberately minimal private API declarations; no private ivar or KVC access.
@interface CCUIMenuModuleViewController : UIViewController
- (void)setTitle:(NSString *)title;
- (void)setMenuItems:(NSArray *)items;
- (void)setGlyphImage:(UIImage *)image;
- (void)setSelectedGlyphColor:(UIColor *)color;
- (void)_handleActionTapped:(id)sender;
- (void)willTransitionToExpandedContentMode:(BOOL)expanded;
@end
@interface NSObject (PCMenuInterface)
- (id)initWithTitle:(NSString *)title identifier:(NSString *)identifier handler:(id)handler;
- (void)setSubtitle:(NSString *)subtitle;
- (void)setSelected:(BOOL)selected;
- (id)menuItem;
- (NSString *)identifier;
@end

@interface PowercuffCCModuleViewController : CCUIMenuModuleViewController {
    int _settingsToken, _appliedToken, _requestToken;
    BOOL _waiting;
    uint32_t _previousSession;
}
@property(nonatomic) NSInteger selectedIndex;
@property(nonatomic,copy) NSString *statusText;
- (void)refresh;
- (void)refreshStatus;
- (void)chooseMode:(NSInteger)mode;
- (void)queryStatus;
@end

static NSUserDefaults *PCDefaults(void) {
    return [[NSUserDefaults alloc] initWithSuiteName:@"com.dao.powercuff"];
}
static uint32_t PCSession(int token) {
    uint64_t word = 0; uint32_t session = 0;
    if (token >= 0 && notify_get_state(token, &word) == NOTIFY_STATUS_OK)
        PCRDecodeRequest(word, &session);
    return session;
}
@implementation PowercuffCCModuleViewController
- (id)init {
    if ((self = [super initWithNibName:nil bundle:nil])) {
        _settingsToken = _appliedToken = _requestToken = -1;
        __weak typeof(self) weak = self;
        if (notify_register_check("com.powercuff.roothide.request", &_requestToken) != NOTIFY_STATUS_OK)
            _requestToken = -1;
        if (notify_register_dispatch("com.dao.powercuff.settingschanged", &_settingsToken,
            dispatch_get_main_queue(), ^(int t) { (void)t; [weak refresh]; }) != NOTIFY_STATUS_OK)
            _settingsToken = -1;
        if (notify_register_dispatch(PCRAppliedName, &_appliedToken, dispatch_get_main_queue(),
            ^(int t) { (void)t; [weak refreshStatus]; }) != NOTIFY_STATUS_OK)
            _appliedToken = -1;
        _statusText = @"未验证后台状态";
    }
    return self;
}
- (void)dealloc {
    if (_settingsToken >= 0) notify_cancel(_settingsToken);
    if (_appliedToken >= 0) notify_cancel(_appliedToken);
    if (_requestToken >= 0) notify_cancel(_requestToken);
}
- (void)viewDidLoad {
    [super viewDidLoad];
    if ([self respondsToSelector:@selector(setGlyphImage:)])
        [self setGlyphImage:[UIImage systemImageNamed:@"thermometer"]];
    [self refresh];
}
- (void)viewWillAppear:(BOOL)animated {
    [super viewWillAppear:animated]; [self queryStatus];
}
- (void)controlCenterWillPresent { [self queryStatus]; }
- (BOOL)shouldBeginTransitionToExpandedContentModule { return YES; }
- (BOOL)_canShowWhileLocked { return YES; }
- (void)willTransitionToExpandedContentMode:(BOOL)expanded {
    if ([CCUIMenuModuleViewController instancesRespondToSelector:_cmd])
        [super willTransitionToExpandedContentMode:expanded];
    if (expanded) [self queryStatus];
}
- (void)refresh {
    NSDictionary *snapshot = PCRPreferenceSnapshot(PCDefaults(), @"com.dao.powercuff");
    self.selectedIndex = PCRSelectedMode(snapshot[@"PowerMode"]);
    NSArray *titles = @[@"无", @"正常", @"轻度", @"适中", @"重度"];
    Class itemClass = objc_getClass("CCUIMenuModuleItem");
    if (!itemClass || ![itemClass instancesRespondToSelector:@selector(initWithTitle:identifier:handler:)]) return;
    NSMutableArray *items = [NSMutableArray arrayWithCapacity:5];
    for (NSInteger i=0; i<5; ++i) {
        id item = [[itemClass alloc] initWithTitle:titles[i] identifier:[@(i) stringValue] handler:nil];
        if (!item) continue;
        if ([item respondsToSelector:@selector(setSelected:)]) [item setSelected:i == self.selectedIndex];
        if ([item respondsToSelector:@selector(setSubtitle:)])
            [item setSubtitle:i == self.selectedIndex ? self.statusText : @"选择此热模拟档位"];
        [items addObject:item];
    }
    if ([self respondsToSelector:@selector(setTitle:)]) [self setTitle:@"PowerCuff"];
    if ([self respondsToSelector:@selector(setMenuItems:)]) [self setMenuItems:items];
}
- (void)queryStatus {
    _previousSession = PCSession(_requestToken);
    _waiting = YES;
    self.statusText = @"正在确认接口状态…";
    [self refresh];
    if (notify_post("com.dao.powercuff.settingschanged") != NOTIFY_STATUS_OK) {
        _waiting = NO; self.statusText = @"通知发送失败"; [self refresh]; return;
    }
    __weak typeof(self) weak = self;
    // Bounded UI refresh only; no background polling loop.
    for (NSNumber *delay in @[@0.4, @1.3, @3.2]) {
        dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(delay.doubleValue*NSEC_PER_SEC)),
                       dispatch_get_main_queue(), ^{ [weak refreshStatus]; });
    }
}
- (void)refreshStatus {
    uint32_t session = PCSession(_requestToken);
    uint64_t word = 0; unsigned status = 255;
    BOOL valid = _appliedToken >= 0 && session &&
        notify_get_state(_appliedToken, &word) == NOTIFY_STATUS_OK &&
        PCRDecodeStatus(word, session, &status);
    if (_waiting && session == _previousSession) valid = NO;
    if (valid && status <= 4) {
        _waiting = NO;
        NSArray *names = @[@"关闭", @"正常", @"轻度", @"适中", @"重度"];
        self.statusText = [NSString stringWithFormat:@"接口已返回：%@", names[status]];
    } else if (valid && (status == 98 || status == 99)) {
        _waiting = NO; self.statusText = status == 98 ? @"接口异常，已停止重试" : @"接口不兼容";
    } else {
        self.statusText = @"尚未收到本次应用确认";
    }
    [self refresh];
}
- (void)chooseMode:(NSInteger)mode {
    if (mode < 0 || mode > 4) return;
    NSUserDefaults *d = PCDefaults();
    [d setObject:@(mode) forKey:@"PowerMode"];
    if (![d synchronize]) {
        self.statusText = @"设置同步失败，未确认应用"; [self refresh]; return;
    }
    [self queryStatus];
}
- (void)buttonTapped:(id)sender forEvent:(id)event {
    (void)sender; (void)event;
    NSDictionary *snapshot = PCRPreferenceSnapshot(PCDefaults(), @"com.dao.powercuff");
    [self chooseMode:(PCRSelectedMode(snapshot[@"PowerMode"])+1)%5];
}
- (void)_handleActionTapped:(id)sender {
    id item = [sender respondsToSelector:@selector(menuItem)] ? [sender menuItem] : sender;
    NSString *identifier = [item respondsToSelector:@selector(identifier)] ? [item identifier] : nil;
    NSArray *ids = @[@"0", @"1", @"2", @"3", @"4"];
    NSUInteger index = [identifier isKindOfClass:NSString.class] ? [ids indexOfObject:identifier] : NSNotFound;
    if (index == NSNotFound) {
        if ([CCUIMenuModuleViewController instancesRespondToSelector:_cmd]) [super _handleActionTapped:sender];
        return;
    }
    [self chooseMode:(NSInteger)index];
}
@end

@protocol CCUIContentModule <NSObject>
@property(nonatomic,readonly) UIViewController *contentViewController;
@property(nonatomic,readonly) UIViewController *backgroundViewController;
@end
@interface PowercuffCCModule : NSObject <CCUIContentModule>
@property(nonatomic,strong,readonly) UIViewController *contentViewController;
@property(nonatomic,strong,readonly) UIViewController *backgroundViewController;
@end
@implementation PowercuffCCModule
- (id)init {
    if ((self=[super init])) _contentViewController = [PowercuffCCModuleViewController new];
    return self;
}
@end
