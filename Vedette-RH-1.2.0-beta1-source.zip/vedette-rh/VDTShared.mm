// Original project Copyright (c) 2021 udevs; defensive preferences I/O, GPLv3.
#import "VDTShared.h"
#import "VDTPolicy.h"
#include <sys/file.h>
#include <fcntl.h>
#include <unistd.h>

static NSDictionary *readDictionary(NSString *path) {
    NSDictionary *d=[NSDictionary dictionaryWithContentsOfFile:path];
    return [d isKindOfClass:NSDictionary.class]?d:@{};
}
NSDictionary *getPrefs(){return readDictionary(PREFS_PATH);}
NSDictionary *getTempPrefs(){return readDictionary(PREFS_PATH_TMP);}
id valueForKey(NSString *key){return getPrefs()[key];}
id valueForKeyWithPrefs(NSString *key,NSDictionary *prefs){return (prefs?:getPrefs())[key];}
static NSString *collectionKey(VDTConfigType type){return type==VDTConfigTypeApp?@"appConfigs":@"daemonConfigs";}
static NSString *identifierKey(VDTConfigType type){return type==VDTConfigTypeApp?@"bundleIdentifier":@"daemonName";}
static void changePrefs(void (^change)(NSMutableDictionary *)) {
    // Serialize independent settings writers; atomic file replacement alone does not prevent lost updates.
    NSString *lockPath=[PREFS_PATH stringByAppendingString:@".lock"];
    int fd=open(lockPath.fileSystemRepresentation,O_CREAT|O_RDWR|O_NOFOLLOW,0600);
    if(fd<0 || flock(fd,LOCK_EX)!=0){if(fd>=0)close(fd);NSLog(@"[Vedette RH] preferences lock failed");return;}
    NSMutableDictionary *prefs=[getPrefs() mutableCopy];change(prefs);
    BOOL ok=[prefs writeToFile:PREFS_PATH atomically:YES];
    flock(fd,LOCK_UN);close(fd);
    if(ok)CFNotificationCenterPostNotification(CFNotificationCenterGetDarwinNotifyCenter(),(CFStringRef)PREFS_CHANGED_NN,NULL,NULL,YES);
    else NSLog(@"[Vedette RH] preferences write failed");
}
void setValueForKeyWithPrefs(NSString *key,id value,NSDictionary *prefs) {
    (void)prefs; if(![key isKindOfClass:NSString.class] || !value)return;
    changePrefs(^(NSMutableDictionary *d){d[key]=value;});
}
void setValueForKey(NSString *key,id value){setValueForKeyWithPrefs(key,value,nil);}
id valueForProcessConfigKeyWithPrefs(NSString *ident,NSString *key,id fallback,VDTConfigType type,NSDictionary *prefs) {
    if(![ident isKindOfClass:NSString.class] || !ident.length)return fallback;
    id configs=(prefs?:getPrefs())[collectionKey(type)];
    if(![configs isKindOfClass:NSArray.class])return fallback;
    for(id item in configs)if([item isKindOfClass:NSDictionary.class] && [item[identifierKey(type)] isEqual:ident])return item[key]?:fallback;
    return fallback;
}
id valueForProcessConfigKey(NSString *ident,NSString *key,id fallback,VDTConfigType type) {
    return valueForProcessConfigKeyWithPrefs(ident,key,fallback,type,nil);
}
void setValueForProcessConfigKeyWithPrefs(NSString *ident,NSString *key,id value,VDTConfigType type,NSDictionary *prefs) {
    (void)prefs;
    if(![ident isKindOfClass:NSString.class] || !ident.length || ![key isKindOfClass:NSString.class] || !value)return;
    if([key isEqual:@"enabled"] && [value respondsToSelector:@selector(boolValue)] && [value boolValue] &&
       ((type==VDTConfigTypeDaemon && vdt_protected_name(ident.UTF8String)) ||
        [ident isEqual:@"com.apple.Preferences"] || [ident isEqual:@"com.apple.springboard"]))return;
    changePrefs(^(NSMutableDictionary *d){
        id original=d[collectionKey(type)];
        NSMutableArray *items=[NSMutableArray array]; BOOL updated=NO;
        if([original isKindOfClass:NSArray.class])for(id item in original) {
            if(![item isKindOfClass:NSDictionary.class])continue;
            if([item[identifierKey(type)] isEqual:ident]) {
                if(updated)continue;
                NSMutableDictionary *entry=[item mutableCopy];entry[key]=value;[items addObject:entry];updated=YES;
            }else [items addObject:item];
        }
        if(!updated)[items addObject:@{identifierKey(type):ident,key:value}];
        d[collectionKey(type)]=items;
    });
}
void setValueForProcessConfigKey(NSString *ident,NSString *key,id value,VDTConfigType type) {
    setValueForProcessConfigKeyWithPrefs(ident,key,value,type,nil);
}
void VDTResetPreferences(void) {
    // Replace settings with a disabled snapshot; journal remains owned by the controller until restored.
    changePrefs(^(NSMutableDictionary *d){[d removeAllObjects];d[@"enabled"]=@NO;d[@"dryRun"]=@YES;});
}
